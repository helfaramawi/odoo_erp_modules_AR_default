from odoo import models, fields, api, _
from datetime import date, timedelta
from dateutil.relativedelta import relativedelta

class InventoryRevaluationWizard(models.TransientModel):
    _name = "inventory.revaluation.wizard"
    _description = "Inventory Revaluation Report Wizard / معالج تقرير إعادة التقييم"

    as_of_date = fields.Date(string="As of Date / حتى تاريخ", required=True, default=fields.Date.today)
    company_id = fields.Many2one("res.company", default=lambda self: self.env.company, required=True)
    location_ids = fields.Many2many("stock.location",
        domain="[('usage','=','internal')]",
        string="Locations / المواقع")
    show_zero_qty = fields.Boolean(string="Show Zero Qty / إظهار الكميات الصفرية", default=False)

    def action_print_report(self):
        return self.env.ref("c10_inventory_revaluation.action_report_revaluation").report_action(
            self, data={"as_of_date": str(self.as_of_date), "company_id": self.company_id.id})

    def _get_revaluation_data(self):
        as_of = self.as_of_date or date.today()
        prior = as_of - relativedelta(months=1)
        company = self.company_id

        domain = [("company_id","=",company.id)]
        if self.location_ids:
            domain.append(("location_id","in",self.location_ids.ids))
        if not self.show_zero_qty:
            domain.append(("quantity","!=",0))

        quants = self.env["stock.quant"].search(domain)
        result = []
        for q in quants:
            product = q.product_id
            qty = q.quantity
            cost = product.standard_price
            current_value = qty * cost

            prior_quants = self.env["stock.quant"].search([
                ("product_id","=",product.id),
                ("company_id","=",company.id),
            ])
            prior_qty = sum(prior_quants.mapped("quantity"))
            prior_value = prior_qty * cost
            variance = current_value - prior_value

            result.append({
                "product": product.display_name,
                "category": product.categ_id.complete_name,
                "qty": qty,
                "uom": product.uom_id.name,
                "cost": cost,
                "current_value": current_value,
                "prior_value": prior_value,
                "variance": variance,
            })
        return sorted(result, key=lambda x: (x["category"], x["product"]))
