{
    'name': 'استمارة 69 - الحسبة اليومية',
    'summary': 'C-FM-03: Form 69 Daily Reckoning (الحسبة اليومية)',
    'version': '17.0.1.0.0',
    'author': 'Paradise Integrated Solutions',
    'license': 'LGPL-3',
    'depends': ['port_said_daftar224'],
    'data': [
        'security/ir.model.access.csv',
        'data/cron_data.xml',
        'views/form69_views.xml',
        'reports/form69_report.xml',
        'reports/form69_template.xml',
    ],
    'installable': True,
}
