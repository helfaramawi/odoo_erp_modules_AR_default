# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
from datetime import date


class StockTransferPermit(models.Model):
    """
    إذن التحويل بين المخازن — FR-I4
    نقل الأصناف من مخزن لآخر أو من إدارة لأخرى مع توثيق رسمي
    """
    _name = 'stock.transfer.permit'
    _description = 'إذن التحويل بين المخازن'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'name'
    _order = 'transfer_date desc, name desc'

    name = fields.Char(
        string='رقم إذن التحويل', required=True, copy=False,
        readonly=True, default='/', tracking=True,
    )
    transfer_date = fields.Date(
        string='تاريخ التحويل', required=True,
        default=fields.Date.context_today, tracking=True,
    )
    transfer_reason = fields.Text(
        string='سبب التحويل', required=True, tracking=True,
    )
    fiscal_year = fields.Char(
        string='السنة المالية',
        default=lambda self: str(date.today().year),
    )

    # ── من / إلى ─────────────────────────────────────────────────
    from_warehouse_id = fields.Many2one(
        'stock.warehouse', string='المستودع المُحوِّل', required=True, tracking=True,
    )
    from_location_id = fields.Many2one(
        'stock.location', string='الموقع المصدر', required=True,
        domain="[('usage','=','internal')]", tracking=True,
    )
    from_dept = fields.Char(string='الإدارة المُحوِّلة', tracking=True)
    from_storekeeper_id = fields.Many2one('hr.employee', string='أمين مخزن المصدر')

    to_warehouse_id = fields.Many2one(
        'stock.warehouse', string='المستودع المستلم', required=True, tracking=True,
    )
    to_location_id = fields.Many2one(
        'stock.location', string='الموقع الوجهة', required=True,
        domain="[('usage','=','internal')]", tracking=True,
    )
    to_dept = fields.Char(string='الإدارة المستلمة', tracking=True)
    to_storekeeper_id = fields.Many2one('hr.employee', string='أمين مخزن الوجهة')

    # ── الأصناف ──────────────────────────────────────────────────
    line_ids = fields.One2many(
        'stock.transfer.permit.line', 'permit_id',
        string='الأصناف المُحوَّلة',
    )

    # ── التكامل ──────────────────────────────────────────────────
    picking_id = fields.Many2one(
        'stock.picking', string='حركة المخزن', readonly=True,
    )
    # إذا كان التحويل لأصل ثابت
    fixed_asset_id = fields.Many2one(
        'port_said.fixed.asset', string='الأصل الثابت (إن وُجد)',
    )
    # إذا كان تحويل عهدة
    custody_id = fields.Many2one(
        'custody.assignment', string='إذن العهدة المرتبط',
    )

    # ── الحالة ───────────────────────────────────────────────────
    state = fields.Selection([
        ('draft',     'مسودة'),
        ('submitted', 'مقدم'),
        ('approved',  'معتمد'),
        ('posted',    'مرحَّل'),
        ('received',  'تم الاستلام'),
        ('cancelled', 'ملغي'),
    ], default='draft', tracking=True)

    approved_by = fields.Many2one('res.users', string='معتمد من', readonly=True)
    received_by = fields.Many2one('res.users', string='تسلَّم من', readonly=True)
    notes = fields.Text(string='ملاحظات')

    total_lines = fields.Integer(compute='_compute_totals')
    total_value = fields.Float(compute='_compute_totals')

    @api.depends('line_ids')
    def _compute_totals(self):
        for rec in self:
            rec.total_lines = len(rec.line_ids)
            rec.total_value = sum(rec.line_ids.mapped('total_value'))

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', '/') == '/':
                vals['name'] = self.env['ir.sequence'].next_by_code(
                    'stock.transfer.permit') or '/'
        return super().create(vals_list)

    def action_submit(self):
        for rec in self:
            if not rec.line_ids:
                raise UserError(_('يجب إضافة صنف واحد على الأقل'))
            rec.write({'state': 'submitted'})
        return True

    def action_approve(self):
        for rec in self:
            rec.write({'state': 'approved', 'approved_by': self.env.user.id})
        return True

    def action_post(self):
        """ترحيل التحويل — إنشاء internal picking"""
        for rec in self:
            if rec.state != 'approved':
                raise UserError(_('يجب اعتماد الإذن أولاً'))

            picking_type = self.env['stock.picking.type'].search([
                ('code', '=', 'internal'),
                ('warehouse_id', '=', rec.from_warehouse_id.id),
            ], limit=1)
            if not picking_type:
                picking_type = self.env['stock.picking.type'].search([
                    ('code', '=', 'internal')], limit=1)

            moves = []
            for line in rec.line_ids:
                moves.append((0, 0, {
                    'name': line.product_id.name,
                    'product_id': line.product_id.id,
                    'product_uom_qty': line.qty,
                    'product_uom': line.uom_id.id,
                    'location_id': rec.from_location_id.id,
                    'location_dest_id': rec.to_location_id.id,
                }))

            picking = self.env['stock.picking'].create({
                'picking_type_id': picking_type.id,
                'location_id': rec.from_location_id.id,
                'location_dest_id': rec.to_location_id.id,
                'origin': rec.name,
                'move_ids': moves,
            })
            picking.action_confirm()
            rec.write({'state': 'posted', 'picking_id': picking.id})
            rec.message_post(body=_(f'تم الترحيل — حركة مخزن: {picking.name}'))
        return True

    def action_receive(self):
        """تأكيد الاستلام في المستودع الوجهة"""
        for rec in self:
            if rec.state != 'posted':
                raise UserError(_('يجب ترحيل التحويل أولاً'))
            if rec.picking_id:
                rec.picking_id.button_validate()
            rec.write({'state': 'received', 'received_by': self.env.user.id})
        return True

    def action_cancel(self):
        for rec in self:
            if rec.state in ('posted', 'received'):
                raise UserError(_('لا يمكن إلغاء تحويل مرحَّل'))
            rec.write({'state': 'cancelled'})
        return True


class StockTransferPermitLine(models.Model):
    _name = 'stock.transfer.permit.line'
    _description = 'بند إذن التحويل'
    _order = 'sequence, id'

    permit_id = fields.Many2one(
        'stock.transfer.permit', required=True, ondelete='cascade', index=True,
    )
    sequence = fields.Integer(default=10)
    product_id = fields.Many2one('product.product', string='الصنف', required=True)
    product_code = fields.Char(related='product_id.default_code', store=True)
    uom_id = fields.Many2one(
        'uom.uom', related='product_id.uom_id', store=True, string='الوحدة',
    )
    qty = fields.Float(
        string='الكمية', required=True, digits='Product Unit of Measure',
    )
    unit_price = fields.Float(string='سعر الوحدة', digits='Product Price')
    total_value = fields.Float(compute='_compute_total', store=True)
    serial_lot = fields.Char(string='الرقم التسلسلي / الدفعة')
    condition = fields.Selection([
        ('good', 'سليم'),
        ('fair', 'مقبول'),
        ('damaged', 'تالف'),
    ], string='الحالة', default='good')
    notes = fields.Char(string='ملاحظات')

    @api.depends('qty', 'unit_price')
    def _compute_total(self):
        for line in self:
            line.total_value = line.qty * line.unit_price

    @api.onchange('product_id')
    def _onchange_product(self):
        if self.product_id:
            self.unit_price = self.product_id.standard_price
