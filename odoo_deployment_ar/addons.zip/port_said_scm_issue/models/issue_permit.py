# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
from datetime import date


class StockIssuePermit(models.Model):
    """
    إذن الصرف من المخزن — نموذج 2 مخازن / استمارة 111 ع.ح
    FR-I2: صرف الأصناف المستديمة والمستهلكة
    يتكامل مع: stock.picking | port_said_daftar55 | port_said_commitment | l10n_eg_custody
    """
    _name = 'stock.issue.permit'
    _description = 'إذن الصرف — نموذج 2 مخازن / 111 ع.ح'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'name'
    _order = 'issue_date desc, name desc'

    # ── هوية الإذن ───────────────────────────────────────────────
    name = fields.Char(
        string='رقم إذن الصرف', required=True, copy=False,
        readonly=True, default='/', tracking=True,
    )
    issue_type = fields.Selection([
        ('consumable',  'مستهلكات — Consumables'),
        ('durable',     'مستديمات — Durable Goods'),
        ('maintenance', 'صيانة — Maintenance'),
        ('project',     'مشروع — Project'),
        ('direct',      'صرف مباشر — Direct Issue'),
    ], string='نوع الصرف', required=True, default='consumable', tracking=True)

    issue_date = fields.Date(
        string='تاريخ الإذن', required=True,
        default=fields.Date.context_today, tracking=True,
    )
    reference_no = fields.Char(string='رقم المرجع / أمر العمل', tracking=True)
    fiscal_year = fields.Char(
        string='السنة المالية',
        default=lambda self: str(date.today().year),
    )

    # ── الطالب والمستلم ──────────────────────────────────────────
    requesting_dept = fields.Char(
        string='الإدارة / المصلحة الطالبة', required=True, tracking=True,
    )
    requesting_employee_id = fields.Many2one(
        'hr.employee', string='الموظف الطالب', tracking=True,
    )
    receiving_employee_id = fields.Many2one(
        'hr.employee', string='الموظف المستلم', tracking=True,
        help='الموظف الذي استلم الأصناف فعلياً',
    )
    purpose = fields.Text(string='الغرض من الصرف', required=True, tracking=True)

    # ── المخزن ───────────────────────────────────────────────────
    warehouse_id = fields.Many2one(
        'stock.warehouse', string='المستودع', required=True, tracking=True,
    )
    location_id = fields.Many2one(
        'stock.location', string='موقع المصدر', required=True,
        domain="[('usage','=','internal')]", tracking=True,
    )
    location_dest_id = fields.Many2one(
        'stock.location', string='موقع الوجهة',
        default=lambda self: self.env.ref('stock.stock_location_customers', raise_if_not_found=False),
        tracking=True,
    )
    storekeeper_id = fields.Many2one(
        'hr.employee', string='أمين المخزن', tracking=True,
    )

    # ── الأصناف ──────────────────────────────────────────────────
    line_ids = fields.One2many(
        'stock.issue.permit.line', 'permit_id',
        string='الأصناف المطلوب صرفها',
    )

    # ── التكامل ──────────────────────────────────────────────────
    picking_id = fields.Many2one(
        'stock.picking', string='حركة المخزن (Picking)', readonly=True,
    )
    daftar55_id = fields.Many2one(
        'port_said.daftar55', string='مرجع دفتر 55 ع.ح',
        help='مرجع اذا كان الصرف مرتبطاً بعملية صرف مالي',
    )
    commitment_id = fields.Many2one(
        'port_said.commitment', string='الارتباط الميزاني',
    )
    custody_ids = fields.Many2many(
        'custody.assignment', string='العهد المرتبطة',
        help='العهد الحكومية المرتبطة بهذا الصرف',
    )

    # ── الحالة ───────────────────────────────────────────────────
    state = fields.Selection([
        ('draft',     'مسودة'),
        ('submitted', 'مقدم للاعتماد'),
        ('approved',  'معتمد'),
        ('posted',    'مرحَّل — تم الصرف'),
        ('cancelled', 'ملغي'),
    ], string='الحالة', default='draft', tracking=True, required=True)

    approved_by = fields.Many2one('res.users', string='معتمد من', readonly=True)
    approval_date = fields.Date(string='تاريخ الاعتماد', readonly=True)
    notes = fields.Text(string='ملاحظات')

    # ── إحصاءات ──────────────────────────────────────────────────
    total_lines = fields.Integer(string='عدد الأصناف', compute='_compute_totals')
    total_value = fields.Float(string='القيمة الإجمالية', compute='_compute_totals')

    @api.depends('line_ids', 'line_ids.total_value')
    def _compute_totals(self):
        for rec in self:
            rec.total_lines = len(rec.line_ids)
            rec.total_value = sum(rec.line_ids.mapped('total_value'))

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', '/') == '/':
                vals['name'] = self.env['ir.sequence'].next_by_code(
                    'stock.issue.permit') or '/'
        return super().create(vals_list)

    # ── Workflow ─────────────────────────────────────────────────
    def action_submit(self):
        for rec in self:
            if not rec.line_ids:
                raise UserError(_('يجب إضافة صنف واحد على الأقل'))
            rec.write({'state': 'submitted'})
        return True

    def action_approve(self):
        for rec in self:
            rec.write({
                'state': 'approved',
                'approved_by': self.env.user.id,
                'approval_date': date.today(),
            })
        return True

    def action_post(self):
        """ترحيل إذن الصرف — إنشاء stock.picking وتحريك المخزون"""
        for rec in self:
            if rec.state != 'approved':
                raise UserError(_('يجب اعتماد الإذن أولاً'))
            if not rec.line_ids:
                raise UserError(_('لا توجد أصناف للصرف'))

            # تحقق من الكميات المتاحة
            for line in rec.line_ids:
                if line.qty_requested <= 0:
                    raise ValidationError(_(f'كمية الصنف {line.product_id.name} يجب أن تكون موجبة'))

            # إنشاء stock.picking
            picking_type = self.env['stock.picking.type'].search([
                ('code', '=', 'outgoing'),
                ('warehouse_id', '=', rec.warehouse_id.id),
            ], limit=1)
            if not picking_type:
                picking_type = self.env['stock.picking.type'].search([
                    ('code', '=', 'outgoing'),
                ], limit=1)

            moves = []
            for line in rec.line_ids:
                moves.append((0, 0, {
                    'name': line.product_id.name,
                    'product_id': line.product_id.id,
                    'product_uom_qty': line.qty_requested,
                    'product_uom': line.uom_id.id,
                    'location_id': rec.location_id.id,
                    'location_dest_id': rec.location_dest_id.id
                    if rec.location_dest_id
                    else self.env.ref('stock.stock_location_customers').id,
                }))

            picking = self.env['stock.picking'].create({
                'picking_type_id': picking_type.id,
                'partner_id': rec.receiving_employee_id.address_id.id
                if rec.receiving_employee_id and rec.receiving_employee_id.address_id
                else False,
                'location_id': rec.location_id.id,
                'location_dest_id': rec.location_dest_id.id
                if rec.location_dest_id
                else self.env.ref('stock.stock_location_customers').id,
                'origin': rec.name,
                'move_ids': moves,
            })
            picking.action_confirm()

            rec.write({'state': 'posted', 'picking_id': picking.id})
            rec.message_post(body=_(f'تم ترحيل إذن الصرف — حركة مخزن: {picking.name}'))
        return True

    def action_cancel(self):
        for rec in self:
            if rec.state == 'posted':
                raise UserError(_('لا يمكن إلغاء إذن صرف مرحَّل'))
            rec.write({'state': 'cancelled'})
        return True

    def unlink(self):
        for rec in self:
            if rec.state in ('posted', 'approved'):
                raise UserError(_('لا يمكن حذف إذن صرف معتمد أو مرحَّل'))
        return super().unlink()


class StockIssuePermitLine(models.Model):
    """بنود إذن الصرف"""
    _name = 'stock.issue.permit.line'
    _description = 'بند إذن الصرف'
    _order = 'sequence, id'

    permit_id = fields.Many2one(
        'stock.issue.permit', string='إذن الصرف',
        required=True, ondelete='cascade', index=True,
    )
    sequence = fields.Integer(default=10)
    product_id = fields.Many2one(
        'product.product', string='الصنف', required=True,
    )
    product_code = fields.Char(
        related='product_id.default_code', string='كود الصنف', store=True,
    )
    description = fields.Char(string='الوصف / الملاحظة')
    unit = fields.Char(string='الوحدة')
    uom_id = fields.Many2one(
        'uom.uom', string='وحدة القياس',
        related='product_id.uom_id', store=True,
    )

    qty_requested = fields.Float(
        string='الكمية المطلوبة', required=True, digits='Product Unit of Measure',
    )
    qty_available = fields.Float(
        string='الكمية المتاحة', compute='_compute_available', store=False,
    )
    qty_issued = fields.Float(
        string='الكمية المصروفة الفعلية', digits='Product Unit of Measure',
    )
    unit_price = fields.Float(string='سعر الوحدة', digits='Product Price')
    total_value = fields.Float(
        string='القيمة الإجمالية', compute='_compute_total', store=True,
    )

    # ربط بالعهدة
    custody_assignment_id = fields.Many2one(
        'custody.assignment', string='إذن العهدة (إن وُجد)',
        help='يُربط إذا كان الصنف مُسجَّلاً كعهدة',
    )
    # ربط بالأصول الثابتة
    fixed_asset_id = fields.Many2one(
        'port_said.fixed.asset', string='الأصل الثابت (إن وُجد)',
    )
    notes = fields.Char(string='ملاحظات')

    @api.depends('product_id', 'permit_id.location_id')
    def _compute_available(self):
        for line in self:
            if line.product_id and line.permit_id.location_id:
                quant = self.env['stock.quant'].search([
                    ('product_id', '=', line.product_id.id),
                    ('location_id', '=', line.permit_id.location_id.id),
                ], limit=1)
                line.qty_available = quant.quantity if quant else 0.0
            else:
                line.qty_available = 0.0

    @api.depends('qty_requested', 'unit_price')
    def _compute_total(self):
        for line in self:
            line.total_value = line.qty_requested * line.unit_price

    @api.onchange('product_id')
    def _onchange_product(self):
        if self.product_id:
            self.unit_price = self.product_id.standard_price
