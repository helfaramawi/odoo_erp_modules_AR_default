# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError
from datetime import date, timedelta


class SlowMovingReport(models.Model):
    """
    بيان المخزون الراكد — FR-I6
    الأصناف التي لم تتحرك خلال فترة محددة
    """
    _name = 'stock.slow.moving.report'
    _description = 'بيان المخزون الراكد'
    _inherit = ['mail.thread']
    _rec_name = 'name'
    _order = 'report_date desc'

    name = fields.Char(
        string='رقم البيان', required=True, copy=False,
        readonly=True, default='/',
    )
    report_date = fields.Date(
        string='تاريخ البيان', required=True,
        default=fields.Date.context_today,
    )
    fiscal_year = fields.Char(
        string='السنة المالية',
        default=lambda self: str(date.today().year),
    )
    warehouse_id = fields.Many2one(
        'stock.warehouse', string='المستودع',
    )
    location_id = fields.Many2one(
        'stock.location', string='الموقع',
        domain="[('usage','=','internal')]",
    )
    threshold_days = fields.Integer(
        string='فترة الركود (يوم)', default=180,
        help='الأصناف التي لم تتحرك خلال هذه الفترة تُعتبر راكدة',
    )
    cutoff_date = fields.Date(
        string='تاريخ الفصل', compute='_compute_cutoff', store=True,
    )

    line_ids = fields.One2many(
        'stock.slow.moving.line', 'report_id', string='الأصناف الراكدة',
    )

    state = fields.Selection([
        ('draft',     'مسودة'),
        ('generated', 'تم التوليد'),
        ('reviewed',  'مراجعة اللجنة'),
        ('submitted', 'مُقدَّم للاعتماد'),
    ], default='draft')

    committee_notes = fields.Text(string='ملاحظات لجنة المخزون')
    total_items = fields.Integer(compute='_compute_totals')
    total_value = fields.Float(compute='_compute_totals', string='إجمالي قيمة الراكد')

    @api.depends('report_date', 'threshold_days')
    def _compute_cutoff(self):
        for rec in self:
            if rec.report_date and rec.threshold_days:
                rec.cutoff_date = rec.report_date - timedelta(days=rec.threshold_days)
            else:
                rec.cutoff_date = False

    @api.depends('line_ids')
    def _compute_totals(self):
        for rec in self:
            rec.total_items = len(rec.line_ids)
            rec.total_value = sum(rec.line_ids.mapped('total_value'))

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', '/') == '/':
                vals['name'] = self.env['ir.sequence'].next_by_code(
                    'stock.slow.moving') or '/'
        return super().create(vals_list)

    def action_generate(self):
        """توليد بيان الأصناف الراكدة تلقائياً من stock.quant"""
        for rec in self:
            if not rec.cutoff_date:
                raise UserError(_('يجب تحديد تاريخ الفصل أولاً'))

            # حذف السطور القديمة
            rec.line_ids.unlink()

            domain = [('location_id.usage', '=', 'internal'), ('quantity', '>', 0)]
            if rec.location_id:
                domain.append(('location_id', '=', rec.location_id.id))
            elif rec.warehouse_id:
                domain.append(('location_id.warehouse_id', '=', rec.warehouse_id.id))

            quants = self.env['stock.quant'].search(domain)
            lines = []
            for quant in quants:
                # آخر حركة للصنف في هذا الموقع
                last_move = self.env['stock.move.line'].search([
                    ('product_id', '=', quant.product_id.id),
                    ('location_dest_id', '=', quant.location_id.id),
                    ('state', '=', 'done'),
                ], order='date desc', limit=1)

                last_move_date = last_move.date.date() if last_move else date(2000, 1, 1)

                if last_move_date <= rec.cutoff_date:
                    days_idle = (rec.report_date - last_move_date).days
                    unit_cost = quant.product_id.standard_price
                    lines.append({
                        'report_id': rec.id,
                        'product_id': quant.product_id.id,
                        'location_id': quant.location_id.id,
                        'qty_on_hand': quant.quantity,
                        'unit_cost': unit_cost,
                        'total_value': quant.quantity * unit_cost,
                        'last_movement_date': last_move_date,
                        'days_idle': days_idle,
                    })

            if lines:
                self.env['stock.slow.moving.line'].create(lines)
            rec.write({'state': 'generated'})
            rec.message_post(body=_(f'تم توليد البيان — {len(lines)} صنف راكد'))
        return True

    def action_review(self):
        self.write({'state': 'reviewed'})
        return True

    def action_submit(self):
        self.write({'state': 'submitted'})
        return True


class SlowMovingLine(models.Model):
    _name = 'stock.slow.moving.line'
    _description = 'بند بيان المخزون الراكد'
    _order = 'days_idle desc'

    report_id = fields.Many2one(
        'stock.slow.moving.report', required=True, ondelete='cascade', index=True,
    )
    product_id = fields.Many2one('product.product', string='الصنف', required=True)
    product_code = fields.Char(related='product_id.default_code', store=True, string='الكود')
    location_id = fields.Many2one('stock.location', string='الموقع')
    qty_on_hand = fields.Float(string='الكمية في المخزن', digits='Product Unit of Measure')
    unit_cost = fields.Float(string='تكلفة الوحدة')
    total_value = fields.Float(string='القيمة الإجمالية')
    last_movement_date = fields.Date(string='تاريخ آخر حركة')
    days_idle = fields.Integer(string='أيام الركود')
    committee_action = fields.Selection([
        ('keep',    'إبقاء في المخزن'),
        ('sell',    'طرح للبيع / مزاد'),
        ('scrap',   'شطب / إتلاف'),
        ('transfer','تحويل لمخزن آخر'),
    ], string='قرار اللجنة')
    notes = fields.Char(string='ملاحظات')
