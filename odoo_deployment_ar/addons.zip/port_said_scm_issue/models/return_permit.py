# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError
from datetime import date


class StockReturnPermit(models.Model):
    """
    إذن الارتجاع — نموذج 8 مخازن
    FR-I3: إرجاع الأصناف غير المستخدمة أو التالفة للمخزن
    """
    _name = 'stock.return.permit'
    _description = 'إذن الارتجاع — نموذج 8 مخازن'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'name'
    _order = 'return_date desc, name desc'

    name = fields.Char(
        string='رقم إذن الارتجاع', required=True, copy=False,
        readonly=True, default='/', tracking=True,
    )
    return_date = fields.Date(
        string='تاريخ الارتجاع', required=True,
        default=fields.Date.context_today, tracking=True,
    )
    fiscal_year = fields.Char(
        default=lambda self: str(date.today().year),
    )

    return_type = fields.Selection([
        ('unused',    'غير مستخدم — لم تستخدم'),
        ('defective', 'معيب / تالف'),
        ('excess',    'زيادة — فائض'),
        ('wrong',     'صنف خاطئ'),
        ('expired',   'منتهي الصلاحية'),
    ], string='سبب الارتجاع', required=True, default='unused', tracking=True)
    return_reason = fields.Text(string='تفاصيل / ملاحظات الارتجاع')

    # ── المُرتجِع ────────────────────────────────────────────────
    returning_dept = fields.Char(
        string='الإدارة / المصلحة المُرتجِعة', required=True, tracking=True,
    )
    returning_employee_id = fields.Many2one(
        'hr.employee', string='الموظف المُرتجِع', tracking=True,
    )
    original_issue_id = fields.Many2one(
        'stock.issue.permit', string='إذن الصرف الأصلي',
        help='إذن الصرف الذي صدرت به هذه الأصناف أصلاً',
    )

    # ── المخزن ───────────────────────────────────────────────────
    warehouse_id = fields.Many2one(
        'stock.warehouse', string='المستودع', required=True, tracking=True,
    )
    location_id = fields.Many2one(
        'stock.location', string='موقع الإرجاع', required=True,
        domain="[('usage','=','internal')]", tracking=True,
    )
    storekeeper_id = fields.Many2one('hr.employee', string='أمين المخزن')

    # ── الأصناف ──────────────────────────────────────────────────
    line_ids = fields.One2many(
        'stock.return.permit.line', 'permit_id',
        string='الأصناف المُرتجَعة',
    )

    # ── لجنة الارتجاع (مطلوبة للأصناف التالفة) ──────────────────
    needs_committee = fields.Boolean(
        string='تحتاج لجنة فحص',
        compute='_compute_needs_committee', store=True,
    )
    committee_chairman_id = fields.Many2one('hr.employee', string='رئيس لجنة الارتجاع')
    committee_member1_id = fields.Many2one('hr.employee', string='عضو اللجنة الأول')
    committee_member2_id = fields.Many2one('hr.employee', string='عضو اللجنة الثاني')
    committee_decision = fields.Text(string='قرار اللجنة')

    # ── التكامل ──────────────────────────────────────────────────
    picking_id = fields.Many2one(
        'stock.picking', string='حركة المخزن', readonly=True,
    )

    # ── الحالة ───────────────────────────────────────────────────
    state = fields.Selection([
        ('draft',     'مسودة'),
        ('submitted', 'مقدم'),
        ('committee', 'في اللجنة'),
        ('approved',  'معتمد'),
        ('posted',    'مرحَّل — تم الارتجاع'),
        ('cancelled', 'ملغي'),
    ], default='draft', tracking=True)

    approved_by = fields.Many2one('res.users', string='معتمد من', readonly=True)
    notes = fields.Text(string='ملاحظات إضافية')

    total_lines = fields.Integer(compute='_compute_totals')
    total_value = fields.Float(compute='_compute_totals')

    @api.depends('return_type')
    def _compute_needs_committee(self):
        for rec in self:
            rec.needs_committee = rec.return_type in ('defective', 'expired')

    @api.depends('line_ids')
    def _compute_totals(self):
        for rec in self:
            rec.total_lines = len(rec.line_ids)
            rec.total_value = sum(rec.line_ids.mapped('total_value'))

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', '/') == '/':
                vals['name'] = self.env['ir.sequence'].next_by_code(
                    'stock.return.permit') or '/'
        return super().create(vals_list)

    def action_submit(self):
        for rec in self:
            if not rec.line_ids:
                raise UserError(_('يجب إضافة صنف واحد على الأقل'))
            next_state = 'committee' if rec.needs_committee else 'submitted'
            rec.write({'state': next_state})
        return True

    def action_committee_done(self):
        for rec in self:
            if not rec.committee_decision:
                raise UserError(_('يجب إدخال قرار اللجنة'))
            rec.write({'state': 'submitted'})
        return True

    def action_approve(self):
        for rec in self:
            rec.write({'state': 'approved', 'approved_by': self.env.user.id})
        return True

    def action_post(self):
        """ترحيل الارتجاع — إنشاء incoming picking للمخزن"""
        for rec in self:
            if rec.state != 'approved':
                raise UserError(_('يجب اعتماد الإذن أولاً'))

            picking_type = self.env['stock.picking.type'].search([
                ('code', '=', 'incoming'),
                ('warehouse_id', '=', rec.warehouse_id.id),
            ], limit=1)
            if not picking_type:
                picking_type = self.env['stock.picking.type'].search([
                    ('code', '=', 'incoming')], limit=1)

            # موقع المصدر = العميل/الإدارة
            src_location = self.env.ref(
                'stock.stock_location_customers', raise_if_not_found=False
            )

            moves = []
            for line in rec.line_ids:
                moves.append((0, 0, {
                    'name': f'ارتجاع: {line.product_id.name}',
                    'product_id': line.product_id.id,
                    'product_uom_qty': line.qty_returned,
                    'product_uom': line.uom_id.id,
                    'location_id': src_location.id if src_location else rec.location_id.id,
                    'location_dest_id': rec.location_id.id,
                }))

            picking = self.env['stock.picking'].create({
                'picking_type_id': picking_type.id,
                'location_id': src_location.id if src_location else rec.location_id.id,
                'location_dest_id': rec.location_id.id,
                'origin': rec.name,
                'move_ids': moves,
            })
            picking.action_confirm()
            rec.write({'state': 'posted', 'picking_id': picking.id})
            rec.message_post(body=_(f'تم الارتجاع — حركة مخزن: {picking.name}'))
        return True

    def action_cancel(self):
        for rec in self:
            if rec.state == 'posted':
                raise UserError(_('لا يمكن إلغاء إذن ارتجاع مرحَّل'))
            rec.write({'state': 'cancelled'})
        return True


class StockReturnPermitLine(models.Model):
    _name = 'stock.return.permit.line'
    _description = 'بند إذن الارتجاع'
    _order = 'sequence, id'

    permit_id = fields.Many2one(
        'stock.return.permit', required=True, ondelete='cascade', index=True,
    )
    sequence = fields.Integer(default=10)
    product_id = fields.Many2one('product.product', string='الصنف', required=True)
    product_code = fields.Char(related='product_id.default_code', store=True)
    uom_id = fields.Many2one(
        'uom.uom', related='product_id.uom_id', store=True, string='الوحدة',
    )
    qty_original = fields.Float(string='الكمية المصروفة أصلاً', digits='Product Unit of Measure')
    qty_returned = fields.Float(
        string='الكمية المُرتجَعة', required=True, digits='Product Unit of Measure',
    )
    unit_price = fields.Float(string='سعر الوحدة')
    total_value = fields.Float(compute='_compute_total', store=True)
    condition = fields.Selection([
        ('good',    'سليم'),
        ('damaged', 'تالف'),
        ('partial', 'جزئي التلف'),
    ], string='الحالة', default='good')
    serial_lot = fields.Char(string='الرقم التسلسلي')
    notes = fields.Char(string='ملاحظات اللجنة')

    @api.depends('qty_returned', 'unit_price')
    def _compute_total(self):
        for line in self:
            line.total_value = line.qty_returned * line.unit_price

    @api.onchange('product_id')
    def _onchange_product(self):
        if self.product_id:
            self.unit_price = self.product_id.standard_price
