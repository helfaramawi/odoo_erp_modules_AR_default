# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from datetime import date


class StockItemCard(models.Model):
    """
    كارت الصنف — سجل حركات الصنف الحكومي
    يجمع كل الحركات الواردة والصادرة لكل صنف في كل موقع
    """
    _name = 'stock.item.card'
    _description = 'كارت الصنف الحكومي'
    _rec_name = 'display_name'
    _auto = False  # View-based / computed

    # نستخدم wizard بدل model عشان التقرير
    pass


class StockItemCardWizard(models.TransientModel):
    """ويزارد استخراج كارت الصنف وتقرير الحركات"""
    _name = 'stock.item.card.wizard'
    _description = 'ويزارد كارت الصنف وحركات المخزن'

    product_id = fields.Many2one('product.product', string='الصنف')
    product_category_id = fields.Many2one(
        'product.category', string='فئة الأصناف',
        help='اترك فارغاً لكل الفئات',
    )
    warehouse_id = fields.Many2one('stock.warehouse', string='المستودع')
    location_id = fields.Many2one(
        'stock.location', string='الموقع',
        domain="[('usage','=','internal')]",
    )
    date_from = fields.Date(
        string='من تاريخ', required=True,
        default=lambda self: date(date.today().year, 1, 1),
    )
    date_to = fields.Date(
        string='إلى تاريخ', required=True,
        default=fields.Date.context_today,
    )
    report_type = fields.Selection([
        ('item_card',   'كارت الصنف التفصيلي'),
        ('movements',   'تقرير حركات المخزن'),
        ('balance',     'بيان الأرصدة'),
        ('slow_moving', 'بيان الراكد'),
    ], string='نوع التقرير', required=True, default='item_card')

    fiscal_year = fields.Char(
        string='السنة المالية',
        default=lambda self: str(date.today().year),
    )

    def _get_stock_moves(self):
        """استخراج حركات المخزن بالمعايير المحددة"""
        domain = [
            ('state', '=', 'done'),
            ('date', '>=', str(self.date_from)),
            ('date', '<=', str(self.date_to) + ' 23:59:59'),
        ]
        if self.product_id:
            domain.append(('product_id', '=', self.product_id.id))
        if self.product_category_id:
            domain.append(('product_id.categ_id', '=', self.product_category_id.id))
        if self.location_id:
            domain += [
                '|',
                ('location_id', '=', self.location_id.id),
                ('location_dest_id', '=', self.location_id.id),
            ]
        elif self.warehouse_id:
            wh_locations = self.env['stock.location'].search([
                ('warehouse_id', '=', self.warehouse_id.id),
            ])
            if wh_locations:
                domain += [
                    '|',
                    ('location_id', 'in', wh_locations.ids),
                    ('location_dest_id', 'in', wh_locations.ids),
                ]
        return self.env['stock.move'].search(domain, order='date asc')

    def action_print_item_card(self):
        return self.env.ref(
            'port_said_scm_issue.action_rpt_item_card'
        ).report_action(self)

    def action_print_movements(self):
        return self.env.ref(
            'port_said_scm_issue.action_rpt_stock_movements'
        ).report_action(self)
