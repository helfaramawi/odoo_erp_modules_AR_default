# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class ProcurementTenderWorks(models.Model):
    _inherit = 'procurement.tender'

    works_type = fields.Selection(
        selection_add=[('contracting', 'أعمال مقاولات')],
    )
    award_id = fields.Many2one(
        'subcontract.award', string='أمر الإسناد',
        readonly=True, copy=False,
    )

    def action_contract(self):
        self.ensure_one()
        if self.works_type == 'contracting':
            if not self.partner_id:
                raise UserError(_('يجب تحديد المقاول الفائز.'))
            award = self.env['subcontract.award'].create({
                'tender_id':          self.id,
                'partner_id':         self.partner_id.id,
                'is_sovereign':       self.partner_id.jihat_siyadiya,
                'jihat_code':         self.jihat_code or '',
                'works_description':  self.description,
                'works_location':     '',
                'contract_value':     self.amount_estimate,
            })
            self.award_id = award
            self.date_contract = fields.Date.today()
            self.state = 'contract'
        else:
            return super().action_contract()


class ResPartnerWorks(models.Model):
    _inherit = 'res.partner'

    is_contractor = fields.Boolean(
        string='Contractor (مقاول)', default=False,
    )
    contractor_grade = fields.Selection([
        ('first',  'الدرجة الأولى'),
        ('second', 'الدرجة الثانية'),
        ('third',  'الدرجة الثالثة'),
    ], string='Contractor Grade')
