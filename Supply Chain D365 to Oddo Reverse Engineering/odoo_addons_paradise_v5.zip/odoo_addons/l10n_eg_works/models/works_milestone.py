# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class WorksMilestone(models.Model):
    _name = 'works.milestone'
    _description = 'Works Progress Milestone — مرحلة تنفيذ'
    _order = 'award_id, sequence'

    award_id = fields.Many2one(
        'subcontract.award', required=True, ondelete='cascade', index=True,
    )
    name = fields.Char(string='Milestone (Arabic)', required=True)
    sequence = fields.Integer(default=10)
    currency_id = fields.Many2one(related='award_id.currency_id')
    planned_value = fields.Monetary(
        string='Planned Payment (EGP)', required=True,
        currency_field='currency_id',
    )
    planned_date  = fields.Date(string='Target Date', required=True)
    actual_date   = fields.Date(string='Actual Completion Date')
    completion_pct = fields.Float(
        string='Completion %', digits=(5, 1),
        help='0.0 to 100.0',
    )
    state = fields.Selection([
        ('pending',        'Pending — معلق'),
        ('submitted',      'Submitted — مقدم'),
        ('approved',       'Approved — معتمد'),
        ('payment_issued', 'Payment Issued — صرف الدفعة'),
    ], default='pending', index=True)
    site_inspector_id = fields.Many2one(
        'res.users', string='Site Inspector (المشرف الفني)',
    )
    approval_date = fields.Date(string='Approval Date', readonly=True)
    payment_ref   = fields.Char(string='Payment Certificate Reference')

    def action_approve(self):
        self.ensure_one()
        self.state = 'approved'
        self.approval_date = fields.Date.today()

    def action_print_certificate(self):
        return self.env.ref(
            'l10n_eg_works.report_milestone_cert').report_action(self)
