# -*- coding: utf-8 -*-
from . import subcontract_award
from . import works_milestone
from . import procurement_tender
from . import res_partner
