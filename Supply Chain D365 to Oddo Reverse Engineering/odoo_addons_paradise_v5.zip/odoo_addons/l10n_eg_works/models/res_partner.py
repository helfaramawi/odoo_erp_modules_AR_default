# -*- coding: utf-8 -*-
# res_partner fields are defined in procurement_tender.py for C-PR05
