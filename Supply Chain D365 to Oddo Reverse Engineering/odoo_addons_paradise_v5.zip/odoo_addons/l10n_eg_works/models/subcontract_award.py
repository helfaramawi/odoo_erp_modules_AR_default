# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError

THRESHOLD_DEPUTY   = 50_000.0
THRESHOLD_GOVERNOR = 500_000.0


class SubcontractAward(models.Model):
    _name = 'subcontract.award'
    _description = 'Works Assignment Order — أمر الإسناد'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name desc'

    name = fields.Char(
        required=True, copy=False, readonly=True,
        default=lambda self: _('New'), tracking=True, index=True,
    )
    tender_id = fields.Many2one(
        'procurement.tender', string='Source Tender',
        tracking=True, copy=False, index=True,
    )
    partner_id = fields.Many2one(
        'res.partner', string='Contractor (المقاول)',
        required=True, tracking=True, index=True,
    )

    # Sovereign entity fields
    is_sovereign = fields.Boolean(
        string='Sovereign Entity (جهة سيادية)', tracking=True,
    )
    jihat_code = fields.Char(
        string='رمز الجهة السيادية', size=20,
    )

    # Works details
    works_description = fields.Text(
        string='Works Description (Arabic)', required=True,
    )
    works_location = fields.Char(
        string='Works Location', required=True,
    )
    currency_id = fields.Many2one(
        'res.currency',
        default=lambda self: self.env.ref('base.EGP', raise_if_not_found=False),
    )
    contract_value = fields.Monetary(
        string='Contract Value (EGP)',
        required=True, currency_field='currency_id', tracking=True,
    )
    performance_bond_value = fields.Monetary(
        string='Performance Bond (ضمان التنفيذ)',
        currency_field='currency_id',
    )
    performance_bond_ref = fields.Char(
        string='Bond Reference Number',
    )
    start_date = fields.Date(string='Works Start Date')
    end_date   = fields.Date(string='Contracted Completion Date')

    state = fields.Selection([
        ('draft',       'Draft — مسودة'),
        ('issued',      'Issued — صادر'),
        ('in_progress', 'In Progress — جاري التنفيذ'),
        ('completed',   'Completed — مكتمل'),
        ('closed',      'Closed — مغلق'),
        ('terminated',  'Terminated — موقوف'),
    ], default='draft', tracking=True, index=True)

    milestone_ids = fields.One2many(
        'works.milestone', 'award_id', string='Milestones',
    )
    authority_level = fields.Selection([
        ('dept_head',       'مدير الإدارة'),
        ('deputy_governor', 'نائب المحافظ'),
        ('governor',        'المحافظ'),
    ], compute='_compute_authority', store=True)

    # ── Computed ──────────────────────────────────────────────────────────
    @api.depends('contract_value')
    def _compute_authority(self):
        for rec in self:
            if rec.contract_value < THRESHOLD_DEPUTY:
                rec.authority_level = 'dept_head'
            elif rec.contract_value < THRESHOLD_GOVERNOR:
                rec.authority_level = 'deputy_governor'
            else:
                rec.authority_level = 'governor'

    # ── Constraints ────────────────────────────────────────────────────────
    @api.constrains('is_sovereign', 'jihat_code', 'partner_id')
    def _validate_sovereign(self):
        for rec in self:
            if rec.is_sovereign:
                if not rec.jihat_code:
                    raise ValidationError(_(
                        'رمز الجهة السيادية مطلوب للعقود مع الجهات السيادية.'
                    ))
                if not rec.partner_id.jihat_siyadiya:
                    raise ValidationError(_(
                        'المقاول المحدد ليس جهة سيادية.\n'
                        'يجب تفعيل خاصية الجهة السيادية على سجل المقاول.'
                    ))

    # ── State actions ──────────────────────────────────────────────────────
    def action_issue(self):
        self.ensure_one()
        if not self.milestone_ids:
            raise UserError(_(
                'يجب إضافة مراحل التنفيذ قبل إصدار أمر الإسناد.'
            ))
        if self.state != 'draft':
            raise UserError(_('يمكن إصدار أمر الإسناد من حالة المسودة فقط.'))
        self.name = (
            self.env['ir.sequence'].next_by_code('subcontract.award')
            or self.name
        )
        self.state = 'issued'
        # Log to C13 audit trail if available
        try:
            self.env['audit.log'].sudo().create({
                'model_name':  self._name,
                'record_id':   self.id,
                'record_ref':  self.name,
                'action':      'issued',
                'amount':      self.contract_value,
                'is_sovereign': self.is_sovereign,
                'notes':       'أمر الإسناد: ' + self.name,
            })
        except Exception:
            pass  # C13 not installed — skip

    def action_start(self):
        self.ensure_one()
        self.state = 'in_progress'

    def action_complete(self):
        self.ensure_one()
        self.state = 'completed'

    def action_print_isnad(self):
        return self.env.ref(
            'l10n_eg_works.report_isnad_order').report_action(self)

    # ── Helpers ────────────────────────────────────────────────────────────
    def _get_authority_title(self):
        titles = {
            'dept_head':       'مدير الإدارة المختصة',
            'deputy_governor': 'نائب المحافظ',
            'governor':        'المحافظ',
        }
        return titles.get(self.authority_level, 'المدير العام')

    def _get_hijri_date(self):
        try:
            from hijri_converter import convert  # noqa
            d = fields.Date.today()
            h = convert.Gregorian(d.year, d.month, d.day).to_hijri()
            return '%d/%d/%d هـ' % (h.day, h.month, h.year)
        except ImportError:
            return ''

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = _('New')  # Assigned on action_issue()
        return super().create(vals_list)
