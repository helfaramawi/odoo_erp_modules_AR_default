# -*- coding: utf-8 -*-
{
    'name': 'Contracting Works + Sovereign Entity (C-PR05)',
    'version': '17.0.1.0.0',
    'summary': 'Works contracting: أمر الإسناد, عقد التنفيذ, milestones, PR-07 sovereign entity bypass',
    'author': 'Paradise Integrated Solutions',
    'license': 'LGPL-3',
    'category': 'Purchase',
    'depends': [
        'l10n_eg_tender',
        'l10n_eg_tender_public',
        'purchase', 'account', 'hr',
    ],
    'data': [
        'security/ir.model.access.csv',
        'data/sequences.xml',
        'views/subcontract_award_views.xml',
        'views/works_milestone_views.xml',
        'views/tender_views_inherit.xml',
        'views/menu_inherit.xml',
        'report/report_isnad_order.xml',
        'report/report_milestone_cert.xml',
        'report/report_actions.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
