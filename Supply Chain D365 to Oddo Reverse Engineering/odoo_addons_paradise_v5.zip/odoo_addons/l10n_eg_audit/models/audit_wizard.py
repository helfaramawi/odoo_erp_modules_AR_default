# -*- coding: utf-8 -*-
from odoo import models, fields, api, _


class AuditExportWizard(models.TransientModel):
    _name = 'audit.export.wizard'
    _description = 'Audit Trail Export Wizard — تصدير سجل المراجعة'

    date_from = fields.Date(
        string='From Date',
        required=True,
        default=lambda self: fields.Date.today().replace(day=1),
    )
    date_to = fields.Date(
        string='To Date',
        required=True,
        default=fields.Date.today,
    )
    model_name = fields.Selection([
        ('all',                  'All Models — جميع النماذج'),
        ('procurement.tender',   'Tenders — المناقصات'),
        ('subcontract.award',    'Works Assignments — أوامر الإسناد'),
        ('commitment.line',      'Commitments — الالتزامات'),
        ('purchase.order',       'Purchase Orders — أوامر الشراء'),
        ('account.move',         'Journal Entries — القيود المحاسبية'),
        ('custody.move',         'Personal Custody — العهدة الشخصية'),
        ('payment.schedule',     'Payment Schedules — جداول الصرف'),
        ('customs.clearance',    'Customs Clearance — التخليص الجمركي'),
    ], default='all', string='Filter by Model')

    user_id = fields.Many2one(
        'res.users', string='Filter by User',
    )
    is_sovereign_only = fields.Boolean(
        string='Sovereign Entity Actions Only',
        help='Filter to show only PR-07 sovereign entity transactions.',
    )
    include_financial = fields.Boolean(
        string='Include Financial Amount',
        default=True,
    )

    def _get_audit_records(self):
        domain = [
            ('timestamp', '>=', fields.Datetime.from_string(
                str(self.date_from) + ' 00:00:00')),
            ('timestamp', '<=', fields.Datetime.from_string(
                str(self.date_to) + ' 23:59:59')),
        ]
        if self.model_name != 'all':
            domain.append(('model_name', '=', self.model_name))
        if self.user_id:
            domain.append(('user_id', '=', self.user_id.id))
        if self.is_sovereign_only:
            domain.append(('is_sovereign', '=', True))

        return self.env['audit.log'].search(domain, order='timestamp desc')

    def action_export_pdf(self):
        return self.env.ref(
            'l10n_eg_audit.report_audit_export',
        ).report_action(self)

    def action_export_xlsx(self):
        """Export audit trail to Excel — basic CSV fallback."""
        records = self._get_audit_records()
        lines = [
            'Timestamp,Model,Reference,Action,User,Amount,Sovereign,Notes'
        ]
        for rec in records:
            lines.append(','.join([
                str(rec.timestamp),
                rec.model_label or rec.model_name,
                rec.record_ref or '',
                rec.action_label or rec.action,
                rec.user_id.name,
                '%.2f' % rec.amount if rec.amount else '0',
                'Yes' if rec.is_sovereign else 'No',
                (rec.notes or '').replace(',', ';'),
            ]))
        import base64
        csv_content = '\n'.join(lines).encode('utf-8-sig')  # BOM for Excel Arabic
        attachment = self.env['ir.attachment'].create({
            'name':     'audit_trail_%s_%s.csv' % (self.date_from, self.date_to),
            'type':     'binary',
            'datas':    base64.b64encode(csv_content),
            'mimetype': 'text/csv',
        })
        return {
            'type': 'ir.actions.act_url',
            'url':  '/web/content/%d?download=true' % attachment.id,
            'target': 'self',
        }
