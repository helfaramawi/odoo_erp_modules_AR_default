# -*- coding: utf-8 -*-
from odoo import models, fields, api, _


class AuditMixin(models.AbstractModel):
    """
    Mixin to add standardised audit logging to any model.

    Usage — inherit this in any model that needs audit logging:

        class ProcurementTender(models.Model):
            _inherit = ['procurement.tender', 'audit.mixin']

    Then call _log_audit() in state transition methods:

        def action_award(self):
            old_state = self.state
            # ... existing logic ...
            self._log_audit(
                action='state_changed',
                old_val=old_state,
                new_val='award',
                amount=self.amount_estimate,
                is_sovereign=self.jihat_siyadiya,
            )
    """
    _name = 'audit.mixin'
    _description = 'Audit Trail Mixin'

    def _log_audit(self, action, old_val=None, new_val=None,
                   amount=None, is_sovereign=False, notes=None,
                   action_label=None):
        """
        Log an audit event for this record.
        Silently skips if C13 is not installed (audit.log model not found).

        :param action: Selection value from audit.log.action
        :param old_val: Previous state/value (any, converted to str)
        :param new_val: New state/value (any, converted to str)
        :param amount: Financial amount involved (EGP)
        :param is_sovereign: True if sovereign entity (PR-07) involved
        :param notes: Additional Arabic context
        :param action_label: Arabic action label
        """
        self.ensure_one()
        if 'audit.log' not in self.env:
            return  # C13 not installed — skip silently

        record_ref = None
        for field_name in ('name', 'display_name'):
            try:
                record_ref = getattr(self, field_name, None)
                if record_ref:
                    break
            except Exception:
                pass

        try:
            self.env['audit.log'].log(
                model_name=self._name,
                record_id=self.id,
                action=action,
                record_ref=str(record_ref) if record_ref else str(self.id),
                model_label=self._description,
                old_val=old_val,
                new_val=new_val,
                amount=amount,
                is_sovereign=is_sovereign,
                notes=notes,
                action_label=action_label,
            )
        except Exception:
            pass  # Never let audit logging break the main workflow
