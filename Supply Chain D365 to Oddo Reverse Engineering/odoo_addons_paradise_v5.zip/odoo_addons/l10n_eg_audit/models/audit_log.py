# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import AccessError


class AuditLog(models.Model):
    _name = 'audit.log'
    _description = 'Audit Trail — سجل المراجعة الشامل'
    _order = 'timestamp desc'
    _rec_name = 'record_ref'

    # ── Identity ──────────────────────────────────────────────────────────
    model_name = fields.Char(
        string='Model Name',
        required=True,
        index=True,
        help='Odoo model name e.g. procurement.tender',
    )
    model_label = fields.Char(
        string='Arabic Model Label',
        help='Human-readable Arabic name e.g. مناقصة حكومية',
    )
    record_id = fields.Integer(
        string='Record ID',
        required=True,
        index=True,
    )
    record_ref = fields.Char(
        string='Record Reference',
        index=True,
        help='Human-readable reference e.g. PR/2025/0001',
    )

    # ── Action ────────────────────────────────────────────────────────────
    action = fields.Selection([
        ('created',        'Created — تم الإنشاء'),
        ('state_changed',  'State Changed — تغيير الحالة'),
        ('approved',       'Approved — اعتماد'),
        ('cancelled',      'Cancelled — إلغاء'),
        ('issued',         'Issued — إصدار'),
        ('amount_changed', 'Amount Changed — تغيير المبلغ'),
        ('deleted',        'Deleted — حذف'),
        ('login',          'Login — تسجيل دخول'),
        ('override',       'Budget Override — تجاوز الميزانية'),
    ], required=True, index=True, string='Action')

    action_label = fields.Char(
        string='Action Label (Arabic)',
    )
    old_value = fields.Text(string='Old Value')
    new_value = fields.Text(string='New Value')

    # ── Who / When ────────────────────────────────────────────────────────
    user_id = fields.Many2one(
        'res.users',
        string='User',
        required=True,
        default=lambda self: self.env.uid,
        index=True,
        ondelete='restrict',
    )
    timestamp = fields.Datetime(
        string='Timestamp (UTC)',
        required=True,
        default=fields.Datetime.now,
        index=True,
    )
    ip_address = fields.Char(
        string='IP Address',
        size=45,
    )

    # ── Context ───────────────────────────────────────────────────────────
    is_sovereign = fields.Boolean(
        string='Sovereign Entity Action',
        default=False,
        index=True,
        help='True when action involves a sovereign entity (PR-07). '
             'Extra detail logged for الهيئة العامة للرقابة المالية.',
    )
    currency_id = fields.Many2one(
        'res.currency',
        default=lambda self: self.env.ref('base.EGP', raise_if_not_found=False),
    )
    amount = fields.Monetary(
        string='Financial Amount (EGP)',
        currency_field='currency_id',
    )
    notes = fields.Text(string='Additional Notes')

    # ── IMMUTABILITY — core security feature ──────────────────────────────
    def write(self, vals):
        raise AccessError(_(
            'سجلات المراجعة لا يمكن تعديلها.\n'
            'Audit log records are immutable and cannot be modified.'
        ))

    def unlink(self):
        raise AccessError(_(
            'سجلات المراجعة لا يمكن حذفها.\n'
            'Audit log records cannot be deleted.'
        ))

    # ── Convenience factory ───────────────────────────────────────────────
    @api.model
    def log(self, model_name, record_id, action,
            record_ref=None, model_label=None, old_val=None, new_val=None,
            amount=None, is_sovereign=False, notes=None, action_label=None):
        """
        Convenience factory — call this from any model to log an audit event.

        Usage:
            self.env['audit.log'].log(
                model_name='procurement.tender',
                record_id=self.id,
                action='state_changed',
                record_ref=self.name,
                new_val=self.state,
                amount=self.amount_estimate,
            )
        """
        vals = {
            'model_name':   model_name,
            'record_id':    record_id,
            'action':       action,
            'record_ref':   record_ref,
            'model_label':  model_label,
            'old_value':    str(old_val) if old_val is not None else None,
            'new_value':    str(new_val) if new_val is not None else None,
            'user_id':      self.env.uid,
            'timestamp':    fields.Datetime.now(),
            'is_sovereign': is_sovereign,
            'amount':       amount or 0.0,
            'notes':        notes,
            'action_label': action_label,
        }
        # Use sudo() so even restricted users can create audit entries
        return self.sudo().create(vals)
