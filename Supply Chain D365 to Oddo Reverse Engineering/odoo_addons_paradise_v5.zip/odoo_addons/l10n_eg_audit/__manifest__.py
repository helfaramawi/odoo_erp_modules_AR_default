# -*- coding: utf-8 -*-
{
    'name': 'Audit Trail — سجل المراجعة (C13)',
    'version': '17.0.1.0.0',
    'summary': 'Tamper-evident audit log for الهيئة العامة للرقابة المالية — covers all key models',
    'description': """
        C13 AuditTrail
        ==============
        Centralised, tamper-evident audit log covering all key state changes
        across the procurement and finance system.

        Mandatory regulatory requirement from الهيئة العامة للرقابة المالية.

        Features:
        - audit.log model: immutable after creation (write/unlink raise AccessError)
        - AuditMixin abstract model: _log_audit() helper called by all other modules
        - Arabic PDF export report for GFCA submission
        - Covers 8 key models: procurement.tender, subcontract.award,
          commitment.line, purchase.order, account.move, custody.move,
          payment.schedule, customs.clearance

        INSTALL ORDER: First — depends only on base and mail.
        All other custom modules call _log_audit() on C13, not the reverse.
        This prevents circular dependencies.

        FRD: Finance Module C13
        Client: الديوان العام لمحافظة بورسعيد
        Delivered by: Paradise Integrated Solutions
    """,
    'author': 'Paradise Integrated Solutions',
    'license': 'LGPL-3',
    'category': 'Accounting',
    'depends': ['base', 'mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/audit_log_views.xml',
        'views/audit_wizard_views.xml',
        'report/report_audit_export.xml',
        'report/report_actions.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
