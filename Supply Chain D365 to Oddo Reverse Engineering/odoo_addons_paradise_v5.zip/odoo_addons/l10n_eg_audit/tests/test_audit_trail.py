# -*- coding: utf-8 -*-
from odoo.tests.common import TransactionCase
from odoo.exceptions import AccessError


class TestAuditTrail(TransactionCase):
    """5 unit tests for C13 AuditTrail."""

    def test_01_audit_log_created_via_factory(self):
        """TC-01: log() factory creates audit record correctly."""
        rec = self.env['audit.log'].log(
            model_name='procurement.tender',
            record_id=1,
            action='state_changed',
            record_ref='PR/2025/0001',
            model_label='مناقصة حكومية',
            new_val='award',
            amount=100000,
            is_sovereign=False,
        )
        self.assertTrue(rec, 'Audit log record should be created')
        self.assertEqual(rec.model_name, 'procurement.tender')
        self.assertEqual(rec.action, 'state_changed')
        self.assertEqual(rec.record_ref, 'PR/2025/0001')
        self.assertAlmostEqual(rec.amount, 100000.0)

    def test_02_audit_log_immutable_write(self):
        """TC-02: write() on audit.log raises AccessError."""
        rec = self.env['audit.log'].log(
            model_name='test.model', record_id=1, action='created',
        )
        with self.assertRaises(AccessError) as ctx:
            rec.write({'notes': 'tampered'})
        self.assertIn('لا يمكن تعديلها', str(ctx.exception))

    def test_03_audit_log_immutable_unlink(self):
        """TC-03: unlink() on audit.log raises AccessError."""
        rec = self.env['audit.log'].log(
            model_name='test.model', record_id=2, action='created',
        )
        with self.assertRaises(AccessError) as ctx:
            rec.unlink()
        self.assertIn('لا يمكن حذفها', str(ctx.exception))

    def test_04_sovereign_flag_logged(self):
        """TC-04: is_sovereign=True is preserved on audit record."""
        rec = self.env['audit.log'].log(
            model_name='subcontract.award',
            record_id=99,
            action='issued',
            amount=600000,
            is_sovereign=True,
            notes='جهة سيادية — رمز الجهة: GOV-001',
        )
        self.assertTrue(rec.is_sovereign)
        self.assertIn('GOV-001', rec.notes or '')

    def test_05_wizard_get_audit_records(self):
        """TC-05: Wizard _get_audit_records filters by date correctly."""
        # Create a record
        self.env['audit.log'].log(
            model_name='commitment.line', record_id=10, action='created',
        )
        wizard = self.env['audit.export.wizard'].create({
            'date_from': '2020-01-01',
            'date_to':   '2099-12-31',
            'model_name': 'all',
        })
        records = wizard._get_audit_records()
        self.assertTrue(len(records) >= 1, 'Should find at least 1 audit record')
