# -*- coding: utf-8 -*-
from odoo import models, fields, _
from odoo.exceptions import UserError


class DirectOrderCommittee(models.Model):
    _name = 'direct.order.committee'
    _description = 'Direct Order Simplified Committee — لجنة الأمر المباشر'
    _rec_name = 'purchase_order_id'

    purchase_order_id = fields.Many2one(
        'purchase.order',
        string='Purchase Order',
        required=True,
        ondelete='cascade',
        index=True,
    )
    formation_date = fields.Date(
        string='Committee Formation Date',
        required=True,
        default=fields.Date.today,
    )
    chairman_id = fields.Many2one(
        'res.users',
        string='Chairman (رئيس اللجنة)',
        required=True,
    )
    member_ids = fields.Many2many(
        'res.users',
        'direct_committee_member_rel',
        'committee_id', 'user_id',
        string='Committee Members',
    )
    decision_text = fields.Text(
        string='Committee Decision (Arabic)',
        required=True,
        help='Formal Arabic decision text — printed on قرار اللجنة المبسط.',
    )
    inspection_result = fields.Selection([
        ('approved',               'مقبول — Approved'),
        ('conditionally_approved', 'مقبول بشروط — Conditionally Approved'),
        ('rejected',               'مرفوض — Rejected'),
    ], required=True, string='Inspection Result')

    inspection_notes = fields.Text(
        string='Inspection Notes (Arabic)',
        help='Technical inspection notes — printed on محضر الفحص الفني.',
    )

    # ── Print actions ──────────────────────────────────────────────────────
    def action_print_inspection_minutes(self):
        self.ensure_one()
        report = self.env.ref(
            'l10n_eg_direct.report_inspection_minutes',
            raise_if_not_found=False,
        )
        if not report:
            raise UserError(_('تعذر العثور على نموذج محضر الفحص الفني.'))
        return report.report_action(self)

    def action_print_committee_decision(self):
        self.ensure_one()
        report = self.env.ref(
            'l10n_eg_direct.report_simple_committee',
            raise_if_not_found=False,
        )
        if not report:
            raise UserError(_('تعذر العثور على نموذج قرار اللجنة.'))
        return report.report_action(self)
