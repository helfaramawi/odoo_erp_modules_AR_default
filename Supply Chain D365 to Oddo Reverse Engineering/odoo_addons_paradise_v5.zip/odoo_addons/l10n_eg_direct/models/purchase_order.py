# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class PurchaseOrderDirect(models.Model):
    _inherit = 'purchase.order'

    # ── Direct order fields ───────────────────────────────────────────────
    is_direct_order = fields.Boolean(
        string='Direct Order (أمر مباشر)',
        default=False,
        help='Activates استمارة 50 and محضر الفحص الفني print buttons on this PO.',
    )
    direct_order_reason = fields.Selection([
        ('emergency',          'حالة الضرورة / الطوارئ'),
        ('single_supplier',    'مورد وحيد / مورد حصري'),
        ('small_value',        'قيمة صغيرة دون الحد المقرر'),
        ('gov_entity',         'جهة حكومية / هيئة عامة'),
        ('contract_extension', 'تمديد عقد قائم'),
    ], string='Direct Order Justification',
       help='Mandatory reason for using direct order. Printed on استمارة 50.')

    direct_order_reason_text = fields.Text(
        string='Justification Details (Arabic)',
        help='Free-text elaboration of the justification. Printed on استمارة 50.',
    )
    simple_committee_id = fields.Many2one(
        'direct.order.committee',
        string='Technical Inspection Committee',
        copy=False,
    )
    inspection_date = fields.Date(
        string='Inspection Date',
        help='Date goods/services were physically inspected by the committee.',
    )
    form_50_ref = fields.Char(
        string='استمارة 50 Reference',
        copy=False,
        readonly=True,
        help='Auto-generated from ir.sequence on first print: FORM50/YYYY/NNNN',
    )

    # ── Validation on approve ──────────────────────────────────────────────
    def button_approve(self, force=False):
        for order in self:
            if order.is_direct_order and not order.direct_order_reason:
                raise UserError(_(
                    'يجب تحديد مبرر الأمر المباشر قبل اعتماد أمر الشراء.\n'
                    'الحقل: "مبرر الأمر المباشر"'
                ))
        return super().button_approve(force=force)

    # ── Print استمارة 50 ──────────────────────────────────────────────────
    def action_print_form_50(self):
        self.ensure_one()
        if not self.is_direct_order:
            raise UserError(_(
                'هذا الأمر ليس أمراً مباشراً.\n'
                'استمارة صرف 50 ع.ح متاحة فقط للأوامر المباشرة.'
            ))
        # Auto-assign form_50_ref on first print
        if not self.form_50_ref:
            self.form_50_ref = (
                self.env['ir.sequence'].next_by_code('direct.order.form50')
                or self.name
            )
        return self.env.ref(
            'l10n_eg_direct.report_form_50',
            raise_if_not_found=False,
        ).report_action(self)

    # ── Arabic amount helper ──────────────────────────────────────────────
    def _amount_in_words_ar(self):
        """Return total amount in Arabic words for استمارة 50."""
        try:
            from num2words import num2words  # noqa
            return num2words(
                self.amount_total, lang='ar',
                to='currency', currency='EGP',
            )
        except (ImportError, NotImplementedError):
            return '%.2f جنيه مصري' % self.amount_total

    # ── Authority title ───────────────────────────────────────────────────
    def _get_authority_title(self):
        if self.amount_total < 50_000:
            return 'مدير الإدارة المختصة'
        elif self.amount_total < 500_000:
            return 'نائب المحافظ'
        else:
            return 'المحافظ'

    # ── Hijri date helper ─────────────────────────────────────────────────
    def _get_hijri_date(self):
        try:
            from hijri_converter import convert  # noqa
            d = fields.Date.today()
            h = convert.Gregorian(d.year, d.month, d.day).to_hijri()
            return '%d/%d/%d هـ' % (h.day, h.month, h.year)
        except ImportError:
            return ''

    # ── Available budget helper for استمارة 50 ───────────────────────────
    def _get_available_budget(self):
        """Returns remaining budget on the analytic account for this PO."""
        if not self.account_analytic_id:
            return 0.0
        budget_line = self.env['crossovered.budget.lines'].search([
            ('analytic_account_id', '=', self.account_analytic_id.id),
            ('date_from', '<=', fields.Date.today()),
            ('date_to', '>=', fields.Date.today()),
        ], limit=1)
        if not budget_line:
            return 0.0
        return getattr(budget_line, 'available_amount', 0.0)
