# -*- coding: utf-8 -*-
{
    'name': 'Direct Order Templates — الأمر المباشر (C-PR04)',
    'version': '17.0.1.0.0',
    'summary': 'Direct order prints: استمارة 50 ع.ح, محضر الفحص الفني, قرار اللجنة المبسط',
    'description': """
        C-PR04 DirectOrderTemplates
        ============================
        Print-template module for government direct order procurement.
        Adds 3 mandatory Arabic document templates to purchase.order:

        1. استمارة صرف 50 ع.ح — disbursement form (required before payment)
        2. محضر الفحص الفني — technical inspection committee minutes
        3. قرار اللجنة المبسط — simplified committee decision

        Also introduces:
        - direct.order.committee lightweight model
        - direct_order_reason field with 5 justification types
        - form_50_ref auto-sequence: FORM50/YYYY/NNNN
        - num2words Arabic amount-in-words helper
        - _get_authority_title() based on amount thresholds

        NOTE: C-PR04 does NOT depend on C-PR02/C-PR03.
        Direct orders use purchase.order directly, bypassing the tender pipeline.

        FRD: PR-04 الطرح بوسيلة الأمر المباشر
        Client: الديوان العام لمحافظة بورسعيد
        Delivered by: Paradise Integrated Solutions
    """,
    'author': 'Paradise Integrated Solutions',
    'license': 'LGPL-3',
    'category': 'Purchase',
    'depends': [
        'l10n_eg_tender',   # C-PR01 — for base QWeb template and Hijri helpers
        'purchase',
        'account',
    ],
    # NOTE: intentionally NOT depending on l10n_eg_tender_public (C-PR02/03)
    'data': [
        'security/ir.model.access.csv',
        'data/sequences.xml',
        'views/purchase_order_views.xml',
        'views/direct_committee_views.xml',
        'report/report_form_50.xml',
        'report/report_inspection_minutes.xml',
        'report/report_simple_committee.xml',
        'report/report_actions.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
