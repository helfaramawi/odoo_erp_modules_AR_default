# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class TenderNegotiation(models.Model):
    _name = 'tender.negotiation'
    _description = 'Negotiation Session — جلسة التفاوض (الممارسة)'
    _order = 'tender_id, partner_id, session_number'

    tender_id = fields.Many2one(
        'procurement.tender', required=True,
        ondelete='cascade', index=True,
    )
    partner_id = fields.Many2one(
        'res.partner', string='Vendor', required=True,
    )
    bid_id = fields.Many2one(
        'bid.envelope', string='Vendor Bid',
        required=True, index=True,
    )
    session_number = fields.Integer(
        string='Session Number', required=True, default=1,
    )
    session_date = fields.Datetime(
        string='Session Date & Time', required=True,
    )
    committee_members = fields.Many2many(
        'res.users',
        'negotiation_member_rel',
        'negotiation_id', 'user_id',
        string='Negotiation Committee',
    )
    currency_id = fields.Many2one(related='tender_id.currency_id')
    initial_price = fields.Monetary(
        string='Initial Bid Price (EGP)',
        currency_field='currency_id',
    )
    negotiated_price = fields.Monetary(
        string='Negotiated Price (EGP)',
        currency_field='currency_id',
    )
    price_reduction_pct = fields.Float(
        compute='_compute_reduction', store=True,
        string='Price Reduction %', digits=(5, 2),
    )
    negotiation_notes = fields.Text(
        string='Negotiation Notes (Arabic)',
    )
    outcome = fields.Selection([
        ('agreement_reached', 'تم الاتفاق — Agreement Reached'),
        ('no_agreement',      'لم يتم الاتفاق — No Agreement'),
        ('vendor_withdrew',   'انسحب المورد — Vendor Withdrew'),
    ], string='Negotiation Outcome')

    state = fields.Selection([
        ('scheduled',   'Scheduled — مجدول'),
        ('in_progress', 'In Progress — جارٍ'),
        ('completed',   'Completed — مكتمل'),
        ('cancelled',   'Cancelled — ملغى'),
    ], default='scheduled', index=True)

    minutes_doc_id = fields.Many2one(
        'procurement.document',
        string='Minutes Document',
        readonly=True, copy=False,
    )

    # ── Computed ──────────────────────────────────────────────────────────
    @api.depends('initial_price', 'negotiated_price')
    def _compute_reduction(self):
        for rec in self:
            if rec.initial_price and rec.negotiated_price:
                rec.price_reduction_pct = (
                    (rec.initial_price - rec.negotiated_price)
                    / rec.initial_price * 100
                )
            else:
                rec.price_reduction_pct = 0.0

    # ── Constraints ────────────────────────────────────────────────────────
    @api.constrains('bid_id')
    def _check_bid_qualified(self):
        for rec in self:
            if not rec.bid_id.technical_qualified:
                raise ValidationError(_(
                    'لا يمكن إجراء تفاوض مع مورد لم يجتاز البت الفني.\n'
                    'المورد: %(vendor)s',
                    vendor=rec.partner_id.name,
                ))

    # ── Complete session ───────────────────────────────────────────────────
    def action_complete(self):
        self.ensure_one()
        if not self.outcome:
            raise UserError(_(
                'يجب تحديد نتيجة جلسة التفاوض قبل إغلاقها.'
            ))
        if self.outcome == 'agreement_reached' and not self.negotiated_price:
            raise UserError(_(
                'يجب إدخال السعر المتفق عليه عند اختيار "تم الاتفاق".'
            ))
        self.state = 'completed'

        # Write negotiated price back to bid envelope
        if self.outcome == 'agreement_reached':
            self.bid_id.financial_amount = self.negotiated_price
        elif self.outcome == 'vendor_withdrew':
            self.bid_id.state = 'rejected'

        # Auto-generate minutes document
        try:
            report = self.env.ref(
                'l10n_eg_negotiation.report_negotiation_minutes',
                raise_if_not_found=False,
            )
            if report:
                doc = self.tender_id._safe_generate_document(
                    'l10n_eg_negotiation.report_negotiation_minutes'
                )
                if doc:
                    self.minutes_doc_id = doc
        except Exception:
            pass
