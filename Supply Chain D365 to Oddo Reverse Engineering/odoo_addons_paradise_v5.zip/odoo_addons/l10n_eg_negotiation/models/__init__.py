# -*- coding: utf-8 -*-
from . import tender_negotiation
from . import procurement_tender
