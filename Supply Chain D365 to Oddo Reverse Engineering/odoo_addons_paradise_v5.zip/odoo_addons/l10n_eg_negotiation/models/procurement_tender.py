# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class ProcurementTenderNegotiation(models.Model):
    _inherit = 'procurement.tender'

    # Add 'ممارسة' to tender_type selection
    tender_type = fields.Selection(
        selection_add=[('ممارسة', 'ممارسة — Negotiation Tender')],
        ondelete={'ممارسة': 'set default'},
    )

    # Add 'negotiation' state between evaluation and award
    state = fields.Selection(
        selection_add=[('negotiation', 'الممارسة — Negotiation')],
        ondelete={'negotiation': 'set default'},
    )

    negotiation_ids = fields.One2many(
        'tender.negotiation', 'tender_id',
        string='Negotiation Sessions',
    )
    negotiation_count = fields.Integer(
        compute='_compute_negotiation_count',
        string='Sessions',
    )

    def _compute_negotiation_count(self):
        for rec in self:
            rec.negotiation_count = len(rec.negotiation_ids)

    # ── Enter negotiation stage ───────────────────────────────────────────
    def action_start_negotiation(self):
        self.ensure_one()
        if self.tender_type != 'ممارسة':
            raise UserError(_(
                'مرحلة الممارسة متاحة فقط للمناقصات من نوع الممارسة.'
            ))
        # Verify البت الفني is complete
        pending = self.evaluation_ids.filtered(
            lambda e: e.eval_type in ('بت_فني_أ', 'بت_فني_ب')
            and e.state not in ('decided', 'report_generated', 'signed')
        )
        if pending:
            raise UserError(_(
                'يجب إتمام تقييمات البت الفني قبل بدء مرحلة الممارسة.'
            ))
        # Get technically qualified bids
        qualified = self.bid_ids.filtered('technical_qualified')
        if not qualified:
            raise UserError(_(
                'لا توجد عروض مؤهلة فنياً لإجراء التفاوض معها.'
            ))
        # Create one negotiation session per qualified bid
        for bid in qualified:
            self.env['tender.negotiation'].create({
                'tender_id':      self.id,
                'partner_id':     bid.partner_id.id,
                'bid_id':         bid.id,
                'initial_price':  bid.financial_amount,
                'session_number': 1,
                'state':          'scheduled',
                'session_date':   fields.Datetime.now(),
            })
        self.state = 'negotiation'

    # ── Gate: move from negotiation to financial eval ─────────────────────
    def action_start_financial_eval(self):
        self.ensure_one()
        if self.tender_type == 'ممارسة':
            # All sessions must be completed or cancelled
            pending = self.negotiation_ids.filtered(
                lambda n: n.state not in ('completed', 'cancelled')
            )
            if pending:
                raise UserError(_(
                    'يجب إتمام جميع جلسات التفاوض قبل الانتقال إلى البت المالي.\n'
                    'الجلسات المعلقة: %(count)d',
                    count=len(pending),
                ))
            # At least one agreement must have been reached
            agreements = self.negotiation_ids.filtered(
                lambda n: n.outcome == 'agreement_reached'
            )
            if not agreements:
                raise UserError(_(
                    'لم يتم التوصل إلى اتفاق مع أي مورد.\n'
                    'يجب إلغاء المناقصة أو إعادة طرحها.'
                ))
        # Return to evaluation state for البت المالي
        self.state = 'evaluation'
