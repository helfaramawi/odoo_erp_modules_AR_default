# -*- coding: utf-8 -*-
{
    'name': 'Negotiation Tender — الممارسة (C-PR06)',
    'version': '17.0.1.0.0',
    'summary': 'Negotiation tender: الممارسة stage, محضر جلسة المفاوضة, price negotiation writeback',
    'author': 'Paradise Integrated Solutions',
    'license': 'LGPL-3',
    'category': 'Purchase',
    'depends': [
        'l10n_eg_tender',
        'l10n_eg_tender_public',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/tender_negotiation_views.xml',
        'views/tender_views_inherit.xml',
        'report/report_negotiation_minutes.xml',
        'report/report_fin_eval_extension.xml',
        'report/report_actions.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
