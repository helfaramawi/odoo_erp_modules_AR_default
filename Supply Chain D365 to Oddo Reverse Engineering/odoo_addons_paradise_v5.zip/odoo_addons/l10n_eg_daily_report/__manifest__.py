# -*- coding: utf-8 -*-
{
    'name': 'Daily Accounting Report — تقرير اليومية المحاسبية (C2)',
    'version': '17.0.1.0.0',
    'summary': 'Arabic RTL daily journal report replacing D365 X++ RDP class',
    'author': 'Paradise Integrated Solutions',
    'license': 'LGPL-3',
    'category': 'Accounting',
    'depends': ['account'],
    'data': [
        'security/ir.model.access.csv',
        'views/daily_wizard_views.xml',
        'report/report_daily_accounting.xml',
        'report/report_actions.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
