# -*- coding: utf-8 -*-
from odoo import models, fields, api, _


class DailyAccountingWizard(models.TransientModel):
    _name = 'daily.accounting.wizard'
    _description = 'Daily Accounting Report Wizard — تقرير اليومية المحاسبية'

    date_from     = fields.Date(required=True, default=fields.Date.today)
    date_to       = fields.Date(required=True, default=fields.Date.today)
    journal_ids   = fields.Many2many('account.journal',
                                     string='Journals (empty = all)')
    account_ids   = fields.Many2many('account.account',
                                     string='Accounts (empty = all)')
    company_id    = fields.Many2one('res.company',
                                    default=lambda self: self.env.company)
    include_draft = fields.Boolean(default=False,
                                   string='Include Draft Entries')

    def action_print(self):
        return self.env.ref(
            'l10n_eg_daily_report.report_daily_accounting',
        ).report_action(self)

    def _get_journal_data(self):
        """Aggregate account.move.line data grouped by journal."""
        domain = [
            ('date', '>=', self.date_from),
            ('date', '<=', self.date_to),
            ('company_id', '=', self.company_id.id),
            ('move_id.state', 'in',
             ['posted'] if not self.include_draft else ['posted', 'draft']),
        ]
        if self.journal_ids:
            domain.append(('journal_id', 'in', self.journal_ids.ids))
        if self.account_ids:
            domain.append(('account_id', 'in', self.account_ids.ids))

        lines = self.env['account.move.line'].search(
            domain, order='journal_id, date, move_id')

        journals = {}
        for line in lines:
            jid = line.journal_id.id
            if jid not in journals:
                journals[jid] = {
                    'name':          line.journal_id.name,
                    'lines':         [],
                    'total_debit':   0.0,
                    'total_credit':  0.0,
                }
            journals[jid]['lines'].append({
                'date':         str(line.date),
                'ref':          line.move_id.ref or line.move_id.name or '',
                'account_code': line.account_id.code,
                'account_name': line.account_id.name,
                'debit':        '%.2f' % line.debit,
                'credit':       '%.2f' % line.credit,
                'partner':      line.partner_id.name or '',
            })
            journals[jid]['total_debit']  += line.debit
            journals[jid]['total_credit'] += line.credit

        return list(journals.values())

    def _grand_total_debit(self):
        return '%.2f' % sum(j['total_debit'] for j in self._get_journal_data())

    def _grand_total_credit(self):
        return '%.2f' % sum(j['total_credit'] for j in self._get_journal_data())

    def _get_hijri_range(self):
        """Return Hijri date string for the date_from."""
        try:
            from hijri_converter import convert  # noqa
            d = self.date_from
            h = convert.Gregorian(d.year, d.month, d.day).to_hijri()
            return '%d/%d/%d هـ' % (h.day, h.month, h.year)
        except ImportError:
            return ''
