# -*- coding: utf-8 -*-
from . import daily_accounting_wizard
