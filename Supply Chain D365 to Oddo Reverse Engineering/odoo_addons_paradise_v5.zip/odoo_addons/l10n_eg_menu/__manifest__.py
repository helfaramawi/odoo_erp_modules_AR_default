# -*- coding: utf-8 -*-
{
    'name': 'Arabic Unified Menu — القائمة العربية الموحدة (C7)',
    'version': '17.0.1.0.0',
    'summary': 'Unified Arabic/English navigation for الديوان العام — installed LAST',
    'author': 'Paradise Integrated Solutions',
    'license': 'LGPL-3',
    'category': 'Base',
    'depends': [
        'l10n_eg_tender',
        'l10n_eg_tender_public',
        'l10n_eg_tender_ltd',
        'l10n_eg_direct',
        'l10n_eg_works',
        'l10n_eg_negotiation',
        'l10n_eg_commitment',
        'l10n_eg_approval',
        'l10n_eg_budget_control',
        'l10n_eg_daily_report',
        'l10n_eg_aging',
        'l10n_eg_audit',
    ],
    'data': [
        'views/menu.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
