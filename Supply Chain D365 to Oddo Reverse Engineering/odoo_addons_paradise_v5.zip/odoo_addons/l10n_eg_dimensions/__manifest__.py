# -*- coding: utf-8 -*-
{
    'name': 'Financial Dimensions — الأبعاد المالية (C3)',
    'version': '17.0.1.0.0',
    'summary': 'Propagate analytic account from PO to stock.move, GRN, and account.move.line',
    'author': 'Paradise Integrated Solutions',
    'license': 'LGPL-3',
    'category': 'Accounting',
    'depends': ['stock', 'account', 'purchase', 'l10n_eg_commitment'],
    'data': [
        'security/ir.model.access.csv',
        'views/stock_picking_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
