# -*- coding: utf-8 -*-
from odoo import models, fields, api


class StockPickingDimension(models.Model):
    """
    Extend stock.picking to display the dominant analytic account
    (from the first move line that has one).
    """
    _inherit = 'stock.picking'

    analytic_account_id = fields.Many2one(
        'account.analytic.account',
        string='Cost Centre (مركز التكلفة)',
        compute='_compute_analytic',
        store=True,
    )

    @api.depends('move_ids.analytic_account_id')
    def _compute_analytic(self):
        for picking in self:
            analytic = picking.move_ids.mapped('analytic_account_id')
            picking.analytic_account_id = analytic[0] if analytic else False
