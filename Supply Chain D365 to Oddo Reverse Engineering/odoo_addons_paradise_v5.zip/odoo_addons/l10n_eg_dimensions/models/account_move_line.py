# -*- coding: utf-8 -*-
from odoo import models, fields


class AccountMoveLineDimension(models.Model):
    """
    Ensure account.move.line always has analytic_account_id visible
    and filterable for الديوان العام budget reports.
    """
    _inherit = 'account.move.line'

    # analytic_account_id already exists in Odoo 17 account module.
    # This extension just adds a helper for C1 budget matching.

    def _get_analytic_for_commitment(self):
        """
        Returns the analytic account for this move line,
        used by C1 CommitmentLedger to find the matching budget line.
        """
        self.ensure_one()
        return self.analytic_account_id or False
