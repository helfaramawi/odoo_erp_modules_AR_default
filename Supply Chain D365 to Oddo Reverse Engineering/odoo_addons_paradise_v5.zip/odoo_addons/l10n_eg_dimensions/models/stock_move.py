# -*- coding: utf-8 -*-
from odoo import models, fields, api


class StockMoveDimension(models.Model):
    """
    C3 FinancialDimensions — extend stock.move with analytic_account_id.

    Propagation chain:
    purchase.order.line.account_analytic_id
        → stock.move.analytic_account_id  (via _compute_analytic)
        → account.move.line.analytic_account_id (via _generate_valuation_lines_data)

    This ensures inventory valuation journal entries carry the correct
    cost centre (مركز التكلفة) for الديوان العام لمحافظة بورسعيد.
    """
    _inherit = 'stock.move'

    analytic_account_id = fields.Many2one(
        'account.analytic.account',
        string='Cost Centre (مركز التكلفة)',
        index=True,
        compute='_compute_analytic',
        store=True,
        help='Auto-propagated from the PO line analytic account.',
    )

    @api.depends('purchase_line_id.account_analytic_id',
                 'sale_line_id')
    def _compute_analytic(self):
        for move in self:
            if move.purchase_line_id and move.purchase_line_id.account_analytic_id:
                move.analytic_account_id = move.purchase_line_id.account_analytic_id
            else:
                move.analytic_account_id = False

    def _generate_valuation_lines_data(self, partner_id, qty, debit_value,
                                        credit_value, debit_account_id,
                                        credit_account_id, svl_id, description):
        """
        Override to inject analytic_account_id into valuation journal entries.
        This is the critical hook — without it, C1 budget matching cannot
        link landed costs to the correct budget line.
        """
        result = super()._generate_valuation_lines_data(
            partner_id, qty, debit_value, credit_value,
            debit_account_id, credit_account_id, svl_id, description,
        )
        if self.analytic_account_id:
            analytic_id = self.analytic_account_id.id
            for line_data in result.values():
                if isinstance(line_data, dict):
                    line_data['analytic_account_id'] = analytic_id
        return result
