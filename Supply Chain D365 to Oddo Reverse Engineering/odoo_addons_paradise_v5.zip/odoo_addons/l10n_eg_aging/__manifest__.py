# -*- coding: utf-8 -*-
{
    'name': 'Arabic Aging Report — تقرير أعمار الديون (C4)',
    'version': '17.0.1.0.0',
    'summary': 'AP/AR aging with configurable buckets, Arabic RTL column headers',
    'author': 'Paradise Integrated Solutions',
    'license': 'LGPL-3',
    'category': 'Accounting',
    'depends': ['account'],
    'data': [
        'security/ir.model.access.csv',
        'views/aging_wizard_views.xml',
        'report/report_aging_arabic.xml',
        'report/report_actions.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
