# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import date


class AgingReportWizard(models.TransientModel):
    _name = 'aging.report.wizard'
    _description = 'Arabic Aging Report Wizard — تقرير أعمار الديون'

    report_type = fields.Selection([
        ('payable',    'موردون — AP Payables'),
        ('receivable', 'عملاء — AR Receivables'),
    ], required=True, default='payable',
       string='Report Type')

    as_of_date = fields.Date(
        string='As of Date',
        required=True,
        default=fields.Date.today,
    )
    bucket_1_days = fields.Integer(string='Bucket 1 (days)', default=30)
    bucket_2_days = fields.Integer(string='Bucket 2 (days)', default=60)
    bucket_3_days = fields.Integer(string='Bucket 3 (days)', default=90)
    bucket_4_days = fields.Integer(string='Bucket 4 (days)', default=120)

    partner_ids = fields.Many2many(
        'res.partner',
        string='Filter by Vendor/Customer (empty = all)',
    )
    currency_id = fields.Many2one(
        'res.currency',
        default=lambda self: self.env.ref('base.EGP', raise_if_not_found=False),
    )

    def _get_aging_data(self):
        """Compute aging buckets per partner."""
        acc_type = (
            'liability_payable' if self.report_type == 'payable'
            else 'asset_receivable'
        )
        domain = [
            ('account_id.account_type', '=', acc_type),
            ('move_id.state', '=', 'posted'),
            ('reconciled', '=', False),
        ]
        if self.partner_ids:
            domain.append(('partner_id', 'in', self.partner_ids.ids))

        lines = self.env['account.move.line'].search(domain)
        buckets = [
            self.bucket_1_days,
            self.bucket_2_days,
            self.bucket_3_days,
            self.bucket_4_days,
        ]
        result = {}

        for line in lines:
            pid = line.partner_id.id
            if not pid:
                continue
            if pid not in result:
                result[pid] = {
                    'name':    line.partner_id.name,
                    'buckets': [0.0] * 5,
                    'total':   0.0,
                }
            due_date = line.date_maturity or line.date
            age = (self.as_of_date - due_date).days
            bal = abs(line.amount_residual)

            if age <= buckets[0]:
                result[pid]['buckets'][0] += bal
            elif age <= buckets[1]:
                result[pid]['buckets'][1] += bal
            elif age <= buckets[2]:
                result[pid]['buckets'][2] += bal
            elif age <= buckets[3]:
                result[pid]['buckets'][3] += bal
            else:
                result[pid]['buckets'][4] += bal
            result[pid]['total'] += bal

        return sorted(result.values(), key=lambda x: x['name'])

    def _bucket_label(self, index):
        """Return Arabic label for bucket column headers."""
        b = [self.bucket_1_days, self.bucket_2_days,
             self.bucket_3_days, self.bucket_4_days]
        labels = [
            '0 – %d يوم' % b[0],
            '%d – %d يوم' % (b[0] + 1, b[1]),
            '%d – %d يوم' % (b[1] + 1, b[2]),
            '%d – %d يوم' % (b[2] + 1, b[3]),
            'أكثر من %d يوم' % b[3],
        ]
        return labels[index] if index < len(labels) else ''

    def _column_totals(self):
        """Return list of 5 bucket totals across all partners."""
        data = self._get_aging_data()
        totals = [0.0] * 5
        for partner in data:
            for i, val in enumerate(partner['buckets']):
                totals[i] += val
        return totals

    def action_print(self):
        return self.env.ref(
            'l10n_eg_aging.report_aging_arabic',
        ).report_action(self)
