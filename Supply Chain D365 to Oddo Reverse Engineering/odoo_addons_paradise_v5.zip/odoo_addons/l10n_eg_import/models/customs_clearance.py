# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class CustomsClearance(models.Model):
    _name = 'customs.clearance'
    _description = 'Import Customs Clearance — تخليص جمركي'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name desc'

    name = fields.Char(required=True, copy=False, readonly=True,
                       default=lambda self: _('New'), index=True)
    picking_id = fields.Many2one('stock.picking', required=True,
                                  domain=[('picking_type_code','=','incoming')], index=True)
    purchase_id = fields.Many2one(related='picking_id.purchase_id', store=True)
    customs_declaration_no = fields.Char(required=True, index=True,
                                          string='Customs Declaration No. (رقم البيان الجمركي)')
    clearance_agent_id = fields.Many2one('res.partner', required=True,
                                          string='Clearance Agent (شركة التخليص)')
    port_of_entry = fields.Selection([
        ('port_said','بورسعيد'),('alex','الإسكندرية'),
        ('cairo_air','القاهرة الجوي'),('suez','السويس'),('other','أخرى'),
    ], required=True, default='port_said')
    declaration_date = fields.Date(required=True)
    clearance_date   = fields.Date(string='Clearance Date (تاريخ الإفراج)')
    currency_id = fields.Many2one('res.currency',
                                   default=lambda self: self.env.ref('base.EGP', raise_if_not_found=False))
    customs_duty_amount = fields.Monetary(currency_field='currency_id',
                                           string='Customs Duty (جمارك) EGP')
    clearance_fees  = fields.Monetary(currency_field='currency_id',
                                       string='Clearance Fees (أتعاب) EGP')
    other_charges   = fields.Monetary(currency_field='currency_id',
                                       string='Other Port Charges EGP')
    total_landed_cost = fields.Monetary(compute='_compute_total', store=True,
                                         currency_field='currency_id')
    landed_cost_id  = fields.Many2one('stock.landed.cost', readonly=True, copy=False)
    duty_account_id = fields.Many2one('account.account', required=True)
    state = fields.Selection([
        ('draft','Draft — مسودة'),('in_clearance','In Clearance — تحت التخليص'),
        ('cleared','Cleared — تم الإفراج'),('landed','Landed — تم التسليم'),
        ('cancelled','Cancelled — ملغى'),
    ], default='draft', tracking=True, index=True)

    @api.depends('customs_duty_amount','clearance_fees','other_charges')
    def _compute_total(self):
        for r in self:
            r.total_landed_cost = r.customs_duty_amount + r.clearance_fees + r.other_charges

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name',_('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code('customs.clearance') or _('New')
        return super().create(vals_list)

    def action_confirm_clearance(self):
        self.ensure_one()
        if not self.clearance_date:
            raise UserError(_('يجب إدخال تاريخ الإفراج الجمركي.'))
        duty_product = self.env.ref('l10n_eg_import.product_customs_duty', raise_if_not_found=False)
        fees_product = self.env.ref('l10n_eg_import.product_clearance_fees', raise_if_not_found=False)
        cost_lines = []
        if self.customs_duty_amount > 0 and duty_product:
            cost_lines.append((0,0,{'product_id':duty_product.id,'price_unit':self.customs_duty_amount,
                                     'account_id':self.duty_account_id.id,'split_method':'by_current_cost_price'}))
        if self.clearance_fees > 0 and fees_product:
            cost_lines.append((0,0,{'product_id':fees_product.id,'price_unit':self.clearance_fees,
                                     'account_id':self.duty_account_id.id,'split_method':'by_current_cost_price'}))
        if cost_lines:
            lc = self.env['stock.landed.cost'].create({'picking_ids':[(4,self.picking_id.id)],'cost_lines':cost_lines})
            self.landed_cost_id = lc
        self.state = 'cleared'

    def action_validate_landed_cost(self):
        self.ensure_one()
        if not self.landed_cost_id:
            raise UserError(_('يجب إنشاء تكاليف الشحن أولاً — استخدم تأكيد التخليص.'))
        if self.landed_cost_id.state != 'done':
            self.landed_cost_id.button_validate()
        self.state = 'landed'
