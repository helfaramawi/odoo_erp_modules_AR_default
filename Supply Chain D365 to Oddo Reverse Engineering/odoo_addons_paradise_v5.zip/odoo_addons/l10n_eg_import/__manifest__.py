# -*- coding: utf-8 -*-
{
    'name': 'Import Customs Clearance — تخليص جمركي (C10)',
    'version': '17.0.1.0.0',
    'summary': 'Customs clearance tracking: declaration, agent, duties, landed costs',
    'author': 'Paradise Integrated Solutions',
    'license': 'LGPL-3',
    'category': 'Inventory',
    'depends': ['stock_landed_costs', 'purchase', 'account', 'l10n_eg_commitment'],
    'data': [
        'security/ir.model.access.csv',
        'data/sequences.xml',
        'data/product_data.xml',
        'views/customs_clearance_views.xml',
        'report/report_clearance_doc.xml',
        'report/report_actions.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
