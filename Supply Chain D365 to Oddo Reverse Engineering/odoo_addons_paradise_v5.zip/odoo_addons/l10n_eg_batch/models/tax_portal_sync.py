# -*- coding: utf-8 -*-
import requests
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class TaxPortalSync(models.Model):
    """
    TaxPortalSync — Monthly EDI sync with Egyptian Tax Authority (ETA).

    OAuth2 implementation — CR-001 fix applied (Week 19 of project).
    ETA changed from basic auth to OAuth2 client_credentials in 2025.

    Configuration via ir.config_parameter:
        eta.client_id      — ETA client ID
        eta.client_secret  — ETA client secret
        eta.token_url      — OAuth2 token endpoint
        eta.api_url        — ETA submission API endpoint
    """
    _name = 'tax.portal.sync'
    _description = 'Egyptian Tax Authority Portal Sync (CR-001 OAuth2)'

    name = fields.Char(default='ETA Sync', readonly=True)
    last_sync_date = fields.Datetime(string='Last Sync', readonly=True)
    last_sync_status = fields.Selection([
        ('success', 'Success'),
        ('error',   'Error'),
        ('pending', 'Pending'),
    ], default='pending', readonly=True)
    last_sync_message = fields.Text(readonly=True)
    synced_count = fields.Integer(string='Records Synced', readonly=True)

    def _get_oauth2_token(self):
        """Fetch OAuth2 bearer token from ETA portal (CR-001 fix)."""
        config = self.env['ir.config_parameter'].sudo()
        client_id     = config.get_param('eta.client_id', '')
        client_secret = config.get_param('eta.client_secret', '')
        token_url     = config.get_param(
            'eta.token_url',
            'https://api.invoicing.eta.gov.eg/connect/token',
        )
        if not client_id or not client_secret:
            raise UserError(_(
                'إعدادات بوابة الضرائب غير مكتملة.\n'
                'يُرجى إدخال client_id و client_secret في إعدادات النظام.'
            ))
        try:
            resp = requests.post(
                token_url,
                data={
                    'grant_type':    'client_credentials',
                    'client_id':     client_id,
                    'client_secret': client_secret,
                },
                timeout=30,
            )
            resp.raise_for_status()
            return resp.json().get('access_token')
        except requests.RequestException as e:
            raise UserError(_(
                'فشل الاتصال ببوابة الضرائب المصرية.\n'
                'التفاصيل: %(error)s',
                error=str(e),
            ))

    @api.model
    def _sync_tax_portal(self):
        """
        Monthly EDI sync — called by C8 ir.cron.
        Submits previous month VAT data to ETA via OAuth2.
        """
        sync_rec = self.search([], limit=1) or self.create({'name': 'ETA Sync'})
        try:
            token = self._get_oauth2_token()
            api_url = self.env['ir.config_parameter'].sudo().get_param(
                'eta.api_url',
                'https://api.invoicing.eta.gov.eg/api/v1/documents/requests/submit',
            )
            # Find unsynced posted invoices
            moves = self.env['account.move'].search([
                ('move_type', 'in', ['out_invoice', 'out_refund', 'in_invoice']),
                ('state', '=', 'posted'),
                ('eta_synced', '=', False),
            ])
            if not moves:
                sync_rec.write({
                    'last_sync_date':    fields.Datetime.now(),
                    'last_sync_status':  'success',
                    'last_sync_message': 'لا توجد مستندات جديدة للمزامنة',
                    'synced_count':      0,
                })
                return

            payload = {'documents': [self._to_eta_format(m) for m in moves]}
            resp = requests.post(
                api_url,
                json=payload,
                headers={'Authorization': 'Bearer %s' % token},
                timeout=60,
            )
            resp.raise_for_status()
            moves.write({
                'eta_synced':      True,
                'eta_sync_date':   fields.Datetime.now(),
            })
            sync_rec.write({
                'last_sync_date':    fields.Datetime.now(),
                'last_sync_status':  'success',
                'last_sync_message': 'تمت المزامنة بنجاح',
                'synced_count':      len(moves),
            })
        except Exception as e:
            error_msg = str(e)
            sync_rec.write({
                'last_sync_date':    fields.Datetime.now(),
                'last_sync_status':  'error',
                'last_sync_message': error_msg,
            })
            # Log error to mail — never let cron crash silently
            self.env['mail.message'].sudo().create({
                'subject':      'TaxPortalSync Error — CR-001',
                'body':         error_msg,
                'model':        'tax.portal.sync',
                'res_id':       sync_rec.id,
                'message_type': 'comment',
            })

    def _to_eta_format(self, move):
        """Convert account.move to ETA API format (simplified)."""
        return {
            'issuer': {
                'id':   self.env.company.vat or '',
                'name': self.env.company.name,
            },
            'receiver': {
                'id':   move.partner_id.vat or '',
                'name': move.partner_id.name,
            },
            'documentType': 'I' if move.move_type == 'out_invoice' else 'C',
            'dateTimeIssued': str(move.invoice_date or fields.Date.today()),
            'totalAmount': move.amount_total,
            'currency': move.currency_id.name,
        }
