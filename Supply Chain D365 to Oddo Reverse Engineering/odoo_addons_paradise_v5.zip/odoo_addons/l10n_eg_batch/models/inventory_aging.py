# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import date, timedelta


class InventoryAgingReport(models.Model):
    """
    Inventory aging computation — called weekly by C8 cron.
    Identifies slow-moving items and flags them for the C-INV06 disposal workflow.
    """
    _name = 'inventory.aging.report'
    _description = 'Inventory Aging Report — تقرير أعمار المخزون'
    _order = 'days_inactive desc'

    product_id   = fields.Many2one('product.product', required=True, index=True)
    location_id  = fields.Many2one('stock.location', required=True, index=True)
    last_move_date = fields.Date(string='Last Movement Date')
    days_inactive  = fields.Integer(
        compute='_compute_days', store=True, string='Days Inactive',
    )
    threshold_days = fields.Integer(default=180)
    quantity_on_hand = fields.Float(string='On-Hand Qty')
    value_on_hand    = fields.Monetary(
        string='Inventory Value (EGP)', currency_field='currency_id',
    )
    currency_id = fields.Many2one(
        'res.currency',
        default=lambda self: self.env.ref('base.EGP', raise_if_not_found=False),
    )
    flagged_date = fields.Date(
        string='Date Flagged', default=fields.Date.today,
    )

    @api.depends('last_move_date')
    def _compute_days(self):
        today = date.today()
        for rec in self:
            rec.days_inactive = (
                (today - rec.last_move_date).days
                if rec.last_move_date else 9999
            )

    @api.model
    def _compute_inventory_aging(self):
        """
        Called weekly by C8 ir.cron (InventoryAging job).
        Scans all internal locations for slow-moving items.
        Flags items with zero movement >= threshold_days.
        """
        # Only check products with stock
        quants = self.env['stock.quant'].search([
            ('location_id.usage', '=', 'internal'),
            ('quantity', '>', 0),
        ])
        flagged = 0
        for quant in quants:
            # Find last movement
            last_move = self.env['stock.move.line'].search([
                ('product_id', '=', quant.product_id.id),
                ('location_dest_id', '=', quant.location_id.id),
                ('state', '=', 'done'),
            ], order='date desc', limit=1)

            if not last_move:
                continue

            last_date = last_move.date.date() if last_move else None
            if not last_date:
                continue

            days = (date.today() - last_date).days
            # Use product category threshold or default 180
            threshold = getattr(
                quant.product_id.categ_id, 'slow_moving_threshold', 180
            ) or 180

            if days >= threshold:
                # Only create if not already flagged
                existing = self.search([
                    ('product_id', '=', quant.product_id.id),
                    ('location_id', '=', quant.location_id.id),
                ])
                if not existing:
                    self.create({
                        'product_id':      quant.product_id.id,
                        'location_id':     quant.location_id.id,
                        'last_move_date':  last_date,
                        'quantity_on_hand': quant.quantity,
                        'value_on_hand':   quant.value,
                        'threshold_days':  threshold,
                    })
                    flagged += 1

        return flagged
