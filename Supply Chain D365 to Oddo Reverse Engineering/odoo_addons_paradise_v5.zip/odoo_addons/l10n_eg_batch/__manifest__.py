# -*- coding: utf-8 -*-
{
    'name': 'Batch Jobs — المهام المجدولة (C8)',
    'version': '17.0.1.0.0',
    'summary': '6 ir.cron jobs: CommitmentSync, TaxPortalSync(OAuth2), InventoryAging, CustodyReport, BudgetReconciliation, VendorStatement',
    'author': 'Paradise Integrated Solutions',
    'license': 'LGPL-3',
    'category': 'Accounting',
    'depends': [
        'l10n_eg_commitment',
        'l10n_eg_aging',
        'account_budget',
        'mail',
    ],
    'data': [
        'security/ir.model.access.csv',
        'data/cron_jobs.xml',
        'views/tax_portal_config_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
