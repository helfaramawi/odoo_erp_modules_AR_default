# الديوان العام لمحافظة بورسعيد — Odoo 17 Custom Addons
## Paradise Integrated Solutions | D365 F&O → Odoo 17 Migration
## Version 3 — All Procurement + Finance Foundation Addons

---

## Installation Order (STRICT — this sequence is mandatory)

```bash
# Step 1: Foundation
odoo-bin -d <db> -i l10n_eg_tender          --stop-after-init   # C-PR01

# Step 2: Finance foundation (must install before tender pipeline)
odoo-bin -d <db> -i l10n_eg_approval        --stop-after-init   # C5
odoo-bin -d <db> -i l10n_eg_commitment      --stop-after-init   # C1

# Step 3: Procurement pipeline
odoo-bin -d <db> -i l10n_eg_tender_public   --stop-after-init   # C-PR02
odoo-bin -d <db> -i l10n_eg_tender_ltd      --stop-after-init   # C-PR03
odoo-bin -d <db> -i l10n_eg_direct          --stop-after-init   # C-PR04
odoo-bin -d <db> -i l10n_eg_works           --stop-after-init   # C-PR05
odoo-bin -d <db> -i l10n_eg_negotiation     --stop-after-init   # C-PR06

# Step 4: Budget control (depends on C1 + C5)
odoo-bin -d <db> -i l10n_eg_budget_control  --stop-after-init   # C6
```

---

## Addon Summary

| Addon | Module | Hours | Key Files |
|-------|--------|-------|-----------|
| `l10n_eg_tender` | C-PR01 GovernmentTenderLifecycle | 60h | 7 py, 9 xml, 8 tests |
| `l10n_eg_tender_public` | C-PR02 PublicTenderPipeline | 80h | 6 py, 12 xml, 14 tests |
| `l10n_eg_tender_ltd` | C-PR03 LimitedTenderExtension | 45h | 7 py, 9 xml, 11 tests |
| `l10n_eg_direct` | C-PR04 DirectOrderTemplates | 30h | 3 py, 7 xml, 8 tests |
| `l10n_eg_works` | C-PR05 ContractingWorks+Sovereign | 85h | 5 py, 8 xml, 12 tests |
| `l10n_eg_negotiation` | C-PR06 NegotiationTender | 25h | 3 py, 5 xml, 9 tests |
| `l10n_eg_approval` | C5 MultiLevelApproval | 50h | 3 py, 1 xml, 7 tests |
| `l10n_eg_commitment` | C1 CommitmentLedger | 80h | 7 py, 7 xml, 10 tests |
| `l10n_eg_budget_control` | C6 BudgetControl | 45h | 3 py, 2 xml, 6 tests |
| **TOTAL** | **9 addons** | **500h** | **44 py, 60 xml, 85 tests** |

---

## Addon Details

### l10n_eg_tender (C-PR01) — FOUNDATION
- `procurement.tender` model: 6-stage lifecycle (draft→committee→published→evaluation→award→contract)
- Sovereign entity (PR-07) bypass: `jihat_siyadiya` flag + `jihat_code` enforcement
- 3-tier approval authority: مدير الإدارة / نائب المحافظ / المحافظ (thresholds: 50K / 500K EGP)
- Arabic QWeb base template: RTL, Hijri date, gov header, 3-col signature block
- `إخطار الترسية` award notification report
- Auto-creates `purchase.order` on contract stage
- 4 security groups: readonly / user / officer / manager

### l10n_eg_tender_public (C-PR02)
- `bid.envelope`: deadline + duplicate vendor constraint
- `tender.evaluation`: البت الفني/المالي rounds
- `tender.sample.receipt`: كشف استلام العينات
- Financial ranking: ascending price (lowest = rank 1 = winner)
- 6 Arabic QWeb templates: محضر فتح المظاريف, البت الفني أ/ب, البت المالي 1/2, حصر الشركات

### l10n_eg_tender_ltd (C-PR03)
- `vendor.prequalification` registry with category filtering
- `tender.invitation`: per-vendor invitation records
- 8 seed supply categories pre-loaded (BLDG/OFFICE/IT/CIVIL/CLEAN/VEH/MED/FOOD)
- Minimum 3-vendor enforcement at publish stage
- Non-invited vendor bid rejection
- كشف أسماء الموردين + خطاب دعوة المورد + صورة الإعلان المحلي

### l10n_eg_direct (C-PR04)
- `direct.order.committee` lightweight model
- 5 justification types for direct order
- استمارة صرف 50 ع.ح: 4-column signature, amount-in-Arabic-words, budget balance
- محضر الفحص الفني: color-coded result (approved/conditional/rejected)
- قرار اللجنة المبسط: vendor + amount in committee decision
- FORM50/YYYY/NNNN sequence

### l10n_eg_works (C-PR05)
- `subcontract.award`: أمر الإسناد — 17 fields, ISN/YYYY/NNNN sequence
- `works.milestone`: progress tracking with completion_pct and inspector approval
- PR-07 sovereign bypass: `is_sovereign` + `jihat_code` constraints
- أمر الإسناد report: milestones table + sovereign entity banner
- شهادة إنجاز مرحلة milestone certificate

### l10n_eg_negotiation (C-PR06)
- Adds `ممارسة` tender type and `negotiation` state
- `tender.negotiation`: per-vendor session with price negotiation writeback
- Gate enforcement: all sessions complete → agreement exists → البت المالي
- محضر جلسة المفاوضة: 3-col signature, color-coded outcome box
- Extends C-PR02 البت المالي template with negotiation summary table

### l10n_eg_approval (C5) — INSTALL BEFORE C-PR01 AND C1
- 3-tier: dept_head (<50K) → deputy_governor (50K–500K) → governor (>500K)
- Sequential gate: each step must precede the next
- Full audit trail: user + timestamp on each step
- Arabic UserError messages for out-of-order calls

### l10n_eg_commitment (C1) — NON-NEGOTIABLE
- `commitment.line`: CMT/YYYY/NNNN, 16 fields
- `commitment.config`: per-company journal + DR/CR accounts
- `button_approve` hook → `_create_commitment_entries()`
- `button_validate` hook → proportional GRN reversal
- `button_cancel` hook → full commitment reversal
- `check_budget_availability()` used by C6
- `crossovered.budget.lines` extension: `committed_amount` + `available_amount`

### l10n_eg_budget_control (C6) — INSTALL AFTER C1 AND C5
- Intercepts `action_confirm()` on all POs
- Calls C1 `check_budget_availability()` per analytic account
- Arabic error dialog: available / required / shortfall in EGP
- 24-hour override window: finance director grants via `action_approve_budget_override()`
- Override tracked: user + timestamp for C13 audit trail
- `group_finance_director` security group

---

## Python Dependencies (install on Odoo server before starting)

```bash
pip install hijri-converter>=2.3.1   # Hijri date in all Arabic reports
pip install num2words>=0.5.12        # Arabic amount-in-words (استمارة 50)
```

---

## Running Tests

```bash
odoo-bin --test-enable -d <db> \
  -i l10n_eg_tender,l10n_eg_approval,l10n_eg_commitment,\
l10n_eg_tender_public,l10n_eg_tender_ltd,l10n_eg_direct,\
l10n_eg_works,l10n_eg_negotiation,l10n_eg_budget_control \
  --stop-after-init

# Expected: 85 tests across 9 addons
```

---

## Post-Install Configuration Required

### 1. Commitment Accounting (C1) — REQUIRED BEFORE ANY PO APPROVAL
Navigate to: الشؤون المالية > إعدادات > إعدادات محاسبة الالتزامات

Create one config record:
- **Commitment Journal**: create General journal "دفتر الالتزامات"
- **DR Account**: "حساب مصروفات الالتزامات" (account_type: expense)
- **CR Account**: "احتياطي مقابل الالتزامات" (account_type: liability_current)
- **Auto-reverse on GRN**: ✓
- **Auto-reverse on Cancel**: ✓
- **Hard Budget Block**: ✓ (delegates to C6)

### 2. Vendor Registry (C-PR03) — seed data auto-loaded on install
8 supply categories pre-loaded. Add vendors via:
إدارة التعاقدات > سجل الموردين المؤهلين > جديد

### 3. Port Said Governorate Seal
Replace `/l10n_eg_tender/static/src/img/port_said_seal.svg`
with the official seal file from الديوان العام.

---

*Paradise Integrated Solutions × الديوان العام لمحافظة بورسعيد*
*D365 F&O → Odoo 17 | v3 — 9 addons | 500h | 140 files*
