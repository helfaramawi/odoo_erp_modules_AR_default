# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class CustodyTransfer(models.Model):
    _name = 'custody.transfer'
    _description = 'Custody Transfer — نقل العهدة'
    _order = 'custody_move_id, id'

    custody_move_id = fields.Many2one(
        'custody.move', required=True, ondelete='cascade', index=True,
    )
    from_employee_id = fields.Many2one(
        'hr.employee', required=True, string='From Employee',
    )
    to_employee_id = fields.Many2one(
        'hr.employee', required=True, string='To Employee',
    )
    transfer_date = fields.Date(
        default=fields.Date.today, required=True,
    )
    reason = fields.Text(string='Reason (Arabic)')
    state = fields.Selection([
        ('draft',     'Draft'),
        ('confirmed', 'Confirmed'),
        ('cancelled', 'Cancelled'),
    ], default='draft', index=True)

    def action_confirm(self):
        self.ensure_one()
        if self.state != 'draft':
            raise UserError(_('التحويل ليس في حالة مسودة.'))
        self.custody_move_id.action_confirm_transfer(self)

    def action_cancel(self):
        self.state = 'cancelled'
