# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class CustodyClearance(models.Model):
    _name = 'custody.clearance'
    _description = 'Custody Clearance — إخلاء طرف'
    _inherit = ['mail.thread']
    _order = 'clearance_date desc'

    employee_id = fields.Many2one(
        'hr.employee', required=True, index=True,
        string='Employee Being Cleared',
    )
    custody_move_ids = fields.Many2many(
        'custody.move',
        'clearance_custody_rel',
        'clearance_id', 'custody_id',
        string='Custody Items Being Cleared',
    )
    clearance_date = fields.Date(
        required=True, default=fields.Date.today,
    )
    signed_by = fields.Many2one(
        'res.users', string='Signed By',
        default=lambda self: self.env.uid,
    )
    reason = fields.Selection([
        ('resignation',  'استقالة — Resignation'),
        ('transfer',     'نقل — Transfer'),
        ('retirement',   'تقاعد — Retirement'),
        ('return_items', 'إرجاع أصناف — Return Items'),
    ], required=True)
    state = fields.Selection([
        ('draft',    'Draft — مسودة'),
        ('signed',   'Signed — موقع'),
        ('archived', 'Archived — مؤرشف'),
    ], default='draft', tracking=True)
    notes = fields.Text()

    def action_sign(self):
        self.ensure_one()
        # Mark all linked custody items as cleared
        self.custody_move_ids.write({
            'clearance_status': 'cleared',
            'clearance_doc_id': self.id,
        })
        self.state = 'signed'
        self.message_post(body=_(
            'تم توقيع وثيقة إخلاء الطرف بواسطة %(user)s',
            user=self.env.user.name,
        ))

    def action_archive(self):
        self.state = 'archived'
