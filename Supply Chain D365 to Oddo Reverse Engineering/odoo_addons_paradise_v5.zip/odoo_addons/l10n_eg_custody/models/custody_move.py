# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class CustodyMove(models.Model):
    _name = 'custody.move'
    _description = 'Personal Custody — عهدة شخصية'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name desc'

    name = fields.Char(
        required=True, copy=False, readonly=True,
        default=lambda self: _('New'), index=True,
    )
    product_id = fields.Many2one(
        'product.product', required=True,
        domain=[('type', 'in', ['product', 'consu'])],
        string='Item (الصنف المستديم)',
    )
    employee_id = fields.Many2one(
        'hr.employee', required=True, index=True,
        string='Employee (الموظف المستلم)',
    )
    department_id = fields.Many2one(
        related='employee_id.department_id', store=True,
        string='Department (الإدارة)',
    )
    custody_type = fields.Selection([
        ('personal', 'فرعية — Personal Custody'),
        ('location', 'مكانية — Location Custody'),
    ], required=True, default='personal',
       string='Custody Type')

    issue_date = fields.Date(
        required=True, default=fields.Date.today,
        string='Issue Date',
    )
    clearance_status = fields.Selection([
        ('pending',      'Pending — معلق'),
        ('cleared',      'Cleared — مُصفَّى'),
        ('not_required', 'Not Required — غير مطلوب'),
    ], default='pending', tracking=True, index=True)

    clearance_doc_id = fields.Many2one(
        'custody.clearance', string='Clearance Document',
        readonly=True, copy=False, index=True,
    )
    ref_193 = fields.Char(
        string='استمارة 193 Reference',
        size=30, copy=False, readonly=True, index=True,
    )
    transfer_ids = fields.One2many(
        'custody.transfer', 'custody_move_id',
        string='Transfer History',
    )
    lot_id = fields.Many2one(
        'stock.lot', string='Serial / Lot Number',
        domain="[('product_id','=',product_id)]",
    )
    notes = fields.Text(string='Notes')

    # ── Constraints ─────────────────────────────────────────────────────
    @api.constrains('product_id')
    def _check_product_type(self):
        for rec in self:
            if rec.product_id.type not in ('product', 'consu'):
                raise ValidationError(_(
                    'العهدة الشخصية تشمل الأصناف المستديمة فقط.\n'
                    'الصنف المحدد ليس من نوع منتج مخزني.'
                ))

    # ── Sequence ──────────────────────────────────────────────────────────
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = (
                    self.env['ir.sequence'].next_by_code('custody.move')
                    or _('New')
                )
        return super().create(vals_list)

    # ── استمارة 193 ──────────────────────────────────────────────────────
    def action_issue_form_193(self):
        self.ensure_one()
        if self.custody_type != 'personal':
            raise UserError(_(
                'استمارة 193 تُصدر فقط للعهدة الفرعية (الشخصية).\n'
                'هذا السجل من نوع عهدة مكانية.'
            ))
        if not self.ref_193:
            self.ref_193 = (
                self.env['ir.sequence'].next_by_code('custody.form.193')
                or self.name
            )
        return self.env.ref(
            'l10n_eg_custody.report_form_193',
            raise_if_not_found=False,
        ).report_action(self)

    # ── Transfer ──────────────────────────────────────────────────────────
    def action_initiate_transfer(self, to_employee_id):
        self.ensure_one()
        if self.clearance_doc_id and self.clearance_status == 'pending':
            raise UserError(_(
                'لا يمكن نقل العهدة — يوجد إخلاء طرف معلق للموظف الحالي.'
            ))
        return self.env['custody.transfer'].create({
            'custody_move_id':  self.id,
            'from_employee_id': self.employee_id.id,
            'to_employee_id':   to_employee_id,
            'state':            'draft',
        })

    def action_confirm_transfer(self, transfer):
        self.ensure_one()
        self.write({
            'employee_id':      transfer.to_employee_id.id,
            'clearance_status': 'pending',
        })
        transfer.state = 'confirmed'

    def _get_hijri_date(self):
        try:
            from hijri_converter import convert  # noqa
            d = self.issue_date or fields.Date.today()
            h = convert.Gregorian(d.year, d.month, d.day).to_hijri()
            return '%d/%d/%d هـ' % (h.day, h.month, h.year)
        except ImportError:
            return ''
