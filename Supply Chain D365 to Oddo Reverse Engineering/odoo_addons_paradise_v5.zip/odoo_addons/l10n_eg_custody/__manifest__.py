# -*- coding: utf-8 -*-
{
    'name': 'Personal Custody — العهدة الشخصية (C12)',
    'version': '17.0.1.0.0',
    'summary': '3 models: custody.move, custody.transfer, custody.clearance | استمارة 193 | إخلاء طرف',
    'description': """
        C12 PersonalCustody
        ====================
        Tracks government-issued durable items (مستديم) assigned to individual
        employees as personal custody (عهدة شخصية).

        3 new models:
        - custody.move: core custody record — one per item-employee assignment
        - custody.transfer: transfer history between employees
        - custody.clearance: formal إخلاء طرف document

        Reports:
        - استمارة 193 ع.ح — personal custody issue form (double-column RTL)
        - كشف العهد الشخصية — employee custody register

        FRD: INV-04 العهدة الشخصية
        Client: الديوان العام لمحافظة بورسعيد
        Delivered by: Paradise Integrated Solutions
    """,
    'author': 'Paradise Integrated Solutions',
    'license': 'LGPL-3',
    'category': 'Inventory',
    'depends': ['stock', 'hr', 'mail'],
    'data': [
        'security/ir.model.access.csv',
        'data/sequences.xml',
        'views/custody_move_views.xml',
        'views/custody_transfer_views.xml',
        'views/custody_clearance_views.xml',
        'report/report_form_193.xml',
        'report/report_custody_register.xml',
        'report/report_actions.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
