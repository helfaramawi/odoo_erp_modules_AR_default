# -*- coding: utf-8 -*-
{
    'name': 'Government Payment Schedule — جداول الصرف الحكومية (C11)',
    'version': '17.0.1.0.0',
    'summary': 'Government payment: payment.schedule model, deductions, أمر الصرف PDF',
    'author': 'Paradise Integrated Solutions',
    'license': 'LGPL-3',
    'category': 'Accounting',
    'depends': ['account', 'l10n_eg_approval', 'purchase'],
    'data': [
        'security/ir.model.access.csv',
        'data/sequences.xml',
        'views/payment_schedule_views.xml',
        'report/report_payment_order.xml',
        'report/report_actions.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
