# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError

THRESHOLD_DEPUTY   = 50_000.0
THRESHOLD_GOVERNOR = 500_000.0


class PaymentSchedule(models.Model):
    _name = 'payment.schedule'
    _description = 'Government Payment Schedule — جدول الصرف الحكومي'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name desc'

    # ── Identity ──────────────────────────────────────────────────────────
    name = fields.Char(
        string='Payment Order No.',
        required=True, copy=False, readonly=True,
        default=lambda self: _('New'), index=True,
    )
    vendor_id = fields.Many2one(
        'res.partner', string='Vendor / Beneficiary',
        required=True, index=True,
    )
    purchase_order_id = fields.Many2one(
        'purchase.order',
        string='Source Purchase Order',
        index=True,
    )
    invoice_id = fields.Many2one(
        'account.move',
        string='Vendor Invoice',
        domain=[('move_type', '=', 'in_invoice'), ('state', '=', 'posted')],
        index=True,
    )
    description = fields.Text(
        string='Payment Subject (Arabic)',
        required=True,
        help='Printed on أمر الصرف.',
    )

    # ── Financial ─────────────────────────────────────────────────────────
    currency_id = fields.Many2one(
        'res.currency',
        default=lambda self: self.env.ref('base.EGP', raise_if_not_found=False),
    )
    gross_amount = fields.Monetary(
        string='Gross Amount (EGP)', required=True,
        currency_field='currency_id',
    )

    # ── Deductions ────────────────────────────────────────────────────────
    deduction_tax_pct = fields.Float(
        string='Tax Deduction %',
        default=0.0,
        help='Standard government tax withholding percentage.',
    )
    deduction_tax_amount = fields.Monetary(
        compute='_compute_deductions', store=True,
        string='Tax Deduction Amount',
        currency_field='currency_id',
    )
    deduction_guarantee_pct = fields.Float(
        string='Performance Guarantee % (ضمان حسن التنفيذ)',
        default=0.0,
    )
    deduction_guarantee_amount = fields.Monetary(
        compute='_compute_deductions', store=True,
        string='Performance Guarantee Amount',
        currency_field='currency_id',
    )
    deduction_advance_pct = fields.Float(
        string='Advance Recovery % (استرداد سلفة)',
        default=0.0,
    )
    deduction_advance_amount = fields.Monetary(
        compute='_compute_deductions', store=True,
        string='Advance Recovery Amount',
        currency_field='currency_id',
    )
    deduction_other = fields.Monetary(
        string='Other Deductions (EGP)',
        currency_field='currency_id',
    )
    total_deductions = fields.Monetary(
        compute='_compute_deductions', store=True,
        string='Total Deductions',
        currency_field='currency_id',
    )
    net_payable = fields.Monetary(
        compute='_compute_deductions', store=True,
        string='Net Payable (أمر الصرف)',
        currency_field='currency_id',
    )

    # ── Authority & State ─────────────────────────────────────────────────
    authority_level = fields.Selection([
        ('dept_head',       'مدير الإدارة'),
        ('deputy_governor', 'نائب المحافظ'),
        ('governor',        'المحافظ'),
    ], compute='_compute_authority', store=True)

    state = fields.Selection([
        ('draft',     'Draft — مسودة'),
        ('submitted', 'Submitted — مقدم'),
        ('approved',  'Approved — معتمد'),
        ('paid',      'Paid — مصروف'),
        ('cancelled', 'Cancelled — ملغى'),
    ], default='draft', tracking=True, index=True)

    payment_date = fields.Date(string='Payment Date')
    payment_ref  = fields.Char(string='Bank/Treasury Reference')
    account_move_id = fields.Many2one(
        'account.move', string='Journal Entry', readonly=True, copy=False,
    )
    payment_method = fields.Selection([
        ('bank_transfer', 'تحويل بنكي'),
        ('cheque',        'شيك'),
        ('cash',          'نقداً'),
    ], default='bank_transfer')

    # ── Computed ──────────────────────────────────────────────────────────
    @api.depends('gross_amount',
                 'deduction_tax_pct',
                 'deduction_guarantee_pct',
                 'deduction_advance_pct',
                 'deduction_other')
    def _compute_deductions(self):
        for rec in self:
            tax   = rec.gross_amount * rec.deduction_tax_pct       / 100
            guar  = rec.gross_amount * rec.deduction_guarantee_pct  / 100
            adv   = rec.gross_amount * rec.deduction_advance_pct    / 100
            other = rec.deduction_other
            total = tax + guar + adv + other
            rec.deduction_tax_amount       = tax
            rec.deduction_guarantee_amount = guar
            rec.deduction_advance_amount   = adv
            rec.total_deductions           = total
            rec.net_payable                = rec.gross_amount - total

    @api.depends('net_payable')
    def _compute_authority(self):
        for rec in self:
            if rec.net_payable < THRESHOLD_DEPUTY:
                rec.authority_level = 'dept_head'
            elif rec.net_payable < THRESHOLD_GOVERNOR:
                rec.authority_level = 'deputy_governor'
            else:
                rec.authority_level = 'governor'

    # ── Sequence ──────────────────────────────────────────────────────────
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = (
                    self.env['ir.sequence'].next_by_code('payment.schedule')
                    or _('New')
                )
        return super().create(vals_list)

    # ── Actions ────────────────────────────────────────────────────────────
    def action_submit(self):
        self.ensure_one()
        if self.net_payable <= 0:
            raise UserError(_(
                'المبلغ الصافي يجب أن يكون أكبر من صفر.'
            ))
        self.state = 'submitted'

    def action_approve(self):
        self.ensure_one()
        self.state = 'approved'
        self.message_post(body=_(
            'تم اعتماد أمر الصرف بواسطة %(user)s بمبلغ %(amount)s ج.م',
            user=self.env.user.name,
            amount='%.2f' % self.net_payable,
        ))

    def action_pay(self):
        """Create journal entry and mark as paid."""
        self.ensure_one()
        if not self.payment_date:
            raise UserError(_('يجب تحديد تاريخ الصرف.'))
        if self.state != 'approved':
            raise UserError(_('يجب اعتماد أمر الصرف قبل الصرف.'))

        journal = self.env['account.journal'].search(
            [('type', 'in', ['bank', 'cash'])], limit=1,
        )
        if not journal:
            raise UserError(_('لا يوجد دفتر يومية بنكي أو نقدي. يُرجى إنشاء دفتر يومية أولاً.'))

        payable_acct = self.env['account.account'].search(
            [('account_type', '=', 'liability_payable')], limit=1,
        )
        move = self.env['account.move'].create({
            'journal_id': journal.id,
            'date': self.payment_date,
            'ref': 'أمر صرف: ' + self.name,
            'move_type': 'entry',
            'line_ids': [
                (0, 0, {
                    'account_id': payable_acct.id if payable_acct else journal.default_account_id.id,
                    'partner_id': self.vendor_id.id,
                    'debit': self.net_payable,
                    'credit': 0.0,
                    'name': self.description,
                }),
                (0, 0, {
                    'account_id': journal.default_account_id.id,
                    'partner_id': self.vendor_id.id,
                    'debit': 0.0,
                    'credit': self.net_payable,
                    'name': self.description,
                }),
            ],
        })
        move.action_post()
        self.account_move_id = move
        self.state = 'paid'

    # ── Print ──────────────────────────────────────────────────────────────
    def action_print_payment_order(self):
        return self.env.ref(
            'l10n_eg_gov_payment.report_payment_order',
        ).report_action(self)

    # ── Helpers ────────────────────────────────────────────────────────────
    def _get_authority_title(self):
        titles = {
            'dept_head':       'مدير الإدارة المختصة',
            'deputy_governor': 'نائب المحافظ',
            'governor':        'المحافظ',
        }
        return titles.get(self.authority_level, 'المدير المختص')

    def _amount_in_words_ar(self):
        try:
            from num2words import num2words  # noqa
            return num2words(self.net_payable, lang='ar',
                             to='currency', currency='EGP')
        except (ImportError, NotImplementedError):
            return '%.2f جنيه مصري' % self.net_payable

    def _get_hijri_date(self):
        try:
            from hijri_converter import convert  # noqa
            d = fields.Date.today()
            h = convert.Gregorian(d.year, d.month, d.day).to_hijri()
            return '%d/%d/%d هـ' % (h.day, h.month, h.year)
        except ImportError:
            return ''
