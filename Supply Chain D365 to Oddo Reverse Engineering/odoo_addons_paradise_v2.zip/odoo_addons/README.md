# الديوان العام لمحافظة بورسعيد — Odoo 17 Custom Addons
## Paradise Integrated Solutions — D365 F&O → Odoo 17 Migration

---

## Installation Order (STRICT — do not change)

```
1. l10n_eg_tender          (C-PR01) — Install FIRST — foundation for everything
2. l10n_eg_commitment      (C1)     — Install SECOND — finance foundation
3. l10n_eg_tender_public   (C-PR02) — Install THIRD — depends on C-PR01
```

---

## Addons in this package

### l10n_eg_tender (C-PR01) — GovernmentTenderLifecycle
**Foundation module — must be installed before all others.**

- `procurement.tender` model: 6-stage lifecycle (draft→committee→published→evaluation→award→contract)
- 3-tier approval authority matrix: مدير الإدارة (<50K) | نائب المحافظ (50K–500K) | المحافظ (>500K)
- Sovereign entity (PR-07) bypass workflow with `jihat_siyadiya` + `jihat_code` enforcement
- Arabic QWeb document engine: base template inherited by all C-PR02–06 templates
- إخطار الترسية award notification report
- PO auto-creation on contract stage transition
- 8 unit tests (TC-01 to TC-08)

**Key files:**
- `models/procurement_tender.py` — core model with all stage logic
- `models/procurement_committee.py` — committee model
- `models/procurement_document.py` — document tracking
- `report/base_tender_doc.xml` — base Arabic RTL QWeb template

---

### l10n_eg_commitment (C1) — CommitmentLedger
**Non-negotiable — declared Day 1 by Dir. Al-Masri.**

- `commitment.line` model: one per PO line, tracks committed/received/released/net amounts
- `commitment.config` model: per-company configuration (journal, DR/CR accounts, flags)
- `purchase.order` extension: hooks `button_approve` → `_create_commitment_entries()` and `button_cancel` → `_cancel_commitment()`
- `stock.picking` extension: hooks `button_validate` → `_reverse_commitment_on_receipt()` (proportional)
- `crossovered.budget.lines` extension: `committed_amount`, `available_amount`, `check_budget_availability()` (used by C6)
- Sequence: CMT/YYYY/NNNN
- 10 unit tests (TC-01 to TC-10)

**Requires Odoo Enterprise `account_budget` module (crossovered.budget).**

**Setup after install:**
1. Go to: الشؤون المالية > إعدادات > إعدادات محاسبة الالتزامات
2. Create one commitment config record with:
   - Journal: create a new General journal named "دفتر الالتزامات"
   - DR Account: create account "حساب مصروفات الالتزامات"
   - CR Account: create account "احتياطي مقابل الالتزامات"

---

### l10n_eg_tender_public (C-PR02) — PublicTenderPipeline
**Depends on: l10n_eg_tender (C-PR01)**

- `bid.envelope` model: vendor submissions with deadline enforcement and duplicate prevention
- `tender.evaluation` model: البت الفني/المالي evaluation rounds linked to committees
- `tender.sample.receipt` model: كشف استلام العينات
- `procurement.tender` extension: bid pipeline (open envelopes → technical eval → financial ranking)
- Financial ranking: ascending price order (lowest = rank 1 = winner)
- Auto-sets `winning_bid_id` and `partner_id` on financial evaluation
- 6 Arabic QWeb report templates:
  - محضر فتح المظاريف
  - محضر البت الفني أ
  - محضر البت الفني ب
  - محضر البت المالي الأول (with C-PR06 negotiation extension point)
  - محضر البت المالي الثاني
  - نموذج حصر الشركات
- 14 unit tests (TC-01 to TC-14)

---

## Python Dependencies (pip install on Odoo server)

```bash
pip install hijri-converter>=2.3.1    # Hijri date display in all Arabic reports
pip install num2words>=0.5.12         # Arabic amount-in-words for استمارة 50
```

---

## Running Tests

```bash
# All custom addon tests:
odoo-bin --test-enable -d <your_db> \
  -i l10n_eg_tender,l10n_eg_commitment,l10n_eg_tender_public \
  --stop-after-init

# Individual addon:
odoo-bin --test-enable -d <your_db> -i l10n_eg_tender --stop-after-init
```

---

## File Counts

| Addon | Python | XML | CSV | Tests |
|-------|--------|-----|-----|-------|
| l10n_eg_tender | 6 | 9 | 1 | 8 |
| l10n_eg_commitment | 6 | 7 | 1 | 10 |
| l10n_eg_tender_public | 5 | 12 | 1 | 14 |
| **TOTAL** | **17** | **28** | **3** | **32** |

---

## Status

| Module | Addon | Status |
|--------|-------|--------|
| C-PR01 GovernmentTenderLifecycle | l10n_eg_tender | ✅ Complete |
| C-PR02 PublicTenderPipeline | l10n_eg_tender_public | ✅ Complete |
| C1 CommitmentLedger | l10n_eg_commitment | ✅ Complete |
| C-PR03 through C-PR06, C2–C13, C12, C-INV series | TBD | 🔜 In progress |

---

*Paradise Integrated Solutions × الديوان العام لمحافظة بورسعيد*
*D365 F&O → Odoo 17 | Phase 5 Implementation*
