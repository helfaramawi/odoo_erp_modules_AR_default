# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class CommitmentConfig(models.Model):
    _name = 'commitment.config'
    _description = 'Commitment Accounting Configuration — إعدادات محاسبة الالتزامات'
    _rec_name = 'company_id'

    company_id = fields.Many2one(
        'res.company',
        string='Company',
        required=True,
        default=lambda self: self.env.company,
        unique=True,
    )
    commitment_journal_id = fields.Many2one(
        'account.journal',
        string='Commitment Journal (دفتر الالتزامات)',
        required=True,
        domain=[('type', '=', 'general')],
        help='Dedicated journal for all commitment entries. '
             'Separates commitment entries from regular accounting.',
    )
    commitment_expense_account_id = fields.Many2one(
        'account.account',
        string='Commitment Expense Account (DR)',
        required=True,
        help='حساب مصروفات الالتزامات — debited when PO is committed.',
    )
    commitment_reserve_account_id = fields.Many2one(
        'account.account',
        string='Commitment Reserve Account (CR)',
        required=True,
        help='احتياطي مقابل الالتزامات — credited when PO is committed.',
    )
    auto_reverse_on_receive = fields.Boolean(
        string='Auto-Reverse on GRN',
        default=True,
        help='Automatically reverse commitment proportionally on each GRN validation.',
    )
    auto_reverse_on_cancel = fields.Boolean(
        string='Auto-Reverse on PO Cancel',
        default=True,
        help='Automatically reverse full commitment when PO is cancelled.',
    )
    budget_hard_block = fields.Boolean(
        string='Hard Budget Block',
        default=True,
        help='Block PO confirmation if budget line has insufficient available amount. '
             'Used by C6 BudgetControl.',
    )
    sync_cron_active = fields.Boolean(
        string='Activate Nightly Sync Cron',
        default=True,
        help='Used by C8 BatchJobs — CommitmentSync cron.',
    )

    _sql_constraints = [
        ('company_unique', 'unique(company_id)',
         'Only one commitment configuration per company is allowed.'),
    ]

    @api.model
    def get_config(self, company_id=None):
        """Helper to get config for a company. Raises if not configured."""
        company_id = company_id or self.env.company.id
        cfg = self.search([('company_id', '=', company_id)], limit=1)
        if not cfg:
            raise UserError(_(
                'يجب إعداد إعدادات محاسبة الالتزامات أولاً.\n'
                'انتقل إلى: الشؤون المالية > إعدادات > محاسبة الالتزامات'
            ))
        return cfg
