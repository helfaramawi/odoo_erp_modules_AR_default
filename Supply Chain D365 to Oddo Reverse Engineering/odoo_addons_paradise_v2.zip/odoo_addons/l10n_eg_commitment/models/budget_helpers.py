# -*- coding: utf-8 -*-
from odoo import models, fields, api, _


class CrossoveredBudgetLinesCommitment(models.Model):
    _inherit = 'crossovered.budget.lines'

    committed_amount = fields.Monetary(
        compute='_compute_committed',
        store=True,
        string='Committed (EGP)',
        help='Total active commitments (POs approved but not yet received/invoiced)',
    )
    available_amount = fields.Monetary(
        compute='_compute_committed',
        store=True,
        string='Available Budget (EGP)',
        help='Planned - Committed - Invoiced = Truly available budget',
    )

    @api.depends('planned_amount', 'practical_amount')
    def _compute_committed(self):
        for line in self:
            active_commitments = self.env['commitment.line'].search([
                ('budget_line_id', '=', line.id),
                ('state', 'in', ('active', 'partially_received')),
            ])
            line.committed_amount = sum(
                active_commitments.mapped('net_commitment')
            )
            # practical_amount is negative in Odoo (credited amounts)
            line.available_amount = (
                line.planned_amount
                - line.committed_amount
                - abs(line.practical_amount or 0.0)
            )

    def check_budget_availability(self, amount):
        """
        Called by C6 BudgetControl before PO approval.

        Returns:
            (True, '')                   if budget is sufficient
            (False, Arabic error message) if insufficient
        """
        self.ensure_one()
        self._compute_committed()   # Force recompute for real-time check

        if self.available_amount >= amount:
            return True, ''

        return False, _(
            'الميزانية المتاحة غير كافية\n'
            '━━━━━━━━━━━━━━━━━━━━━━━━━\n'
            'الميزانية المخططة : %(planned)s ج.م\n'
            'الالتزامات المعتمدة: %(committed)s ج.م\n'
            'المصروف الفعلي   : %(invoiced)s ج.م\n'
            'المتاح الفعلي    : %(available)s ج.م\n'
            '━━━━━━━━━━━━━━━━━━━━━━━━━\n'
            'المبلغ المطلوب   : %(required)s ج.م\n'
            'العجز            : %(shortfall)s ج.م',
            planned=   '%.2f' % self.planned_amount,
            committed= '%.2f' % self.committed_amount,
            invoiced=  '%.2f' % abs(self.practical_amount or 0.0),
            available= '%.2f' % self.available_amount,
            required=  '%.2f' % amount,
            shortfall= '%.2f' % (amount - self.available_amount),
        )

    def _reconcile_budget_vs_committed(self):
        """
        Nightly reconciliation called by C8 CommitmentSync cron.
        Checks commitment.line amounts against actual stock.move and
        account.move data. Logs discrepancies.
        """
        lines = self.search([])
        for line in lines:
            utilisation_pct = 0.0
            if line.planned_amount > 0:
                utilisation_pct = (
                    (line.committed_amount + abs(line.practical_amount or 0.0))
                    / line.planned_amount * 100
                )
            if utilisation_pct >= 90:
                # Alert finance team
                self.env['mail.message'].sudo().create({
                    'subject': _('تحذير: تجاوز 90%% من الميزانية — %s')
                               % (line.analytic_account_id.name or 'N/A'),
                    'body':    _(
                        'بند الميزانية %(budget)s وصل إلى %(pct).1f%% من '
                        'الإجمالي المخطط.\n'
                        'المتاح: %(available).2f ج.م',
                        budget=line.analytic_account_id.name or 'N/A',
                        pct=utilisation_pct,
                        available=line.available_amount,
                    ),
                    'model':   'crossovered.budget.lines',
                    'res_id':  line.id,
                    'message_type': 'comment',
                    'subtype_id':   self.env.ref(
                        'mail.mt_note',
                        raise_if_not_found=False,
                    ) and self.env.ref('mail.mt_note').id,
                })
