# -*- coding: utf-8 -*-
from odoo import models, fields, api, _


class CommitmentLine(models.Model):
    _name = 'commitment.line'
    _description = 'Budget Commitment Line — سطر الالتزام'
    _order = 'name desc'
    _rec_name = 'name'

    name = fields.Char(
        string='Commitment Reference',
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: _('New'),
        index=True,
    )
    purchase_order_id = fields.Many2one(
        'purchase.order',
        string='Purchase Order',
        required=True,
        ondelete='restrict',
        index=True,
    )
    purchase_line_id = fields.Many2one(
        'purchase.order.line',
        string='PO Line',
        required=True,
        ondelete='restrict',
    )
    account_id = fields.Many2one(
        'account.account',
        string='Budget Account',
        required=True,
    )
    analytic_account_id = fields.Many2one(
        'account.analytic.account',
        string='Cost Center',
        index=True,
    )
    budget_line_id = fields.Many2one(
        'crossovered.budget.lines',
        string='Budget Line',
        index=True,
    )
    currency_id = fields.Many2one(
        'res.currency',
        default=lambda self: self.env.ref('base.EGP', raise_if_not_found=False),
        required=True,
    )
    committed_amount = fields.Monetary(
        string='Committed Amount (EGP)',
        currency_field='currency_id',
        required=True,
    )
    received_amount = fields.Monetary(
        string='Received Amount',
        currency_field='currency_id',
        default=0.0,
    )
    invoiced_amount = fields.Monetary(
        string='Invoiced Amount',
        currency_field='currency_id',
        default=0.0,
    )
    released_amount = fields.Monetary(
        string='Released Amount',
        currency_field='currency_id',
        default=0.0,
    )
    net_commitment = fields.Monetary(
        string='Net Commitment (Remaining)',
        compute='_compute_net',
        store=True,
        currency_field='currency_id',
    )
    state = fields.Selection([
        ('active',             'Active — نشط'),
        ('partially_received', 'Partially Received — مستلم جزئياً'),
        ('fully_received',     'Fully Received — مستلم كلياً'),
        ('cancelled',          'Cancelled — ملغى'),
        ('closed',             'Closed — مغلق'),
    ], default='active', string='Status', index=True, tracking=True)

    move_id = fields.Many2one(
        'account.move',
        string='Commitment Entry',
        readonly=True,
        copy=False,
    )
    reversal_move_ids = fields.One2many(
        'account.move',
        'commitment_line_id',
        string='Reversal Entries',
        readonly=True,
    )
    fiscal_year = fields.Char(
        string='Fiscal Year',
        size=4,
        required=True,
        default=lambda self: str(fields.Date.today().year),
        index=True,
    )
    company_id = fields.Many2one(
        related='purchase_order_id.company_id',
        store=True,
    )

    @api.depends('committed_amount', 'received_amount', 'released_amount')
    def _compute_net(self):
        for rec in self:
            rec.net_commitment = (
                rec.committed_amount
                - rec.received_amount
                - rec.released_amount
            )

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = (
                    self.env['ir.sequence'].next_by_code('commitment.line')
                    or _('New')
                )
        return super().create(vals_list)
