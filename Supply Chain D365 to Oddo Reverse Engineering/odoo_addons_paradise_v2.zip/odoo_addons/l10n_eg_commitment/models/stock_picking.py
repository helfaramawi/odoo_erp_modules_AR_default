# -*- coding: utf-8 -*-
from odoo import models, fields, _
from odoo.exceptions import UserError


class StockPickingCommitment(models.Model):
    _inherit = 'stock.picking'

    def button_validate(self):
        res = super().button_validate()
        # After validation, reverse commitment for incoming receipts
        for picking in self.filtered(
            lambda p: p.picking_type_code == 'incoming'
            and p.purchase_id
        ):
            try:
                picking._reverse_commitment_on_receipt()
            except UserError:
                pass  # Config not set — skip silently
        return res

    def _reverse_commitment_on_receipt(self):
        """Proportionally release commitment for received quantities."""
        try:
            cfg = self.env['commitment.config'].get_config(
                self.company_id.id)
        except UserError:
            return

        if not cfg.auto_reverse_on_receive:
            return

        po = self.purchase_id
        for move_line in self.move_line_ids:
            po_line = move_line.move_id.purchase_line_id
            if not po_line:
                continue

            commitment = po.commitment_ids.filtered(
                lambda c: c.purchase_line_id == po_line
                and c.state in ('active', 'partially_received')
            )
            if not commitment:
                continue

            cl = commitment[0]
            qty_ordered  = po_line.product_qty
            qty_received = move_line.qty_done

            if qty_ordered <= 0 or qty_received <= 0:
                continue

            reversal_pct    = min(qty_received / qty_ordered, 1.0)
            reversal_amount = cl.committed_amount * reversal_pct
            reversal_amount = min(reversal_amount, cl.net_commitment)

            if reversal_amount <= 0:
                continue

            # Post proportional reversal
            reversal_move = self.env['account.move'].create({
                'journal_id': cfg.commitment_journal_id.id,
                'date':       fields.Date.today(),
                'ref':        'استلام جزئي — ' + self.name,
                'move_type':  'entry',
                'company_id': self.company_id.id,
                'line_ids': [
                    (0, 0, {
                        'account_id': cfg.commitment_reserve_account_id.id,
                        'debit':      reversal_amount,
                        'credit':     0.0,
                        'name':       'تحرير التزام: ' + cl.name,
                    }),
                    (0, 0, {
                        'account_id': cfg.commitment_expense_account_id.id,
                        'debit':      0.0,
                        'credit':     reversal_amount,
                        'name':       'تحرير التزام: ' + cl.name,
                    }),
                ],
            })
            reversal_move.action_post()

            new_received = cl.received_amount + reversal_amount
            remaining = cl.net_commitment - reversal_amount

            cl.write({
                'received_amount': new_received,
                'state': 'fully_received' if remaining <= 0.01
                         else 'partially_received',
            })
