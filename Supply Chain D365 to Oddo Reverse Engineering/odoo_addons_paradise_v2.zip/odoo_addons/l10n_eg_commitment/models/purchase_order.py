# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class PurchaseOrderCommitment(models.Model):
    _inherit = 'purchase.order'

    commitment_ids = fields.One2many(
        'commitment.line',
        'purchase_order_id',
        string='Commitment Lines',
    )
    total_committed = fields.Monetary(
        compute='_compute_total_committed',
        store=True,
        string='Total Committed (EGP)',
        currency_field='currency_id',
    )
    commitment_state = fields.Selection([
        ('uncommitted',        'Uncommitted'),
        ('committed',          'Committed — ملتزم'),
        ('partially_released', 'Partially Released'),
        ('released',           'Released — محرر'),
    ], compute='_compute_commitment_state', store=True,
       string='Commitment Status')

    @api.depends('commitment_ids.net_commitment')
    def _compute_total_committed(self):
        for order in self:
            order.total_committed = sum(
                order.commitment_ids.mapped('net_commitment')
            )

    @api.depends('commitment_ids.state')
    def _compute_commitment_state(self):
        for order in self:
            states = order.commitment_ids.mapped('state')
            if not states:
                order.commitment_state = 'uncommitted'
            elif all(s in ('fully_received', 'cancelled', 'closed')
                     for s in states):
                order.commitment_state = 'released'
            elif any(s == 'partially_received' for s in states):
                order.commitment_state = 'partially_released'
            else:
                order.commitment_state = 'committed'

    # ── Override button_approve ────────────────────────────────────────────
    def button_approve(self, force=False):
        res = super().button_approve(force=force)
        for order in self.filtered(lambda o: o.state == 'purchase'):
            try:
                order._create_commitment_entries()
            except UserError:
                # Config not set — log warning but don't block approval
                pass
        return res

    def _create_commitment_entries(self):
        """Create one commitment.line per PO line and post journal entry."""
        cfg = self.env['commitment.config'].get_config(self.company_id.id)

        move_vals = {
            'journal_id':  cfg.commitment_journal_id.id,
            'date':        fields.Date.today(),
            'ref':         'التزام: ' + self.name,
            'move_type':   'entry',
            'company_id':  self.company_id.id,
            'line_ids':    [],
        }
        commitment_vals_list = []

        for pol in self.order_line:
            amount = pol.price_subtotal
            if amount <= 0:
                continue

            # DR: Commitment expense account
            move_vals['line_ids'].append((0, 0, {
                'account_id':          cfg.commitment_expense_account_id.id,
                'analytic_account_id': pol.account_analytic_id.id
                                        if pol.account_analytic_id else False,
                'debit':               amount,
                'credit':              0.0,
                'name':                'التزام: ' + (pol.name or pol.product_id.name or ''),
            }))
            # CR: Commitment reserve account
            move_vals['line_ids'].append((0, 0, {
                'account_id':  cfg.commitment_reserve_account_id.id,
                'debit':       0.0,
                'credit':      amount,
                'name':        'احتياطي الالتزام: ' + (pol.name or ''),
            }))

            commitment_vals_list.append({
                'purchase_order_id':   self.id,
                'purchase_line_id':    pol.id,
                'account_id':          cfg.commitment_expense_account_id.id,
                'analytic_account_id': pol.account_analytic_id.id
                                        if pol.account_analytic_id else False,
                'committed_amount':    amount,
                'fiscal_year':         str(fields.Date.today().year),
            })

        if not move_vals['line_ids']:
            return

        move = self.env['account.move'].create(move_vals)
        move.action_post()

        for cv in commitment_vals_list:
            cv['move_id'] = move.id

        self.env['commitment.line'].create(commitment_vals_list)

    # ── Override button_cancel ─────────────────────────────────────────────
    def button_cancel(self):
        for order in self:
            if order.commitment_ids.filtered(lambda c: c.state == 'active'):
                order._cancel_commitment()
        return super().button_cancel()

    def _cancel_commitment(self):
        """Reverse all active commitment lines on PO cancellation."""
        try:
            cfg = self.env['commitment.config'].get_config(self.company_id.id)
        except UserError:
            return

        if not cfg.auto_reverse_on_cancel:
            return

        active_lines = self.commitment_ids.filtered(
            lambda c: c.state == 'active'
        )
        for cl in active_lines:
            reversal_amount = cl.net_commitment
            if reversal_amount <= 0:
                cl.state = 'cancelled'
                continue

            reversal_move = self.env['account.move'].create({
                'journal_id':  cfg.commitment_journal_id.id,
                'date':        fields.Date.today(),
                'ref':         'إلغاء التزام: ' + self.name,
                'move_type':   'entry',
                'company_id':  self.company_id.id,
                'line_ids': [
                    (0, 0, {
                        'account_id': cfg.commitment_reserve_account_id.id,
                        'debit':      reversal_amount,
                        'credit':     0.0,
                        'name':       'إلغاء احتياطي: ' + cl.name,
                    }),
                    (0, 0, {
                        'account_id': cfg.commitment_expense_account_id.id,
                        'debit':      0.0,
                        'credit':     reversal_amount,
                        'name':       'إلغاء التزام: ' + cl.name,
                    }),
                ],
            })
            reversal_move.action_post()

            cl.write({
                'released_amount': cl.net_commitment,
                'state':           'cancelled',
            })

    # ── Smart button ──────────────────────────────────────────────────────
    def action_view_commitments(self):
        return {
            'name': _('Commitment Lines — الالتزامات'),
            'type': 'ir.actions.act_window',
            'res_model': 'commitment.line',
            'view_mode': 'list,form',
            'domain': [('purchase_order_id', '=', self.id)],
            'context': {'default_purchase_order_id': self.id},
        }
