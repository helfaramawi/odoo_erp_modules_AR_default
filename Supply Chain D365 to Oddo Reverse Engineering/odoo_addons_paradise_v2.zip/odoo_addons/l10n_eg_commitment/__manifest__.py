# -*- coding: utf-8 -*-
{
    'name': 'Commitment Ledger — محاسبة الالتزامات (C1)',
    'version': '17.0.1.0.0',
    'summary': 'Budget commitment accounting: encumber budget on PO approval, reverse on receipt/cancellation',
    'description': """
        C1 CommitmentLedger
        ====================
        Implements budget commitment accounting (محاسبة الالتزامات) for
        الديوان العام لمحافظة بورسعيد. Non-negotiable — declared Day 1.

        Features:
        - commitment.line model: one per PO line
        - Journal entry on PO approval: DR commitment expense / CR commitment reserve
        - Proportional reversal on GRN (stock.picking.button_validate)
        - Full reversal on PO cancellation (button_cancel)
        - check_budget_availability() helper used by C6 BudgetControl
        - crossovered.budget.lines extension: committed_amount + available_amount
        - Nightly sync cron method (called by C8 BatchJobs)

        FRD: Finance Module C1
        Client: الديوان العام لمحافظة بورسعيد
        Delivered by: Paradise Integrated Solutions
    """,
    'author': 'Paradise Integrated Solutions',
    'license': 'LGPL-3',
    'category': 'Accounting',
    'depends': [
        'purchase',
        'account',
        'stock',
        'account_budget',   # crossovered.budget (Odoo Enterprise)
    ],
    'data': [
        'security/ir.model.access.csv',
        'data/sequences.xml',
        'views/commitment_line_views.xml',
        'views/commitment_config_views.xml',
        'views/purchase_order_views.xml',
        'views/menu.xml',
        'report/report_commitment_status.xml',
        'report/report_actions.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
