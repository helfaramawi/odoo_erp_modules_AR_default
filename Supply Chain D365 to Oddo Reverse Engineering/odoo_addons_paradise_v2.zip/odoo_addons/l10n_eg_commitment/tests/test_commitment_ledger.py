# -*- coding: utf-8 -*-
from odoo.tests.common import TransactionCase
from odoo.exceptions import UserError


class TestCommitmentLedger(TransactionCase):
    """10 unit tests for C1 CommitmentLedger."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.company = cls.env.company

        # Create commitment journal
        cls.journal = cls.env['account.journal'].create({
            'name': 'دفتر الالتزامات - Test',
            'code': 'CMT',
            'type': 'general',
            'company_id': cls.company.id,
        })

        # Create commitment accounts
        cls.expense_acct = cls.env['account.account'].create({
            'name': 'مصروفات الالتزامات',
            'code': 'CMT-EXP-TEST',
            'account_type': 'expense',
            'company_id': cls.company.id,
        })
        cls.reserve_acct = cls.env['account.account'].create({
            'name': 'احتياطي الالتزامات',
            'code': 'CMT-RSV-TEST',
            'account_type': 'liability_current',
            'company_id': cls.company.id,
        })

        # Create commitment config
        cls.cfg = cls.env['commitment.config'].create({
            'company_id':                     cls.company.id,
            'commitment_journal_id':           cls.journal.id,
            'commitment_expense_account_id':   cls.expense_acct.id,
            'commitment_reserve_account_id':   cls.reserve_acct.id,
            'auto_reverse_on_receive':         True,
            'auto_reverse_on_cancel':          True,
            'budget_hard_block':               True,
        })

        # Vendor
        cls.vendor = cls.env['res.partner'].create({
            'name': 'مورد الاختبار',
            'supplier_rank': 1,
        })

        # Product
        cls.product = cls.env['product.product'].create({
            'name': 'صنف اختبار',
            'type': 'product',
        })

    def _make_po(self, amounts):
        """Create and return a draft PO with lines for each amount."""
        po = self.env['purchase.order'].create({
            'partner_id': self.vendor.id,
            'company_id': self.company.id,
        })
        for amount in amounts:
            self.env['purchase.order.line'].create({
                'order_id':    po.id,
                'product_id':  self.product.id,
                'product_qty': 1,
                'price_unit':  amount,
                'name':        'Test Line %.0f' % amount,
            })
        return po

    # TC-01 — Commitment lines created on PO approval
    def test_01_commitment_created_on_approval(self):
        po = self._make_po([10000, 5000])
        po.button_confirm()
        po.button_approve()
        self.assertEqual(len(po.commitment_ids), 2)
        amounts = sorted(po.commitment_ids.mapped('committed_amount'))
        self.assertEqual(amounts, [5000.0, 10000.0])
        for cl in po.commitment_ids:
            self.assertEqual(cl.state, 'active')

    # TC-02 — Journal entry posted on PO approval
    def test_02_journal_entry_posted(self):
        po = self._make_po([15000])
        po.button_confirm()
        po.button_approve()
        self.assertTrue(po.commitment_ids, 'No commitment lines created')
        move = po.commitment_ids[0].move_id
        self.assertTrue(move, 'No journal entry created')
        self.assertEqual(move.state, 'posted')
        # DR commitment expense = 15000
        dr_line = move.line_ids.filtered(
            lambda l: l.account_id == self.expense_acct)
        self.assertTrue(dr_line, 'No DR line on commitment entry')
        self.assertAlmostEqual(sum(dr_line.mapped('debit')), 15000.0)
        # CR commitment reserve = 15000
        cr_line = move.line_ids.filtered(
            lambda l: l.account_id == self.reserve_acct)
        self.assertTrue(cr_line, 'No CR line on commitment entry')
        self.assertAlmostEqual(sum(cr_line.mapped('credit')), 15000.0)

    # TC-03 — net_commitment computed correctly
    def test_03_net_commitment_computation(self):
        po = self._make_po([10000])
        po.button_confirm()
        po.button_approve()
        cl = po.commitment_ids[0]
        self.assertAlmostEqual(cl.net_commitment, 10000.0)
        cl.received_amount = 4000.0
        cl._compute_net()
        self.assertAlmostEqual(cl.net_commitment, 6000.0)

    # TC-04 — Commitment cancelled on PO cancel
    def test_04_commitment_cancelled_on_po_cancel(self):
        po = self._make_po([8000])
        po.button_confirm()
        po.button_approve()
        self.assertEqual(po.commitment_ids[0].state, 'active')
        po.button_cancel()
        self.assertEqual(po.commitment_ids[0].state, 'cancelled')
        self.assertAlmostEqual(po.commitment_ids[0].net_commitment, 0.0)

    # TC-05 — Reversal journal entry posted on cancel
    def test_05_reversal_entry_on_cancel(self):
        po = self._make_po([12000])
        po.button_confirm()
        po.button_approve()
        po.button_cancel()
        cl = po.commitment_ids[0]
        # State should be cancelled
        self.assertEqual(cl.state, 'cancelled')
        # released_amount should equal original committed_amount
        self.assertAlmostEqual(cl.released_amount, 12000.0)

    # TC-06 — total_committed on PO sums commitment lines
    def test_06_total_committed_on_po(self):
        po = self._make_po([10000, 5000])
        po.button_confirm()
        po.button_approve()
        self.assertAlmostEqual(po.total_committed, 15000.0)

    # TC-07 — commitment_state transitions
    def test_07_commitment_state_uncommitted(self):
        po = self._make_po([10000])
        # Before approval — no commitment lines
        self.assertEqual(po.commitment_state, 'uncommitted')

    def test_07b_commitment_state_committed(self):
        po = self._make_po([10000])
        po.button_confirm()
        po.button_approve()
        self.assertEqual(po.commitment_state, 'committed')

    # TC-08 — check_budget_availability returns True when sufficient
    def test_08_budget_available(self):
        # Create a budget line
        analytic = self.env['account.analytic.account'].create({
            'name': 'Test Cost Center',
            'plan_id': self.env['account.analytic.plan'].search([], limit=1).id
                       if self.env['account.analytic.plan'].search([], limit=1)
                       else self.env['account.analytic.plan'].create(
                           {'name': 'Test Plan'}).id,
        })
        budget = self.env['crossovered.budget'].create({
            'name': 'Test Budget 2025',
            'date_from': '2025-01-01',
            'date_to': '2025-12-31',
        })
        bline = self.env['crossovered.budget.lines'].create({
            'crossovered_budget_id': budget.id,
            'analytic_account_id': analytic.id,
            'planned_amount': 100000,
            'date_from': '2025-01-01',
            'date_to': '2025-12-31',
        })
        ok, msg = bline.check_budget_availability(50000)
        self.assertTrue(ok, 'Budget should be sufficient: %s' % msg)
        self.assertEqual(msg, '')

    # TC-09 — check_budget_availability returns False when insufficient
    def test_09_budget_insufficient(self):
        analytic = self.env['account.analytic.account'].create({
            'name': 'Test Cost Center 2',
            'plan_id': self.env['account.analytic.plan'].search([], limit=1).id
                       if self.env['account.analytic.plan'].search([], limit=1)
                       else self.env['account.analytic.plan'].create(
                           {'name': 'Test Plan 2'}).id,
        })
        budget = self.env['crossovered.budget'].create({
            'name': 'Test Budget 2025 Small',
            'date_from': '2025-01-01',
            'date_to': '2025-12-31',
        })
        bline = self.env['crossovered.budget.lines'].create({
            'crossovered_budget_id': budget.id,
            'analytic_account_id': analytic.id,
            'planned_amount': 10000,
            'date_from': '2025-01-01',
            'date_to': '2025-12-31',
        })
        ok, msg = bline.check_budget_availability(50000)
        self.assertFalse(ok, 'Budget should be insufficient')
        self.assertIn('الميزانية المتاحة غير كافية', msg)
        self.assertIn('50000', msg)

    # TC-10 — Sequence generates CMT/YYYY/NNNN format
    def test_10_commitment_sequence_format(self):
        po = self._make_po([5000])
        po.button_confirm()
        po.button_approve()
        cl = po.commitment_ids[0]
        self.assertTrue(cl.name.startswith('CMT/'),
                        'Expected CMT/YYYY/NNNN format, got: %s' % cl.name)
