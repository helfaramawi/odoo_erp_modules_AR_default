# -*- coding: utf-8 -*-
{
    'name': 'Limited Tender Extension — المناقصة المحدودة (C-PR03)',
    'version': '17.0.1.0.0',
    'summary': 'Limited tender: vendor prequalification registry, private invitations, كشف أسماء الموردين',
    'description': """
        C-PR03 LimitedTenderExtension
        ==============================
        Extends C-PR02 PublicTenderPipeline with the limited tender method
        (المناقصة المحدودة / المحلية).

        Key features:
        - vendor.prequalification model — the vendor registry
        - vendor.prequalification.category — 8 seed supply categories
        - tender.invitation model — per-vendor invitation records
        - Minimum 3-vendor enforcement (regulatory requirement)
        - Bid acceptance filter — non-invited vendors rejected
        - كشف أسماء الموردين QWeb report
        - خطاب دعوة المورد individual invitation letter
        - local_variant Boolean: مناقصة محلية vs مناقصة محدودة

        FRD: PR-03 المناقصة المحلية أو المحدودة للتوريدات وتقديم الخدمات
        Client: الديوان العام لمحافظة بورسعيد
        Delivered by: Paradise Integrated Solutions
    """,
    'author': 'Paradise Integrated Solutions',
    'license': 'LGPL-3',
    'category': 'Purchase',
    'depends': [
        'l10n_eg_tender_public',   # C-PR02 — REQUIRED
        'l10n_eg_tender',          # C-PR01 — transitive
    ],
    'data': [
        'security/ir.model.access.csv',
        'data/prequalification_categories.xml',
        'views/vendor_prequalification_views.xml',
        'views/tender_invitation_views.xml',
        'views/tender_views_inherit.xml',
        'views/menu_inherit.xml',
        'report/report_invited_vendors.xml',
        'report/report_vendor_invitation.xml',
        'report/report_local_announcement.xml',
        'report/report_actions.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
