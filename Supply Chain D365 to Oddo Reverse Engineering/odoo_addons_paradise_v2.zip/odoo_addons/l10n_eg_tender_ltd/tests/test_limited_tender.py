# -*- coding: utf-8 -*-
from odoo.tests.common import TransactionCase
from odoo.exceptions import UserError, ValidationError
from datetime import date, timedelta


class TestLimitedTender(TransactionCase):
    """11 unit tests for C-PR03 LimitedTenderExtension."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.dept = cls.env['hr.department'].create(
            {'name': 'Test Dept C-PR03'})

        # Supply category
        cls.category = cls.env['vendor.prequalification.category'].create({
            'name': 'مستلزمات اختبار', 'code': 'TEST',
        })

        # Vendors
        cls.vendor1 = cls.env['res.partner'].create(
            {'name': 'مورد 1 اختبار', 'supplier_rank': 1})
        cls.vendor2 = cls.env['res.partner'].create(
            {'name': 'مورد 2 اختبار', 'supplier_rank': 1})
        cls.vendor3 = cls.env['res.partner'].create(
            {'name': 'مورد 3 اختبار', 'supplier_rank': 1})
        cls.vendor4 = cls.env['res.partner'].create(
            {'name': 'مورد 4 غير مؤهل', 'supplier_rank': 1})

        # Active prequalifications for vendors 1-3
        future = date.today() + timedelta(days=365)
        past_approved = date.today() - timedelta(days=30)
        for v in [cls.vendor1, cls.vendor2, cls.vendor3]:
            cls.env['vendor.prequalification'].create({
                'partner_id':          v.id,
                'category_ids':        [(4, cls.category.id)],
                'prequalification_date': past_approved,
                'expiry_date':         future,
                'reference_number':    'PQ-%s' % v.id,
                'state':               'active',
            })

    def _make_limited_tender(self):
        return self.env['procurement.tender'].create({
            'tender_type':    'مناقصة_محدودة',
            'description':    'مناقصة محدودة اختبار',
            'amount_estimate': 100000,
            'department_id':  self.dept.id,
            'date_start':     '2025-01-01',
            'category_id':    self.category.id,
            'min_invitees':   3,
        })

    # TC-01 — Cannot publish with fewer than min_invitees
    def test_01_min_invitees_enforced(self):
        t = self._make_limited_tender()
        t.action_invite_vendors([self.vendor1.id, self.vendor2.id])
        self.assertEqual(len(t.invitation_ids), 2)
        t.state = 'committee'
        with self.assertRaises(UserError) as ctx:
            t.action_publish()
        self.assertIn('يجب دعوة ما لا يقل عن', str(ctx.exception))

    # TC-02 — Publish succeeds with 3 invitees
    def test_02_publish_with_3_invitees(self):
        t = self._make_limited_tender()
        t.action_invite_vendors(
            [self.vendor1.id, self.vendor2.id, self.vendor3.id])
        self.assertEqual(len(t.invitation_ids), 3)
        t.state = 'committee'
        t.action_publish()  # Should not raise
        self.assertEqual(t.state, 'published')

    # TC-03 — Cannot invite vendor with expired prequalification
    def test_03_expired_prequalification_rejected(self):
        t = self._make_limited_tender()
        # Expire vendor1's prequalification
        prequal = self.env['vendor.prequalification'].search([
            ('partner_id', '=', self.vendor1.id)], limit=1)
        prequal.expiry_date = date.today() - timedelta(days=1)
        prequal.state = 'expired'
        with self.assertRaises(UserError):
            t.action_invite_vendors([self.vendor1.id])

    # TC-04 — Cannot invite vendor with category mismatch
    def test_04_category_mismatch_rejected(self):
        t = self._make_limited_tender()
        # vendor4 has no prequalification
        with self.assertRaises(UserError) as ctx:
            t.action_invite_vendors([self.vendor4.id])
        self.assertIn('غير مؤهل', str(ctx.exception))

    # TC-05 — Inviting same vendor twice creates only one invitation
    def test_05_duplicate_invitation_skipped(self):
        t = self._make_limited_tender()
        t.action_invite_vendors([self.vendor1.id])
        t.action_invite_vendors([self.vendor1.id])  # Duplicate
        invitations = t.invitation_ids.filtered(
            lambda i: i.partner_id == self.vendor1)
        self.assertEqual(len(invitations), 1)

    # TC-06 — Non-invited vendor bid rejected
    def test_06_non_invited_bid_rejected(self):
        t = self._make_limited_tender()
        t.action_invite_vendors(
            [self.vendor1.id, self.vendor2.id, self.vendor3.id])
        t.state = 'committee'
        t.action_publish()
        t.state = 'evaluation'
        with self.assertRaises(UserError) as ctx:
            t.action_receive_bid(self.vendor4.id, 'ENV/999')
        self.assertIn('غير مدعو', str(ctx.exception))

    # TC-07 — Invited vendor bid accepted and linked to invitation
    def test_07_invited_bid_accepted(self):
        t = self._make_limited_tender()
        t.action_invite_vendors(
            [self.vendor1.id, self.vendor2.id, self.vendor3.id])
        t.state = 'committee'
        t.action_publish()
        t.state = 'evaluation'
        bid = t.action_receive_bid(self.vendor1.id, 'ENV/001')
        self.assertTrue(bid, 'Bid should be created for invited vendor')
        invitation = t.invitation_ids.filtered(
            lambda i: i.partner_id == self.vendor1)
        self.assertEqual(invitation.bid_id, bid)
        self.assertTrue(invitation.bid_submitted)

    # TC-08 — _get_eligible_vendors returns only active non-expired vendors
    def test_08_eligible_vendors_filtered(self):
        t = self._make_limited_tender()
        eligible = t._get_eligible_vendors()
        self.assertIn(self.vendor2, eligible)
        self.assertIn(self.vendor3, eligible)
        # vendor4 has no prequalification — should not appear
        self.assertNotIn(self.vendor4, eligible)

    # TC-09 — is_prequalified computed on res.partner
    def test_09_is_prequalified_computed(self):
        self.assertTrue(self.vendor2.is_prequalified)
        self.assertFalse(self.vendor4.is_prequalified)

    # TC-10 — Prequalification constraint: expiry before approval raises error
    def test_10_expiry_before_approval_constraint(self):
        today = date.today()
        with self.assertRaises(ValidationError):
            self.env['vendor.prequalification'].create({
                'partner_id':           self.vendor4.id,
                'category_ids':         [(4, self.category.id)],
                'prequalification_date': today,
                'expiry_date':          today - timedelta(days=1),
                'reference_number':     'PQ-BAD',
            })

    # TC-11 — _is_valid_for_tender: correct category + active returns True
    def test_11_is_valid_for_tender(self):
        prequal = self.env['vendor.prequalification'].search([
            ('partner_id', '=', self.vendor2.id)], limit=1)
        self.assertTrue(prequal._is_valid_for_tender(self.category))
