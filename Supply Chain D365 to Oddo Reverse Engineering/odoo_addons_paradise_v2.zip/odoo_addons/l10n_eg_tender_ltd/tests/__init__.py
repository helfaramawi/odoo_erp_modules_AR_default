# -*- coding: utf-8 -*-
from . import test_limited_tender
