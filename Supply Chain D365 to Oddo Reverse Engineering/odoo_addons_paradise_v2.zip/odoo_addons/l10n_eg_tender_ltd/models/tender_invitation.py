# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError


class TenderInvitation(models.Model):
    _name = 'tender.invitation'
    _description = 'Limited Tender Vendor Invitation — دعوة مناقصة محدودة'
    _order = 'tender_id, partner_id'

    tender_id = fields.Many2one(
        'procurement.tender',
        string='Tender',
        required=True,
        ondelete='cascade',
        index=True,
    )
    partner_id = fields.Many2one(
        'res.partner',
        string='Invited Vendor',
        required=True,
        index=True,
    )
    prequalification_id = fields.Many2one(
        'vendor.prequalification',
        string='Prequalification Record',
        required=True,
    )
    invitation_date = fields.Date(
        string='Invitation Date',
        required=True,
        default=fields.Date.today,
    )
    invitation_method = fields.Selection([
        ('official_letter',  'Official Letter — خطاب رسمي'),
        ('registered_mail',  'Registered Mail — بريد مسجل'),
        ('hand_delivery',    'Hand Delivery — استلام شخصي'),
    ], default='official_letter', required=True,
       string='Invitation Method')

    acknowledged = fields.Boolean(
        string='Vendor Acknowledged Receipt (استلم الدعوة)',
        default=False,
    )
    bid_id = fields.Many2one(
        'bid.envelope',
        string='Submitted Bid',
        readonly=True,
        copy=False,
        index=True,
    )
    bid_submitted = fields.Boolean(
        compute='_compute_bid_submitted',
        store=True,
        string='Bid Submitted',
    )

    @api.depends('bid_id')
    def _compute_bid_submitted(self):
        for rec in self:
            rec.bid_submitted = bool(rec.bid_id)

    # ── Constraints ────────────────────────────────────────────────────────
    @api.constrains('prequalification_id')
    def _check_bid_qualified(self):
        """Ensure prequalification is active — cannot invite expired vendors."""
        for rec in self:
            if rec.prequalification_id.state != 'active':
                raise ValidationError(_(
                    'لا يمكن دعوة مورد غير مؤهل أو منتهية صلاحية مؤهليته.\n'
                    'المورد: %(vendor)s — حالة المؤهلية: %(state)s',
                    vendor=rec.partner_id.name,
                    state=dict(rec.prequalification_id._fields['state'].selection)
                    .get(rec.prequalification_id.state, ''),
                ))

    # ── Actions ────────────────────────────────────────────────────────────
    def action_generate_invitation_letter(self):
        """Generate individual invitation letter PDF for this vendor."""
        self.ensure_one()
        report = self.env.ref(
            'l10n_eg_tender_ltd.report_vendor_invitation',
            raise_if_not_found=False,
        )
        if not report:
            raise UserError(_('تعذر العثور على نموذج خطاب الدعوة.'))
        return report.report_action(self)
