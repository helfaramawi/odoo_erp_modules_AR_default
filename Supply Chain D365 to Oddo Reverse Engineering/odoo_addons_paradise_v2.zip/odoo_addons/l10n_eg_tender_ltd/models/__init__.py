# -*- coding: utf-8 -*-
from . import vendor_prequalification
from . import vendor_prequalification_category
from . import tender_invitation
from . import procurement_tender
from . import res_partner
