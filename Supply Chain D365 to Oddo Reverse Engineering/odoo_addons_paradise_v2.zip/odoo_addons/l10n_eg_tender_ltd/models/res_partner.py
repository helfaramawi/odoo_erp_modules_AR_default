# -*- coding: utf-8 -*-
from odoo import models, fields, api
from datetime import date


class ResPartnerPrequalification(models.Model):
    _inherit = 'res.partner'

    prequalification_ids = fields.One2many(
        'vendor.prequalification',
        'partner_id',
        string='Prequalification Records',
    )
    is_prequalified = fields.Boolean(
        compute='_compute_is_prequalified',
        store=True,
        string='Prequalified Vendor (مؤهَّل)',
        index=True,
    )
    prequalification_count = fields.Integer(
        compute='_compute_prequalification_count',
        string='Prequalifications',
    )

    @api.depends('prequalification_ids.state', 'prequalification_ids.expiry_date')
    def _compute_is_prequalified(self):
        today = date.today()
        for rec in self:
            rec.is_prequalified = bool(rec.prequalification_ids.filtered(
                lambda p: p.state == 'active' and p.expiry_date >= today
            ))

    def _compute_prequalification_count(self):
        for rec in self:
            rec.prequalification_count = len(rec.prequalification_ids)
