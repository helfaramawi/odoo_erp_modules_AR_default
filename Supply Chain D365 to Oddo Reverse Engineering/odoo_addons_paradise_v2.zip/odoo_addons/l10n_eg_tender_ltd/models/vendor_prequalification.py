# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from datetime import date


class VendorPrequalification(models.Model):
    _name = 'vendor.prequalification'
    _description = 'Vendor Prequalification Registry — سجل الموردين المؤهلين'
    _rec_name = 'reference_number'
    _order = 'expiry_date desc'
    _inherit = ['mail.thread']

    partner_id = fields.Many2one(
        'res.partner',
        string='Vendor / Contractor',
        required=True,
        ondelete='restrict',
        domain=[('supplier_rank', '>', 0)],
        index=True,
    )
    category_ids = fields.Many2many(
        'vendor.prequalification.category',
        'prequalification_category_rel',
        'prequalification_id',
        'category_id',
        string='Qualified Supply Categories',
        required=True,
    )
    prequalification_date = fields.Date(
        string='Approval Date',
        required=True,
    )
    expiry_date = fields.Date(
        string='Expiry Date',
        required=True,
        index=True,
    )
    reference_number = fields.Char(
        string='Prequalification Reference (رقم المؤهلية)',
        required=True,
        copy=False,
        index=True,
    )
    state = fields.Selection([
        ('active',      'Active — مؤهل'),
        ('suspended',   'Suspended — موقوف'),
        ('expired',     'Expired — منتهي الصلاحية'),
        ('blacklisted', 'Blacklisted — محظور'),
    ], default='active', tracking=True, index=True)

    suspension_reason = fields.Text(
        string='Suspension / Blacklist Reason (Arabic)',
    )
    past_performance_rating = fields.Selection([
        ('excellent', 'ممتاز'),
        ('good',      'جيد'),
        ('average',   'متوسط'),
        ('poor',      'ضعيف'),
    ], string='Past Performance Rating')

    document_ids = fields.Many2many(
        'ir.attachment',
        'prequalification_attachment_rel',
        'prequalification_id',
        'attachment_id',
        string='Supporting Documents',
        help='Registration certificate, tax card, commercial register scans.',
    )
    notes = fields.Text(string='Internal Notes')

    # ── Constraints ────────────────────────────────────────────────────────
    @api.constrains('expiry_date', 'prequalification_date')
    def _check_expiry(self):
        for rec in self:
            if rec.expiry_date < rec.prequalification_date:
                raise ValidationError(_(
                    'تاريخ انتهاء الصلاحية يجب أن يكون بعد تاريخ منح المؤهلية.\n'
                    'تاريخ المنح: %(issued)s — تاريخ الانتهاء: %(expiry)s',
                    issued=rec.prequalification_date,
                    expiry=rec.expiry_date,
                ))

    # ── Business logic ─────────────────────────────────────────────────────
    def _is_valid_for_tender(self, category_id):
        """
        Check if this prequalification is currently valid for a tender
        in the given category. Auto-expires if past expiry date.

        :param category_id: vendor.prequalification.category record
        :return: True if valid, False otherwise
        """
        self.ensure_one()

        # Check state
        if self.state != 'active':
            return False

        # Auto-expire if past expiry date
        if self.expiry_date < date.today():
            self.state = 'expired'
            return False

        # Check category match
        return category_id in self.category_ids

    def name_get(self):
        result = []
        for rec in self:
            name = '%s — %s' % (rec.reference_number, rec.partner_id.name)
            result.append((rec.id, name))
        return result
