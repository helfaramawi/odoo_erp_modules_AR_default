# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class ProcurementTenderLimited(models.Model):
    """Extends procurement.tender with limited / local tender pipeline."""
    _inherit = 'procurement.tender'

    # ── New fields for limited/local tender ───────────────────────────────
    invitation_ids = fields.One2many(
        'tender.invitation',
        'tender_id',
        string='Vendor Invitations',
    )
    local_variant = fields.Boolean(
        string='Local Tender Variant (محلية)',
        default=False,
        help='True = مناقصة محلية (local announcement published). '
             'False = مناقصة محدودة (private invitations only).',
    )
    min_invitees = fields.Integer(
        string='Minimum Vendors Required',
        default=3,
        help='Regulatory minimum: at least 3 vendors must be invited.',
    )
    category_id = fields.Many2one(
        'vendor.prequalification.category',
        string='Supply Category (فئة التوريد)',
        help='Filters the prequalification registry for vendor shortlisting.',
    )
    invitation_count = fields.Integer(
        compute='_compute_invitation_count',
        string='Invitations',
    )

    def _compute_invitation_count(self):
        for rec in self:
            rec.invitation_count = len(rec.invitation_ids)

    # ── Invite vendors from prequalification registry ─────────────────────
    def action_invite_vendors(self, partner_ids):
        """
        Invite specific vendors from the prequalification registry.

        :param partner_ids: list of res.partner IDs to invite
        :raises UserError: if vendor not prequalified or category mismatch
        """
        self.ensure_one()
        if self.tender_type not in ('مناقصة_محدودة', 'مناقصة_محلية'):
            raise UserError(_(
                'دعوة الموردين متاحة فقط للمناقصات المحدودة والمحلية.\n'
                'نوع هذه المناقصة: %(type)s',
                type=self.tender_type,
            ))

        for partner_id in partner_ids:
            domain = [
                ('partner_id', '=', partner_id),
                ('state', '=', 'active'),
            ]
            if self.category_id:
                domain.append(
                    ('category_ids', 'in', [self.category_id.id])
                )
            prequal = self.env['vendor.prequalification'].search(
                domain, limit=1,
            )
            if not prequal:
                partner = self.env['res.partner'].browse(partner_id)
                raise UserError(_(
                    'المورد "%(vendor)s" غير مؤهل في فئة "%(category)s" '
                    'أو منتهية صلاحية مؤهليته.\n'
                    'يُرجى مراجعة سجل الموردين المؤهلين.',
                    vendor=partner.name,
                    category=self.category_id.name if self.category_id else 'N/A',
                ))

            # Check not already invited
            existing = self.invitation_ids.filtered(
                lambda i: i.partner_id.id == partner_id
            )
            if existing:
                continue  # Already invited — skip silently

            self.env['tender.invitation'].create({
                'tender_id':           self.id,
                'partner_id':          partner_id,
                'prequalification_id': prequal.id,
                'invitation_date':     fields.Date.today(),
            })

    # ── Override published stage gate ─────────────────────────────────────
    def action_publish(self):
        """For limited/local tenders — enforce minimum 3 invitees."""
        if self.tender_type in ('مناقصة_محدودة', 'مناقصة_محلية'):
            invited = len(self.invitation_ids)
            if invited < self.min_invitees:
                raise UserError(_(
                    'يجب دعوة ما لا يقل عن %(min)d موردين مؤهلين '
                    'قبل طرح المناقصة المحدودة.\n'
                    'المدعوون حالياً: %(current)d — المطلوب: %(min)d',
                    min=self.min_invitees,
                    current=invited,
                ))
            # Generate كشف أسماء الموردين document
            self._safe_generate_document(
                'l10n_eg_tender_ltd.report_invited_vendors'
            )
        return super().action_publish()

    # ── Override bid receipt — only invited vendors accepted ──────────────
    def action_receive_bid(self, partner_id, envelope_number):
        """For limited tenders — reject bids from non-invited vendors."""
        if self.tender_type in ('مناقصة_محدودة', 'مناقصة_محلية'):
            invitation = self.invitation_ids.filtered(
                lambda i: i.partner_id.id == partner_id
            )
            if not invitation:
                partner = self.env['res.partner'].browse(partner_id)
                raise UserError(_(
                    'المورد "%(vendor)s" غير مدعو في هذه المناقصة المحدودة.\n'
                    'لا يمكن قبول عطاءات من موردين لم يُدعوا رسمياً.',
                    vendor=partner.name,
                ))
            bid = super().action_receive_bid(partner_id, envelope_number)
            invitation[0].bid_id = bid
            return bid
        return super().action_receive_bid(partner_id, envelope_number)

    # ── Helper: get eligible vendors for this tender's category ──────────
    def _get_eligible_vendors(self):
        """
        Returns partner records eligible to invite for this limited tender.
        Filters by: active state + correct category + not expired.
        """
        self.ensure_one()
        from datetime import date
        domain = [
            ('state', '=', 'active'),
            ('expiry_date', '>=', fields.Date.today()),
        ]
        if self.category_id:
            domain.append(('category_ids', 'in', [self.category_id.id]))
        prequals = self.env['vendor.prequalification'].search(domain)
        return prequals.mapped('partner_id')

    # ── Smart button ──────────────────────────────────────────────────────
    def action_view_invitations(self):
        return {
            'name': _('Vendor Invitations — الدعوات'),
            'type': 'ir.actions.act_window',
            'res_model': 'tender.invitation',
            'view_mode': 'list,form',
            'domain': [('tender_id', '=', self.id)],
            'context': {'default_tender_id': self.id},
        }
