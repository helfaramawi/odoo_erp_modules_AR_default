# -*- coding: utf-8 -*-
from odoo import models, fields


class VendorPrequalificationCategory(models.Model):
    _name = 'vendor.prequalification.category'
    _description = 'Vendor Prequalification Category — فئة المؤهلية'
    _order = 'code'

    name = fields.Char(
        string='Category Name (Arabic)',
        required=True,
        translate=False,
    )
    code = fields.Char(
        string='Category Code',
        size=10,
        required=True,
        index=True,
    )
    description = fields.Text(
        string='Description',
    )
    active = fields.Boolean(
        default=True,
        help='Archive unused categories without deleting.',
    )

    _sql_constraints = [
        ('code_unique', 'unique(code)',
         'Category code must be unique.'),
    ]
