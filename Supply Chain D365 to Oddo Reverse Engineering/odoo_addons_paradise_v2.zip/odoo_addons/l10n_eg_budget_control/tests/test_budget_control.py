# -*- coding: utf-8 -*-
from odoo.tests.common import TransactionCase
from odoo.exceptions import UserError
from datetime import timedelta


class TestBudgetControl(TransactionCase):
    """6 unit tests for C6 BudgetControl."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.company = cls.env.company
        cls.vendor  = cls.env['res.partner'].create(
            {'name': 'مورد C6 Test', 'supplier_rank': 1})
        cls.product = cls.env['product.product'].create(
            {'name': 'صنف C6 Test', 'type': 'consu'})

        # Commitment config (reuse C1 setup pattern)
        journal = cls.env['account.journal'].create({
            'name': 'دفتر الالتزامات C6 Test',
            'code': 'C6T',
            'type': 'general',
            'company_id': cls.company.id,
        })
        exp_acct = cls.env['account.account'].create({
            'name': 'CMT EXP C6', 'code': 'CMTE6',
            'account_type': 'expense', 'company_id': cls.company.id,
        })
        rsv_acct = cls.env['account.account'].create({
            'name': 'CMT RSV C6', 'code': 'CMTR6',
            'account_type': 'liability_current', 'company_id': cls.company.id,
        })
        cls.cfg = cls.env['commitment.config'].create({
            'company_id': cls.company.id,
            'commitment_journal_id': journal.id,
            'commitment_expense_account_id': exp_acct.id,
            'commitment_reserve_account_id': rsv_acct.id,
            'budget_hard_block': True,
        })

        # Analytic account + plan
        plan = cls.env['account.analytic.plan'].search([], limit=1)
        if not plan:
            plan = cls.env['account.analytic.plan'].create({'name': 'C6 Test Plan'})
        cls.analytic = cls.env['account.analytic.account'].create({
            'name': 'C6 Cost Center', 'plan_id': plan.id})

        # Budget with 10K available
        cls.budget_year = cls.env['crossovered.budget'].create({
            'name': 'C6 Test Budget 2025',
            'date_from': '2025-01-01', 'date_to': '2025-12-31',
        })
        cls.budget_line = cls.env['crossovered.budget.lines'].create({
            'crossovered_budget_id': cls.budget_year.id,
            'analytic_account_id': cls.analytic.id,
            'planned_amount': 10000,
            'date_from': '2025-01-01', 'date_to': '2025-12-31',
        })

    def _make_po(self, price_unit, with_analytic=True):
        po = self.env['purchase.order'].create({
            'partner_id': self.vendor.id,
            'company_id': self.company.id,
        })
        line_vals = {
            'order_id': po.id, 'product_id': self.product.id,
            'product_qty': 1, 'price_unit': price_unit,
            'name': 'C6 Test', 'date_planned': '2025-06-01',
        }
        if with_analytic:
            line_vals['account_analytic_id'] = self.analytic.id
        self.env['purchase.order.line'].create(line_vals)
        return po

    # TC-01 — PO within budget confirms without error
    def test_01_within_budget_ok(self):
        po = self._make_po(5000)
        try:
            po.action_confirm()  # Should not raise
        except UserError as e:
            self.fail('Should not raise UserError for PO within budget: %s' % e)

    # TC-02 — PO exceeding budget raises Arabic UserError
    def test_02_exceeding_budget_blocked(self):
        po = self._make_po(50000)  # More than 10K budget
        with self.assertRaises(UserError) as ctx:
            po.action_confirm()
        self.assertIn('تجاوز الميزانية', str(ctx.exception))
        self.assertIn('المتاح', str(ctx.exception))

    # TC-03 — No analytic = no budget check (passes through)
    def test_03_no_analytic_skips_check(self):
        po = self._make_po(99999, with_analytic=False)
        try:
            po.action_confirm()  # No analytic — should pass
        except UserError as e:
            self.fail('PO without analytic should skip budget check: %s' % e)

    # TC-04 — Override grants 24h window
    def test_04_override_grants_window(self):
        po = self._make_po(50000)
        po.action_approve_budget_override()
        self.assertTrue(po._has_active_budget_override())
        self.assertEqual(po.budget_override_uid, self.env.user)

    # TC-05 — Expired override no longer active
    def test_05_expired_override_inactive(self):
        po = self._make_po(50000)
        po.action_approve_budget_override()
        # Manually set override date to 25 hours ago
        from odoo import fields
        po.budget_override_date = fields.Datetime.now() - timedelta(hours=25)
        self.assertFalse(po._has_active_budget_override())

    # TC-06 — Active override allows PO to confirm despite budget exceeded
    def test_06_active_override_allows_confirm(self):
        po = self._make_po(50000)
        po.action_approve_budget_override()
        self.assertTrue(po._has_active_budget_override())
        try:
            po.action_confirm()  # Override active — should not raise
        except UserError as e:
            self.fail('Active override should bypass budget check: %s' % e)
