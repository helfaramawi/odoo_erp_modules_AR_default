# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import timedelta


class PurchaseOrderBudgetControl(models.Model):
    _inherit = 'purchase.order'

    # ── Override tracking fields ──────────────────────────────────────────
    budget_override_uid = fields.Many2one(
        'res.users',
        string='Budget Override Granted By',
        readonly=True,
        copy=False,
        help='Finance director who granted the 24-hour budget override.',
    )
    budget_override_date = fields.Datetime(
        string='Budget Override Granted At',
        readonly=True,
        copy=False,
    )
    budget_override_reason = fields.Text(
        string='Override Reason (Arabic)',
        copy=False,
    )

    # ── Override active check ─────────────────────────────────────────────
    def _has_active_budget_override(self):
        """
        Returns True if a finance director has granted an override
        within the last 24 hours.
        """
        self.ensure_one()
        if not self.budget_override_date:
            return False
        expiry = self.budget_override_date + timedelta(hours=24)
        return fields.Datetime.now() < expiry

    # ── Override action_confirm ───────────────────────────────────────────
    def action_confirm(self):
        for order in self:
            # Skip budget check if override is active
            if order._has_active_budget_override():
                order.message_post(body=_(
                    'تم تجاوز التحقق من الميزانية — إذن مؤقت ممنوح بواسطة %(user)s',
                    user=order.budget_override_uid.name,
                ))
                continue
            order._check_all_lines_budget()
        return super().action_confirm()

    # ── Core budget check ─────────────────────────────────────────────────
    def _check_all_lines_budget(self):
        """
        Check budget availability for every PO line that has an
        analytic account. Raises UserError (Arabic) if insufficient.
        """
        # Get commitment config — if not set, respect budget_hard_block default
        try:
            cfg = self.env['commitment.config'].get_config(self.company_id.id)
            if not cfg.budget_hard_block:
                return  # Soft mode — skip hard block
        except UserError:
            return  # Config not set — skip silently

        today = fields.Date.today()

        for line in self.order_line:
            if not line.account_analytic_id:
                continue  # No analytic = no budget line to check

            budget_line = self.env['crossovered.budget.lines'].search([
                ('analytic_account_id', '=', line.account_analytic_id.id),
                ('date_from', '<=', today),
                ('date_to', '>=', today),
            ], limit=1)

            if not budget_line:
                if cfg.budget_hard_block:
                    raise UserError(_(
                        'لا يوجد بند ميزانية لمركز التكلفة:\n'
                        '%(center)s\n\n'
                        'يُرجى التواصل مع مدير الشؤون المالية '
                        'لإنشاء بند ميزانية أو الحصول على إذن تجاوز.',
                        center=line.account_analytic_id.name,
                    ))
                continue  # Soft mode — skip

            ok, msg = budget_line.check_budget_availability(line.price_subtotal)
            if not ok:
                raise UserError(_(
                    'تجاوز الميزانية — لا يمكن اعتماد أمر الشراء\n'
                    '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n'
                    'البند: %(line)s\n'
                    'مركز التكلفة: %(center)s\n\n'
                    '%(budget_msg)s\n\n'
                    'لطلب إذن تجاوز: استخدم زر "طلب تجاوز الميزانية" '
                    'وسيُرسل طلبك إلى مدير الشؤون المالية.',
                    line=line.name or line.product_id.name or '',
                    center=line.account_analytic_id.name,
                    budget_msg=msg,
                ))

    # ── Request override (sends activity to finance director) ─────────────
    def action_request_budget_override(self):
        """
        PO creator requests a budget override.
        Sends mail.activity to the finance director group.
        """
        self.ensure_one()
        finance_director_group = self.env.ref(
            'l10n_eg_budget_control.group_finance_director',
            raise_if_not_found=False,
        )
        target_user = None
        if finance_director_group:
            users_in_group = finance_director_group.users
            target_user = users_in_group[0] if users_in_group else None

        if not target_user:
            target_user = self.env.ref('base.user_admin')

        self.activity_schedule(
            activity_type_id=self.env.ref(
                'mail.mail_activity_data_todo').id,
            summary=_('طلب تجاوز الميزانية — %(po)s', po=self.name),
            note=_(
                'يطلب %(user)s تجاوز قيد الميزانية لأمر الشراء '
                '%(po)s بقيمة %(amount)s ج.م.\n\n'
                'المبرر: %(reason)s',
                user=self.env.user.name,
                po=self.name,
                amount='%.2f' % self.amount_total,
                reason=self.budget_override_reason or 'لم يُحدد',
            ),
            user_id=target_user.id,
        )
        self.message_post(body=_(
            'تم إرسال طلب تجاوز الميزانية إلى مدير الشؤون المالية.',
        ))

    # ── Finance director grants override ──────────────────────────────────
    def action_approve_budget_override(self):
        """
        Finance director grants a 24-hour override window.
        Requires group: l10n_eg_budget_control.group_finance_director
        """
        self.ensure_one()
        self.budget_override_uid  = self.env.uid
        self.budget_override_date = fields.Datetime.now()
        self.message_post(body=_(
            'تم منح إذن تجاوز الميزانية بواسطة %(user)s — '
            'صالح لمدة 24 ساعة حتى %(expiry)s',
            user=self.env.user.name,
            expiry=str(self.budget_override_date + timedelta(hours=24)),
        ))

    # ── Override expiry helper ────────────────────────────────────────────
    def _budget_override_expiry(self):
        """Returns override expiry datetime string or None."""
        if not self.budget_override_date:
            return None
        return str(self.budget_override_date + timedelta(hours=24))
