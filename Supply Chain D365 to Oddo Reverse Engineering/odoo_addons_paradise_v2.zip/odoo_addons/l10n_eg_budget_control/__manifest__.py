# -*- coding: utf-8 -*-
{
    'name': 'Hard Budget Control — التحكم الصارم في الميزانية (C6)',
    'version': '17.0.1.0.0',
    'summary': 'Hard block PO confirmation if budget insufficient — Arabic error dialog + 24h override',
    'description': """
        C6 BudgetControl
        =================
        Intercepts purchase.order action_confirm() and checks budget
        availability via C1 CommitmentLedger's check_budget_availability().

        If insufficient budget:
          - Raises UserError with full Arabic breakdown (available / required / shortfall)
          - Finance director can grant a 24-hour override window
          - Override is tracked with user + timestamp for audit trail

        FRD: Finance Module C6
        Client: الديوان العام لمحافظة بورسعيد
        Delivered by: Paradise Integrated Solutions
    """,
    'author': 'Paradise Integrated Solutions',
    'license': 'LGPL-3',
    'category': 'Accounting',
    'depends': [
        'l10n_eg_commitment',   # C1 — check_budget_availability()
        'l10n_eg_approval',     # C5 — approval chain
        'account_budget',
        'purchase',
        'mail',
    ],
    'data': [
        'security/security_groups.xml',
        'security/ir.model.access.csv',
        'views/purchase_order_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
