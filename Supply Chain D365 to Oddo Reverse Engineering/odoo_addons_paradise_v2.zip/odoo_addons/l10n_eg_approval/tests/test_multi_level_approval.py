# -*- coding: utf-8 -*-
from odoo.tests.common import TransactionCase
from odoo.exceptions import UserError


class TestMultiLevelApproval(TransactionCase):
    """7 unit tests for C5 MultiLevelApproval."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.vendor = cls.env['res.partner'].create(
            {'name': 'مورد الاختبار C5', 'supplier_rank': 1})
        cls.product = cls.env['product.product'].create({
            'name': 'صنف اختبار C5', 'type': 'consu'})

    def _make_po(self, price_unit):
        po = self.env['purchase.order'].create({'partner_id': self.vendor.id})
        self.env['purchase.order.line'].create({
            'order_id': po.id, 'product_id': self.product.id,
            'product_qty': 1, 'price_unit': price_unit,
            'name': 'Test line', 'date_planned': '2025-06-01',
        })
        return po

    # TC-01 — approval_level computed correctly at boundaries
    def test_01_approval_level_boundaries(self):
        t1 = self._make_po(30000)
        self.assertEqual(t1.approval_level, 'dept_head')
        t2 = self._make_po(200000)
        self.assertEqual(t2.approval_level, 'deputy_governor')
        t3 = self._make_po(600000)
        self.assertEqual(t3.approval_level, 'governor')

    # TC-02 — Boundary values: exactly at threshold
    def test_02_threshold_boundaries(self):
        t_low  = self._make_po(49999)
        t_mid  = self._make_po(50000)
        t_high = self._make_po(500000)
        t_over = self._make_po(500001)
        self.assertEqual(t_low.approval_level,  'dept_head')
        self.assertEqual(t_mid.approval_level,  'deputy_governor')
        self.assertEqual(t_high.approval_level, 'deputy_governor')
        self.assertEqual(t_over.approval_level, 'governor')

    # TC-03 — Small PO auto-approved after confirm
    def test_03_small_po_auto_approved(self):
        po = self._make_po(30000)
        po.action_confirm()
        self.assertEqual(po.approval_state, 'dept_confirmed')
        # Should also be in purchase state (auto-approved)
        self.assertIn(po.state, ('purchase', 'to approve'))

    # TC-04 — Deputy review required for mid-range PO
    def test_04_deputy_required_for_midrange(self):
        po = self._make_po(200000)
        po.action_confirm()
        self.assertEqual(po.approval_state, 'dept_confirmed')
        # Must still be 'to approve' — waiting for deputy
        self.assertEqual(po.state, 'to approve')

    # TC-05 — Deputy review gate: dept confirm required first
    def test_05_deputy_gate_enforced(self):
        po = self._make_po(200000)
        po.action_confirm()
        # Mess with state to simulate out-of-order call
        po.approval_state = 'draft'
        with self.assertRaises(UserError):
            po.action_deputy_review()

    # TC-06 — Deputy review on wrong amount raises UserError
    def test_06_deputy_wrong_amount(self):
        po = self._make_po(30000)  # dept_head level
        po.action_confirm()
        with self.assertRaises(UserError):
            po.action_deputy_review()

    # TC-07 — Governor gate: deputy review required first
    def test_07_governor_gate_enforced(self):
        po = self._make_po(600000)
        po.action_confirm()
        self.assertEqual(po.approval_state, 'dept_confirmed')
        # Try governor without deputy review
        with self.assertRaises(UserError):
            po.action_governor_approve()
