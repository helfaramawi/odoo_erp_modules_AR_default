# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError

# ── Authority thresholds (EGP) — confirmed by Dir. Al-Masri Phase 4 ──────────
THRESHOLD_DEPUTY   = 50_000.0    # Below: dept head auto-approves
THRESHOLD_GOVERNOR = 500_000.0   # Above: requires Governor


class PurchaseOrderMultiApproval(models.Model):
    _inherit = 'purchase.order'

    # ── Approval level (computed from amount) ─────────────────────────────
    approval_level = fields.Selection([
        ('dept_head',       'مدير الإدارة المختصة'),
        ('deputy_governor', 'نائب المحافظ'),
        ('governor',        'المحافظ'),
    ], compute='_compute_approval_level', store=True,
       string='Required Approval Authority',
       help='Auto-computed from amount_total using governorate thresholds.')

    # ── Approval workflow state ───────────────────────────────────────────
    approval_state = fields.Selection([
        ('draft',             'Draft — مسودة'),
        ('dept_confirmed',    'Dept Head Confirmed — اعتمد مدير الإدارة'),
        ('deputy_reviewed',   'Deputy Governor Reviewed — راجع نائب المحافظ'),
        ('governor_approved', 'Governor Approved — اعتمد المحافظ'),
    ], default='draft', string='Approval Status',
       tracking=True, copy=False)

    # ── Approval audit trail ──────────────────────────────────────────────
    dept_head_id = fields.Many2one(
        'res.users', string='Dept Head (مدير الإدارة)',
        readonly=True, copy=False,
    )
    dept_confirm_date = fields.Datetime(
        string='Dept Confirm Date', readonly=True, copy=False,
    )
    deputy_id = fields.Many2one(
        'res.users', string='Deputy Governor (نائب المحافظ)',
        readonly=True, copy=False,
    )
    deputy_review_date = fields.Datetime(
        string='Deputy Review Date', readonly=True, copy=False,
    )
    governor_id = fields.Many2one(
        'res.users', string='Governor (المحافظ)',
        readonly=True, copy=False,
    )
    governor_approve_date = fields.Datetime(
        string='Governor Approval Date', readonly=True, copy=False,
    )

    # ── Compute authority level ───────────────────────────────────────────
    @api.depends('amount_total')
    def _compute_approval_level(self):
        for order in self:
            if order.amount_total < THRESHOLD_DEPUTY:
                order.approval_level = 'dept_head'
            elif order.amount_total < THRESHOLD_GOVERNOR:
                order.approval_level = 'deputy_governor'
            else:
                order.approval_level = 'governor'

    # ── Helper: authority title string ────────────────────────────────────
    def _get_authority_title(self):
        """Returns Arabic title for the required signing authority."""
        titles = {
            'dept_head':       'مدير الإدارة المختصة',
            'deputy_governor': 'نائب المحافظ',
            'governor':        'المحافظ',
        }
        return titles.get(self.approval_level, 'المدير المختص')

    # ── Step 1: Dept Head confirms ────────────────────────────────────────
    def action_confirm(self):
        """
        Override confirm — records dept head and auto-approves for
        small POs (< THRESHOLD_DEPUTY).
        """
        res = super().action_confirm()
        for order in self.filtered(lambda o: o.state in ('purchase', 'to approve')):
            order.dept_head_id    = self.env.uid
            order.dept_confirm_date = fields.Datetime.now()
            order.approval_state  = 'dept_confirmed'
            # Small PO — dept head is the final authority
            if order.approval_level == 'dept_head':
                order._finalize_approval()
        return res

    # ── Step 2: Deputy Governor reviews ───────────────────────────────────
    def action_deputy_review(self):
        """Deputy governor reviews — final for 50K–500K POs."""
        self.ensure_one()
        if self.approval_level not in ('deputy_governor', 'governor'):
            raise UserError(_(
                'هذا الأمر (%(amount)s ج.م) لا يستلزم مراجعة نائب المحافظ.\n'
                'الحد الأدنى لمراجعة نائب المحافظ: %(threshold)s ج.م',
                amount='%.2f' % self.amount_total,
                threshold='%.2f' % THRESHOLD_DEPUTY,
            ))
        if self.approval_state != 'dept_confirmed':
            raise UserError(_(
                'يجب اعتماد مدير الإدارة المختصة أولاً قبل مراجعة نائب المحافظ.\n'
                'الحالة الحالية: %(state)s',
                state=dict(self._fields['approval_state'].selection).get(
                    self.approval_state, self.approval_state),
            ))
        self.deputy_id          = self.env.uid
        self.deputy_review_date = fields.Datetime.now()
        self.approval_state     = 'deputy_reviewed'
        self.message_post(body=_(
            'تمت مراجعة نائب المحافظ بتاريخ %(date)s',
            date=fields.Datetime.now(),
        ))
        # Deputy is final for 50K–500K
        if self.approval_level == 'deputy_governor':
            self._finalize_approval()

    # ── Step 3: Governor approves ─────────────────────────────────────────
    def action_governor_approve(self):
        """Governor's final approval — required for > 500K POs."""
        self.ensure_one()
        if self.approval_level != 'governor':
            raise UserError(_(
                'هذا الأمر (%(amount)s ج.م) لا يستلزم اعتماد المحافظ مباشرة.\n'
                'الحد الأدنى لاعتماد المحافظ: %(threshold)s ج.م',
                amount='%.2f' % self.amount_total,
                threshold='%.2f' % THRESHOLD_GOVERNOR,
            ))
        if self.approval_state != 'deputy_reviewed':
            raise UserError(_(
                'يجب مراجعة نائب المحافظ أولاً قبل اعتماد المحافظ.\n'
                'الحالة الحالية: %(state)s',
                state=dict(self._fields['approval_state'].selection).get(
                    self.approval_state, self.approval_state),
            ))
        self.governor_id           = self.env.uid
        self.governor_approve_date = fields.Datetime.now()
        self.approval_state        = 'governor_approved'
        self.message_post(body=_(
            'تم اعتماد المحافظ للأمر بقيمة %(amount)s ج.م بتاريخ %(date)s',
            amount='%.2f' % self.amount_total,
            date=fields.Datetime.now(),
        ))
        self._finalize_approval()

    # ── Internal: finalize ────────────────────────────────────────────────
    def _finalize_approval(self):
        """
        Called when the required authority level has approved.
        Moves PO to 'purchase' state if still in 'to approve'.
        """
        self.ensure_one()
        if self.state == 'to approve':
            self.button_approve()

    # ── Override button_approve for C6 integration ───────────────────────
    def button_approve(self, force=False):
        """
        Ensure approval_state is consistent when button_approve is called
        directly (e.g., by C6 BudgetControl override check after override).
        """
        res = super().button_approve(force=force)
        for order in self:
            # If approval_state was never set (e.g., direct call), set it
            if order.approval_state == 'draft' and order.state == 'purchase':
                order.approval_state = 'dept_confirmed'
        return res
