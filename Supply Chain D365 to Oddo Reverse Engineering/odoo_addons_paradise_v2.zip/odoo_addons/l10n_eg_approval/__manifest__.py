# -*- coding: utf-8 -*-
{
    'name': 'Multi-Level PO Approval — الاعتماد متعدد المستويات (C5)',
    'version': '17.0.1.0.0',
    'summary': '3-tier PO approval: مدير الإدارة (<50K) | نائب المحافظ (50K–500K) | المحافظ (>500K)',
    'description': """
        C5 MultiLevelApproval
        ======================
        Implements the 3-tier purchase order approval authority matrix for
        الديوان العام لمحافظة بورسعيد.

        INSTALL BEFORE: C-PR01 (l10n_eg_tender) and C1 (l10n_eg_commitment)
        Both modules hook into the approval flow established here.

        Thresholds (confirmed by Dir. Al-Masri, Phase 4):
          - < 50,000 EGP  → مدير الإدارة المختصة (auto-approve after confirm)
          - 50K – 500K    → نائب المحافظ (two-step: confirm + deputy review)
          - > 500,000 EGP → المحافظ (three-step: confirm + deputy + governor)

        FRD: Finance Module C5
        Client: الديوان العام لمحافظة بورسعيد
        Delivered by: Paradise Integrated Solutions
    """,
    'author': 'Paradise Integrated Solutions',
    'license': 'LGPL-3',
    'category': 'Purchase',
    'depends': [
        'purchase',
        'mail',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/purchase_order_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
