# -*- coding: utf-8 -*-
from odoo.tests.common import TransactionCase
from odoo.exceptions import UserError, ValidationError


class TestTenderLifecycle(TransactionCase):
    """
    Unit tests for C-PR01 GovernmentTenderLifecycle.
    8 test cases covering all critical paths.
    Run with: python -m pytest addons/l10n_eg_tender/tests/
    Or:        odoo-bin --test-enable -d <db> -i l10n_eg_tender
    """

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        # Department
        cls.dept = cls.env['hr.department'].create({
            'name': 'إدارة التعاقدات — Test',
        })
        # Vendor
        cls.vendor = cls.env['res.partner'].create({
            'name': 'شركة الاختبار للتوريدات',
            'supplier_rank': 1,
        })
        # Sovereign vendor
        cls.sovereign_vendor = cls.env['res.partner'].create({
            'name': 'هيئة حكومية اختبار',
            'supplier_rank': 1,
            'jihat_siyadiya': True,
            'jihat_code': 'GOV-001',
        })

    def _make_tender(self, amount=30000, tender_type='مناقصة_عامة'):
        return self.env['procurement.tender'].create({
            'tender_type':    tender_type,
            'description':    'مناقصة اختبار — Test Tender',
            'amount_estimate': amount,
            'department_id':  self.dept.id,
            'date_start':     '2025-01-01',
        })

    # TC-01 ── Authority level computed correctly
    def test_01_authority_level_computation(self):
        t1 = self._make_tender(30000)
        self.assertEqual(t1.authority_level, 'dept_head',
                         'Amount 30K should = dept_head')

        t2 = self._make_tender(200000)
        self.assertEqual(t2.authority_level, 'deputy_governor',
                         'Amount 200K should = deputy_governor')

        t3 = self._make_tender(600000)
        self.assertEqual(t3.authority_level, 'governor',
                         'Amount 600K should = governor')

    # TC-02 ── Stage gate: cannot move to committee without committee record
    def test_02_committee_gate(self):
        tender = self._make_tender()
        with self.assertRaises(UserError):
            tender.action_to_committee()

    # TC-03 ── Stage gate: cannot publish without كراسة الشروط document
    def test_03_publish_gate_no_document(self):
        tender = self._make_tender()
        # Add a committee to pass TC-02
        self.env['procurement.committee'].create({
            'name':           'لجنة التشكيل',
            'tender_id':      tender.id,
            'committee_type': 'تشكيل',
            'chairman_id':    self.env.user.id,
            'member_ids':     [(4, self.env.user.id)],
        })
        tender.action_to_committee()
        self.assertEqual(tender.state, 'committee')
        # Should fail — no كراسة_شروط document
        with self.assertRaises(UserError):
            tender.action_publish()

    # TC-04 ── Cannot award without all committees decided
    def test_04_award_gate_undecided_committee(self):
        tender = self._make_tender()
        # Setup committee
        committee = self.env['procurement.committee'].create({
            'name':           'لجنة البت الفني',
            'tender_id':      tender.id,
            'committee_type': 'بت_فني',
            'chairman_id':    self.env.user.id,
            'member_ids':     [(4, self.env.user.id)],
            'state':          'convened',  # Not decided yet
        })
        tender.state = 'evaluation'
        with self.assertRaises(UserError):
            tender.action_award()

    # TC-05 ── Sovereign entity bypass — committee state not required
    def test_05_sovereign_bypass(self):
        tender = self._make_tender(100000)
        tender.jihat_siyadiya = True
        tender.jihat_code = 'GOV-TEST-001'
        tender.partner_id = self.sovereign_vendor
        # Add undecided committee — should be bypassed for sovereign
        self.env['procurement.committee'].create({
            'name':           'لجنة البت الفني',
            'tender_id':      tender.id,
            'committee_type': 'بت_فني',
            'chairman_id':    self.env.user.id,
            'member_ids':     [(4, self.env.user.id)],
            'state':          'convened',  # Not decided
        })
        tender.state = 'evaluation'
        # Sovereign bypass — should NOT raise UserError
        tender.action_award()
        self.assertEqual(tender.state, 'award')
        self.assertEqual(tender.date_award, __import__('odoo').fields.Date.today())

    # TC-06 ── Sovereign validation: jihat_code required
    def test_06_sovereign_jihat_code_required(self):
        with self.assertRaises(ValidationError):
            self.env['procurement.tender'].create({
                'tender_type':     'أمر_مباشر',
                'description':     'Test',
                'amount_estimate':  50000,
                'department_id':   self.dept.id,
                'date_start':      '2025-01-01',
                'jihat_siyadiya':  True,
                'jihat_code':      '',  # Missing — should fail
            })

    # TC-07 ── PO auto-created on contract stage transition
    def test_07_po_auto_creation(self):
        tender = self._make_tender(30000)
        tender.partner_id = self.vendor
        tender.state = 'award'
        tender.action_contract()
        self.assertEqual(tender.state, 'contract')
        self.assertTrue(tender.purchase_order_id,
                        'PO should be auto-created on contract stage')
        self.assertEqual(tender.purchase_order_id.partner_id, self.vendor)
        self.assertEqual(tender.purchase_order_id.contract_ref, tender.name)

    # TC-08 ── Sequence generates PR/YYYY/NNNN format
    def test_08_sequence_format(self):
        tender = self._make_tender()
        self.assertTrue(
            tender.name.startswith('PR/'),
            'Tender name should start with PR/ — got: %s' % tender.name
        )
        parts = tender.name.split('/')
        self.assertEqual(len(parts), 3,
                         'Expected PR/YYYY/NNNN format')
        self.assertTrue(parts[2].isdigit(),
                        'Sequence number should be numeric')
