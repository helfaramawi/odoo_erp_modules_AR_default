# -*- coding: utf-8 -*-
{
    'name': 'Egyptian Government Tender Lifecycle (C-PR01)',
    'version': '17.0.1.0.0',
    'summary': 'Foundation module for government procurement — الديوان العام لمحافظة بورسعيد',
    'description': """
        C-PR01 GovernmentTenderLifecycle
        =================================
        Foundation module for all government procurement customs.
        Implements procurement.tender model with 6-stage lifecycle,
        3-tier approval authority matrix (50K/500K EGP thresholds),
        sovereign entity (جهات سيادية) classification and bypass logic,
        and Arabic QWeb document generation engine.

        All C-PR02 through C-PR06 modules extend this foundation.

        FRD: PR-01 العمليات التعاقدية الأولية
        Client: الديوان العام لمحافظة بورسعيد
        Delivered by: Paradise Integrated Solutions
    """,
    'author': 'Paradise Integrated Solutions',
    'website': 'https://www.paradise-solutions.com',
    'license': 'LGPL-3',
    'category': 'Purchase',
    'depends': [
        'purchase',
        'account',
        'hr',
        'mail',
        'base_setup',
    ],
    'data': [
        'security/security_groups.xml',
        'security/ir.model.access.csv',
        'data/sequences.xml',
        'views/procurement_tender_views.xml',
        'views/procurement_committee_views.xml',
        'views/res_partner_views.xml',
        'views/purchase_order_views.xml',
        'views/menu_items.xml',
        'report/base_tender_doc.xml',
        'report/report_actions.xml',
    ],
    'demo': [],
    'installable': True,
    'application': False,
    'auto_install': False,
}
