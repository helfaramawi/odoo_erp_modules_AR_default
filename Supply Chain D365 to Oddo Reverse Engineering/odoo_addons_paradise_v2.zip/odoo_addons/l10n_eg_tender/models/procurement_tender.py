# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError

# Approval authority thresholds (EGP) — confirmed by Dir. Al-Masri Phase 4
THRESHOLD_DEPUTY   = 50_000.0
THRESHOLD_GOVERNOR = 500_000.0


class ProcurementTender(models.Model):
    _name = 'procurement.tender'
    _description = 'Government Tender Lifecycle — مناقصة حكومية'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name desc'
    _rec_name = 'name'

    # ── Identity ──────────────────────────────────────────────────────────
    name = fields.Char(
        string='Tender Reference',
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: _('New'),
        tracking=True,
        index=True,
    )
    description = fields.Text(
        string='Tender Description / Subject',
        required=True,
    )

    # ── Type & State ──────────────────────────────────────────────────────
    tender_type = fields.Selection([
        ('مناقصة_عامة',   'مناقصة عامة — Public Tender'),
        ('مناقصة_محدودة', 'مناقصة محدودة — Limited Tender'),
        ('أمر_مباشر',     'أمر مباشر — Direct Order'),
        ('مزايدة',        'مزايدة — Auction'),
        ('ممارسة',        'ممارسة — Negotiation'),
        ('مقاولات',       'مقاولات — Contracting Works'),
    ], string='Tender Type', required=True, tracking=True, index=True)

    state = fields.Selection([
        ('draft',      'مسودة — Draft'),
        ('committee',  'تشكيل اللجنة — Committee'),
        ('published',  'منشور — Published'),
        ('evaluation', 'قيد التقييم — Evaluation'),
        ('award',      'ترسية — Award'),
        ('contract',   'تعاقد — Contract'),
    ], default='draft', tracking=True, index=True, copy=False)

    # ── Financial ────────────────────────────────────────────────────────
    currency_id = fields.Many2one(
        'res.currency',
        default=lambda self: self.env.ref('base.EGP', raise_if_not_found=False),
        required=True,
    )
    amount_estimate = fields.Monetary(
        string='Estimated Value (EGP)',
        currency_field='currency_id',
        required=True,
        tracking=True,
    )
    authority_level = fields.Selection([
        ('dept_head',       'مدير الإدارة المختصة'),
        ('deputy_governor', 'نائب المحافظ'),
        ('governor',        'المحافظ'),
    ], compute='_compute_authority', store=True,
       string='Approval Authority Level')

    # ── Sovereign Entity (PR-07) ──────────────────────────────────────────
    jihat_siyadiya = fields.Boolean(
        string='Sovereign Entity (جهة سيادية)',
        default=False,
        tracking=True,
        help='True when contracting with another government entity. '
             'Enables PR-07 bypass workflow.',
    )
    jihat_code = fields.Char(
        string='رمز الجهة السيادية',
        size=20,
        help='Mandatory for PR-07 tenders. Printed on all output documents.',
    )

    # ── Parties ───────────────────────────────────────────────────────────
    user_id = fields.Many2one(
        'res.users',
        string='Responsible Officer (مسؤول التعاقد)',
        default=lambda self: self.env.uid,
        required=True,
        tracking=True,
    )
    department_id = fields.Many2one(
        'hr.department',
        string='Requesting Department',
        required=True,
    )
    partner_id = fields.Many2one(
        'res.partner',
        string='Winning Vendor / Contractor',
        tracking=True,
        index=True,
        help='Set at award stage.',
    )

    # ── Dates ─────────────────────────────────────────────────────────────
    date_start = fields.Date(
        string='Initiation Date',
        required=True,
        default=fields.Date.today,
    )
    date_award = fields.Date(
        string='Award Date',
        readonly=True,
        copy=False,
    )
    date_contract = fields.Date(
        string='Contract Date',
        readonly=True,
        copy=False,
    )

    # ── Relations ─────────────────────────────────────────────────────────
    committee_ids = fields.One2many(
        'procurement.committee',
        'tender_id',
        string='Committees',
    )
    document_ids = fields.One2many(
        'procurement.document',
        'tender_id',
        string='Generated Documents',
    )
    purchase_order_id = fields.Many2one(
        'purchase.order',
        string='Linked Purchase Order',
        readonly=True,
        copy=False,
        index=True,
    )

    # ── Works (C-PR05 extension point) ───────────────────────────────────
    works_type = fields.Selection([
        ('supplies',    'توريدات / خدمات'),
        ('contracting', 'أعمال مقاولات'),
    ], default='supplies', string='Contract Type')

    notes = fields.Text(string='Internal Notes')

    # ── Computed ──────────────────────────────────────────────────────────
    committee_count = fields.Integer(
        compute='_compute_committee_count',
        string='Committees',
    )
    document_count = fields.Integer(
        compute='_compute_document_count',
        string='Documents',
    )

    # ── Compute Methods ───────────────────────────────────────────────────
    @api.depends('amount_estimate')
    def _compute_authority(self):
        for rec in self:
            if rec.amount_estimate < THRESHOLD_DEPUTY:
                rec.authority_level = 'dept_head'
            elif rec.amount_estimate < THRESHOLD_GOVERNOR:
                rec.authority_level = 'deputy_governor'
            else:
                rec.authority_level = 'governor'

    def _compute_committee_count(self):
        for rec in self:
            rec.committee_count = len(rec.committee_ids)

    def _compute_document_count(self):
        for rec in self:
            rec.document_count = len(rec.document_ids)

    # ── Constraints ────────────────────────────────────────────────────────
    @api.constrains('jihat_siyadiya', 'jihat_code')
    def _check_jihat_code(self):
        for rec in self:
            if rec.jihat_siyadiya and not rec.jihat_code:
                raise ValidationError(_(
                    'رمز الجهة السيادية مطلوب عند تفعيل خاصية الجهة السيادية.\n'
                    'يُرجى إدخال رمز الجهة في حقل "رمز الجهة السيادية".'
                ))

    # ── Sequence Creation ─────────────────────────────────────────────────
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code(
                    'procurement.tender') or _('New')
        return super().create(vals_list)

    # ── Stage Transitions ─────────────────────────────────────────────────
    def action_to_committee(self):
        self.ensure_one()
        if not self.committee_ids:
            raise UserError(_(
                'يجب تشكيل لجنة واحدة على الأقل قبل المتابعة.\n'
                'انتقل إلى تبويب "اللجان" وأنشئ لجنة التشكيل.'
            ))
        self.state = 'committee'

    def action_publish(self):
        self.ensure_one()
        if not self._doc_exists('كراسة_شروط'):
            raise UserError(_(
                'يجب إنشاء كراسة الشروط والمواصفات وتوقيعها قبل النشر.\n'
                'استخدم زر "إنشاء كراسة الشروط" في تبويب المستندات.'
            ))
        self.state = 'published'

    def action_to_evaluation(self):
        self.ensure_one()
        if self.state != 'published':
            raise UserError(_('يجب أن تكون المناقصة في حالة "منشور" للانتقال إلى مرحلة التقييم.'))
        self.state = 'evaluation'

    def action_award(self):
        self.ensure_one()
        # Sovereign entity bypass — skip committee evaluation requirement
        if self.jihat_siyadiya:
            if not self.jihat_code:
                raise UserError(_(
                    'رمز الجهة السيادية مطلوب قبل إتمام الترسية.'
                ))
        else:
            undecided = self.committee_ids.filtered(
                lambda c: c.state not in ('decided', 'signed')
            )
            if undecided:
                raise UserError(_(
                    'يجب أن تتخذ جميع اللجان قراراتها قبل إتمام الترسية.\n'
                    'اللجان المعلقة: %s'
                ) % ', '.join(undecided.mapped('name')))
        self.date_award = fields.Date.today()
        self.state = 'award'
        # Auto-generate إخطار الترسية if the report exists
        self._safe_generate_document('l10n_eg_tender.report_award_notification')

    def action_contract(self):
        self.ensure_one()
        if not self.partner_id:
            raise UserError(_(
                'يجب تحديد المورد / المقاول الفائز قبل إتمام التعاقد.'
            ))
        self.date_contract = fields.Date.today()
        self.state = 'contract'
        self._create_purchase_order()

    def action_reset_draft(self):
        self.ensure_one()
        if self.state == 'contract':
            raise UserError(_('لا يمكن إعادة المناقصة المتعاقد عليها إلى المسودة.'))
        self.state = 'draft'

    # ── Document Helpers ──────────────────────────────────────────────────
    def _doc_exists(self, doc_type):
        return bool(self.document_ids.filtered(
            lambda d: d.doc_type == doc_type
            and d.state in ('generated', 'signed')
        ))

    def _safe_generate_document(self, report_xml_id):
        """Generate and store a document — silently skips if report not found."""
        try:
            report = self.env.ref(report_xml_id, raise_if_not_found=False)
            if not report:
                return None
            pdf_content, _ = report._render_qweb_pdf(self.ids)
            attachment = self.env['ir.attachment'].create({
                'name':      report.name + ' — ' + self.name + '.pdf',
                'type':      'binary',
                'datas':     pdf_content,
                'res_model': self._name,
                'res_id':    self.id,
                'mimetype':  'application/pdf',
            })
            doc = self.env['procurement.document'].create({
                'tender_id':      self.id,
                'doc_type':       report_xml_id.split('.')[-1],
                'qweb_template':  report_xml_id,
                'state':          'generated',
                'date_generated': fields.Datetime.now(),
                'attachment_id':  attachment.id,
            })
            return doc
        except Exception:
            return None

    def _create_purchase_order(self):
        """Auto-create a purchase.order when tender reaches contract stage."""
        if self.purchase_order_id:
            return self.purchase_order_id
        po = self.env['purchase.order'].create({
            'partner_id':   self.partner_id.id,
            'tender_id':    self.id,
            'contract_ref': self.name,
            'jihat_code':   self.jihat_code or '',
            'origin':       self.name,
        })
        self.purchase_order_id = po
        return po

    # ── Report Helpers (used by QWeb templates) ───────────────────────────
    def _get_authority_title(self):
        titles = {
            'dept_head':       'مدير الإدارة المختصة',
            'deputy_governor': 'نائب المحافظ',
            'governor':        'المحافظ',
        }
        return titles.get(self.authority_level, 'المدير العام')

    def _get_hijri_date(self, date_val=None):
        """Return Hijri date string. Requires hijri-converter pip package."""
        try:
            from hijri_converter import convert  # noqa: PLC0415
            d = date_val or fields.Date.today()
            h = convert.Gregorian(d.year, d.month, d.day).to_hijri()
            return '%d/%d/%d هـ' % (h.day, h.month, h.year)
        except ImportError:
            return ''
        except Exception:
            return ''

    # ── Smart Buttons ─────────────────────────────────────────────────────
    def action_view_committees(self):
        return {
            'name': _('Committees'),
            'type': 'ir.actions.act_window',
            'res_model': 'procurement.committee',
            'view_mode': 'list,form',
            'domain': [('tender_id', '=', self.id)],
            'context': {'default_tender_id': self.id},
        }

    def action_view_documents(self):
        return {
            'name': _('Documents'),
            'type': 'ir.actions.act_window',
            'res_model': 'procurement.document',
            'view_mode': 'list,form',
            'domain': [('tender_id', '=', self.id)],
            'context': {'default_tender_id': self.id},
        }
