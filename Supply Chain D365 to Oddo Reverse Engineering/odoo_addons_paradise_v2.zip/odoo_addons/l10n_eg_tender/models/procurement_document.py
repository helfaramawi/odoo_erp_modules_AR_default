# -*- coding: utf-8 -*-
from odoo import models, fields, api, _


class ProcurementDocument(models.Model):
    _name = 'procurement.document'
    _description = 'Procurement Document — مستند التعاقد'
    _order = 'date_generated desc'

    tender_id = fields.Many2one(
        'procurement.tender',
        string='Tender',
        required=True,
        ondelete='cascade',
        index=True,
    )
    doc_type = fields.Selection([
        ('كراسة_شروط',      'كراسة الشروط والمواصفات'),
        ('محضر_فتح',        'محضر فتح المظاريف'),
        ('محضر_بت_فني_أ',   'محضر البت الفني — الجلسة الأولى'),
        ('محضر_بت_فني_ب',   'محضر البت الفني — الجلسة الثانية'),
        ('محضر_بت_مالي_1',  'محضر البت المالي — الأول'),
        ('محضر_بت_مالي_2',  'محضر البت المالي — الثاني'),
        ('إخطار_ترسية',     'إخطار الترسية'),
        ('عقد_توريد',       'عقد التوريد'),
        ('عقد_تنفيذ',       'عقد التنفيذ'),
        ('أمر_توريد',       'أمر التوريد'),
        ('أمر_إسناد',       'أمر الإسناد'),
        ('استمارة_50',      'استمارة صرف 50 ع.ح'),
        ('محضر_مفاوضة',     'محضر جلسة المفاوضة'),
        ('report_bid_opening',        'محضر فتح المظاريف'),
        ('report_award_notification', 'إخطار الترسية'),
        ('other',           'مستند آخر'),
    ], string='Document Type', required=True)

    qweb_template = fields.Char(
        string='QWeb Template XML ID',
        help='The ir.actions.report XML ID used to generate this document.',
    )
    state = fields.Selection([
        ('draft',     'Draft — مسودة'),
        ('generated', 'Generated — منشأ'),
        ('signed',    'Signed — موقع'),
        ('archived',  'Archived — مؤرشف'),
    ], default='generated', string='Status')

    date_generated = fields.Datetime(
        string='Generated On',
        default=fields.Datetime.now,
    )
    signed_by = fields.Many2one(
        'res.users',
        string='Signed By',
    )
    attachment_id = fields.Many2one(
        'ir.attachment',
        string='PDF Attachment',
        readonly=True,
    )

    name = fields.Char(
        compute='_compute_name',
        store=True,
    )

    @api.depends('doc_type', 'tender_id')
    def _compute_name(self):
        for rec in self:
            doc_label = dict(
                rec._fields['doc_type'].selection
            ).get(rec.doc_type, rec.doc_type)
            rec.name = '%s — %s' % (doc_label, rec.tender_id.name or '')

    def action_mark_signed(self):
        self.ensure_one()
        self.state = 'signed'
        self.signed_by = self.env.uid

    def action_view_attachment(self):
        self.ensure_one()
        if not self.attachment_id:
            return
        return {
            'type': 'ir.actions.act_url',
            'url': '/web/content/%d?download=true' % self.attachment_id.id,
            'target': 'self',
        }
