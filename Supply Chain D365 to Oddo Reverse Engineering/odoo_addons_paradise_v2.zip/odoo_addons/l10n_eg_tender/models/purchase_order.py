# -*- coding: utf-8 -*-
from odoo import models, fields, api, _


class PurchaseOrderTender(models.Model):
    _inherit = 'purchase.order'

    # ── Back-link to tender ───────────────────────────────────────────────
    tender_id = fields.Many2one(
        'procurement.tender',
        string='Source Tender',
        copy=False,
        index=True,
        ondelete='set null',
    )

    # ── Government-specific fields ─────────────────────────────────────────
    contract_ref = fields.Char(
        string='Contract Reference (رقم العقد)',
        copy=False,
        help='Government contract reference number — mandatory for audit trail.',
    )
    jihat_code = fields.Char(
        string='رمز الجهة السيادية',
        size=20,
        help='Inherited from tender for PR-07 sovereign entity document output.',
    )

    # ── Direct Order fields (C-PR04) ──────────────────────────────────────
    is_direct_order = fields.Boolean(
        string='Direct Order (أمر مباشر)',
        default=False,
        help='Activates استمارة 50 and محضر الفحص الفني print buttons.',
    )
    direct_order_reason = fields.Selection([
        ('emergency',          'حالة الضرورة / الطوارئ'),
        ('single_supplier',    'مورد وحيد / مورد حصري'),
        ('small_value',        'قيمة صغيرة دون الحد المقرر'),
        ('gov_entity',         'جهة حكومية / هيئة عامة'),
        ('contract_extension', 'تمديد عقد قائم'),
    ], string='Direct Order Justification')

    direct_order_reason_text = fields.Text(
        string='Justification Details (Arabic)',
        help='Elaboration printed on استمارة صرف 50.',
    )
    form_50_ref = fields.Char(
        string='استمارة 50 Reference',
        copy=False,
        readonly=True,
    )

    # ── Smart button ──────────────────────────────────────────────────────
    def action_view_tender(self):
        self.ensure_one()
        if not self.tender_id:
            return
        return {
            'name': _('Tender'),
            'type': 'ir.actions.act_window',
            'res_model': 'procurement.tender',
            'res_id': self.tender_id.id,
            'view_mode': 'form',
        }

    # ── Report helpers (used by استمارة 50 QWeb) ─────────────────────────
    def _amount_in_words_ar(self):
        """Return total amount in Arabic words for استمارة 50."""
        try:
            from num2words import num2words  # noqa: PLC0415
            return num2words(self.amount_total, lang='ar',
                             to='currency', currency='EGP')
        except (ImportError, NotImplementedError):
            return '%.2f جنيه مصري' % self.amount_total

    def _get_hijri_date(self):
        try:
            from hijri_converter import convert  # noqa: PLC0415
            d = fields.Date.today()
            h = convert.Gregorian(d.year, d.month, d.day).to_hijri()
            return '%d/%d/%d هـ' % (h.day, h.month, h.year)
        except ImportError:
            return ''

    def _get_authority_title(self):
        if self.amount_total < 50_000:
            return 'مدير الإدارة المختصة'
        elif self.amount_total < 500_000:
            return 'نائب المحافظ'
        else:
            return 'المحافظ'
