# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class ResPartnerTender(models.Model):
    _inherit = 'res.partner'

    # ── Sovereign Entity fields (PR-07) ───────────────────────────────────
    jihat_siyadiya = fields.Boolean(
        string='Sovereign Entity (جهة سيادية)',
        default=False,
        help='Mark this partner as an Egyptian government sovereign entity. '
             'Enables PR-07 direct contracting bypass workflow.',
    )
    jihat_code = fields.Char(
        string='رمز الجهة السيادية',
        size=20,
        help='Official sovereign entity classification code. '
             'Printed on all PR-07 output documents.',
    )

    # ── Vendor Classification (C-PR03 prequalification) ───────────────────
    vendor_category = fields.Selection([
        ('BLDG',  'مواد البناء والتشييد'),
        ('OFFICE','المستلزمات المكتبية والقرطاسية'),
        ('IT',    'تقنية المعلومات والأجهزة'),
        ('CIVIL', 'الأعمال المدنية والإنشائية'),
        ('CLEAN', 'خدمات النظافة والصيانة'),
        ('VEH',   'المركبات وقطع الغيار'),
        ('MED',   'المستلزمات الطبية والصحية'),
        ('FOOD',  'المواد الغذائية والإعاشة'),
        ('OTHER', 'أخرى'),
    ], string='Vendor Category (فئة المورد)',
       help='Used by C-PR03 for limited tender vendor shortlisting.')

    prequalified = fields.Boolean(
        string='Prequalified Vendor (مؤهَّل)',
        default=False,
        help='Vendor is approved for limited tender (مناقصة محدودة) invitations.',
    )

    # ── Contractor fields (C-PR05) ────────────────────────────────────────
    is_contractor = fields.Boolean(
        string='Contractor (مقاول)',
        default=False,
    )
    contractor_grade = fields.Selection([
        ('first',  'الدرجة الأولى'),
        ('second', 'الدرجة الثانية'),
        ('third',  'الدرجة الثالثة'),
    ], string='Contractor Grade (درجة المقاول)')

    # ── Tender history ────────────────────────────────────────────────────
    tender_ids = fields.One2many(
        'procurement.tender',
        'partner_id',
        string='Tenders Awarded',
    )
    tender_count = fields.Integer(
        compute='_compute_tender_count',
        string='Awarded Tenders',
    )

    def _compute_tender_count(self):
        for rec in self:
            rec.tender_count = len(rec.tender_ids)

    # ── Constraints ────────────────────────────────────────────────────────
    @api.constrains('jihat_siyadiya', 'jihat_code')
    def _check_sovereign_code(self):
        for rec in self:
            if rec.jihat_siyadiya and not rec.jihat_code:
                raise ValidationError(_(
                    'رمز الجهة السيادية مطلوب عند تفعيل خاصية الجهة السيادية '
                    'على سجل المورد/الجهة.'
                ))
