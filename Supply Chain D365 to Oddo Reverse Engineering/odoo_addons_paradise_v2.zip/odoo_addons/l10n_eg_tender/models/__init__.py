# -*- coding: utf-8 -*-
from . import procurement_tender
from . import procurement_committee
from . import procurement_document
from . import res_partner
from . import purchase_order
