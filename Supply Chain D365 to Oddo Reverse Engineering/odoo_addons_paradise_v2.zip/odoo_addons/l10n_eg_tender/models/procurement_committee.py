# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class ProcurementCommittee(models.Model):
    _name = 'procurement.committee'
    _description = 'Procurement Committee — لجنة التعاقدات'
    _inherit = ['mail.thread']
    _order = 'tender_id, id'

    name = fields.Char(
        string='Committee Name',
        required=True,
        tracking=True,
    )
    tender_id = fields.Many2one(
        'procurement.tender',
        string='Tender',
        required=True,
        ondelete='cascade',
        index=True,
    )
    committee_type = fields.Selection([
        ('تشكيل',     'تشكيل اللجان — Formation'),
        ('بت_فني',    'البت الفني — Technical Evaluation'),
        ('بت_مالي',   'البت المالي — Financial Evaluation'),
        ('فتح_مظاريف','فتح المظاريف — Bid Opening'),
        ('ممارسة',    'التفاوض / الممارسة — Negotiation'),
    ], string='Committee Type', required=True)

    # Members
    member_ids = fields.Many2many(
        'res.users',
        'committee_member_rel',
        'committee_id',
        'user_id',
        string='Members',
    )
    chairman_id = fields.Many2one(
        'res.users',
        string='Chairman (رئيس اللجنة)',
        required=True,
    )
    secretary_id = fields.Many2one(
        'res.users',
        string='Secretary (مقرر اللجنة)',
    )

    # Scheduling
    date_meeting = fields.Datetime(
        string='Meeting Date & Time',
    )
    date_completed = fields.Datetime(
        string='Completion Date',
        readonly=True,
        copy=False,
    )

    # Decision
    decision = fields.Text(
        string='Committee Decision (Arabic)',
        help='Full Arabic decision text — printed in committee minutes.',
    )
    state = fields.Selection([
        ('draft',    'Draft — مسودة'),
        ('convened', 'Convened — منعقدة'),
        ('decided',  'Decided — اتخذت قرارها'),
        ('signed',   'Signed — موقعة'),
    ], default='draft', tracking=True)

    report_id = fields.Many2one(
        'procurement.document',
        string='Minutes Document',
        readonly=True,
        copy=False,
    )

    # ── Constraints ────────────────────────────────────────────────────────
    @api.constrains('chairman_id', 'member_ids')
    def _check_chairman_in_members(self):
        for rec in self:
            if rec.chairman_id and rec.member_ids:
                if rec.chairman_id not in rec.member_ids:
                    # Auto-add chairman to members
                    rec.member_ids = [(4, rec.chairman_id.id)]

    # ── Actions ────────────────────────────────────────────────────────────
    def action_convene(self):
        self.ensure_one()
        if not self.member_ids:
            raise UserError(_('يجب تحديد أعضاء اللجنة قبل انعقادها.'))
        self.state = 'convened'

    def action_decide(self):
        self.ensure_one()
        if not self.decision:
            raise UserError(_(
                'يجب إدخال نص قرار اللجنة قبل إغلاق الجلسة.'
            ))
        self.date_completed = fields.Datetime.now()
        self.state = 'decided'

    def action_sign(self):
        self.ensure_one()
        if self.state != 'decided':
            raise UserError(_('يجب أن تتخذ اللجنة قرارها أولاً.'))
        self.state = 'signed'
