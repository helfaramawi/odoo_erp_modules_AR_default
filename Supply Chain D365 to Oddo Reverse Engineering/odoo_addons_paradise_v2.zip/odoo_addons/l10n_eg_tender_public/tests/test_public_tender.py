# -*- coding: utf-8 -*-
from odoo.tests.common import TransactionCase
from odoo.exceptions import UserError, ValidationError


class TestPublicTenderPipeline(TransactionCase):
    """14 unit tests for C-PR02 PublicTenderPipeline."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.dept = cls.env['hr.department'].create({'name': 'Test Dept'})
        cls.vendor1 = cls.env['res.partner'].create(
            {'name': 'شركة أ للتوريدات', 'supplier_rank': 1})
        cls.vendor2 = cls.env['res.partner'].create(
            {'name': 'شركة ب للتوريدات', 'supplier_rank': 1})
        cls.vendor3 = cls.env['res.partner'].create(
            {'name': 'شركة ج للتوريدات', 'supplier_rank': 1})
        cls.committee = None

    def _make_public_tender(self):
        t = self.env['procurement.tender'].create({
            'tender_type':     'مناقصة_عامة',
            'description':     'توريد مستلزمات اختبار',
            'amount_estimate':  200000,
            'department_id':   self.dept.id,
            'date_start':      '2025-01-01',
        })
        # Add committee
        c = self.env['procurement.committee'].create({
            'name':           'لجنة البت الفني',
            'tender_id':      t.id,
            'committee_type': 'بت_فني',
            'chairman_id':    self.env.user.id,
            'member_ids':     [(4, self.env.user.id)],
        })
        t.state = 'evaluation'
        return t, c

    def _add_bids(self, tender, amounts):
        """Add bids with given financial amounts."""
        bids = []
        for i, amount in enumerate(amounts, 1):
            vendor = getattr(self, 'vendor%d' % i, self.vendor1)
            bid = self.env['bid.envelope'].create({
                'tender_id':       tender.id,
                'partner_id':      vendor.id,
                'envelope_number': 'ENV/2025/%03d' % i,
                'technical_amount': amount,
                'financial_amount': amount,
            })
            bids.append(bid)
        return bids

    # TC-01 ── Late bid rejected after deadline
    def test_01_late_bid_rejected(self):
        t, _ = self._make_public_tender()
        t.bid_deadline = '2025-01-01 10:00:00'
        with self.assertRaises((UserError, ValidationError)):
            self.env['bid.envelope'].create({
                'tender_id':       t.id,
                'partner_id':      self.vendor1.id,
                'envelope_number': 'ENV/LATE',
                'submission_date': '2025-01-02 10:00:00',
            })

    # TC-02 ── Duplicate vendor bid rejected
    def test_02_duplicate_vendor_rejected(self):
        t, _ = self._make_public_tender()
        self.env['bid.envelope'].create({
            'tender_id': t.id, 'partner_id': self.vendor1.id,
            'envelope_number': 'ENV/001',
        })
        with self.assertRaises(ValidationError):
            self.env['bid.envelope'].create({
                'tender_id': t.id, 'partner_id': self.vendor1.id,
                'envelope_number': 'ENV/002',
            })

    # TC-03 ── Cannot open envelopes outside evaluation state
    def test_03_open_envelopes_wrong_state(self):
        t, _ = self._make_public_tender()
        t.state = 'published'
        with self.assertRaises(UserError):
            t.action_open_technical_envelopes()

    # TC-04 ── Cannot open envelopes with no bids
    def test_04_open_envelopes_no_bids(self):
        t, _ = self._make_public_tender()
        with self.assertRaises(UserError):
            t.action_open_technical_envelopes()

    # TC-05 ── Envelope opening sets state to opened_technical
    def test_05_open_envelopes_success(self):
        t, _ = self._make_public_tender()
        self._add_bids(t, [100000, 90000, 110000])
        t.action_open_technical_envelopes()
        for bid in t.bid_ids:
            self.assertEqual(bid.state, 'opened_technical')

    # TC-06 ── Technical evaluation marks qualified/rejected correctly
    def test_06_technical_evaluation(self):
        t, c = self._make_public_tender()
        bids = self._add_bids(t, [100000, 90000, 110000])
        t.action_open_technical_envelopes()
        # Qualify first 2, reject third
        qualified_ids = [bids[0].id, bids[1].id]
        t.action_technical_evaluate(
            'بت_فني_أ', c.id, 'تم قبول العرضين الأول والثاني فنياً.',
            qualified_ids)
        self.assertTrue(bids[0].technical_qualified)
        self.assertTrue(bids[1].technical_qualified)
        self.assertEqual(bids[2].state, 'rejected')

    # TC-07 ── Cannot do financial evaluation with no qualified bids
    def test_07_financial_eval_no_qualified(self):
        t, _ = self._make_public_tender()
        self._add_bids(t, [100000])
        with self.assertRaises(UserError):
            t.action_financial_evaluate()

    # TC-08 ── Financial ranking: ascending price, rank 1 = lowest
    def test_08_financial_ranking(self):
        t, c = self._make_public_tender()
        bids = self._add_bids(t, [100000, 80000, 120000])
        # Qualify all
        for bid in bids:
            bid.technical_qualified = True
        winner = t.action_financial_evaluate()
        self.assertEqual(winner.financial_amount, 80000,
                         'Lowest price bid should win')
        self.assertEqual(winner.financial_rank, 1)
        self.assertEqual(t.winning_bid_id, winner)
        self.assertEqual(t.partner_id, self.vendor2)

    # TC-09 ── Cannot award public tender without winning bid
    def test_09_award_requires_winning_bid(self):
        t, c = self._make_public_tender()
        with self.assertRaises(UserError):
            t.action_award()

    # TC-10 ── Award with winning bid succeeds
    def test_10_award_with_winning_bid(self):
        t, c = self._make_public_tender()
        bids = self._add_bids(t, [90000, 100000])
        for bid in bids:
            bid.technical_qualified = True
        t.action_financial_evaluate()
        c.state = 'decided'
        c.decision = 'Test decision'
        t.action_award()
        self.assertEqual(t.state, 'award')

    # TC-11 ── Envelope number format validation
    def test_11_envelope_number_format(self):
        t, _ = self._make_public_tender()
        bid = self.env['bid.envelope'].create({
            'tender_id': t.id, 'partner_id': self.vendor1.id,
            'envelope_number': 'ENV/2025/001',
        })
        self.assertEqual(bid.envelope_number, 'ENV/2025/001')

    # TC-12 ── Bid count smart button computed correctly
    def test_12_bid_count(self):
        t, _ = self._make_public_tender()
        self.assertEqual(t.bid_count, 0)
        self._add_bids(t, [100000, 90000])
        self.assertEqual(t.bid_count, 2)

    # TC-13 ── tender.evaluation record created by action_technical_evaluate
    def test_13_evaluation_record_created(self):
        t, c = self._make_public_tender()
        bids = self._add_bids(t, [100000])
        t.action_open_technical_envelopes()
        t.action_technical_evaluate('بت_فني_أ', c.id, 'Test', [bids[0].id])
        eval_recs = t.evaluation_ids.filtered(lambda e: e.eval_type == 'بت_فني_أ')
        self.assertEqual(len(eval_recs), 1)
        self.assertEqual(eval_recs[0].state, 'decided')

    # TC-14 ── Sample receipt can be added to tender
    def test_14_sample_receipt(self):
        t, _ = self._make_public_tender()
        product = self.env['product.product'].create({'name': 'Test Item'})
        sample = self.env['tender.sample.receipt'].create({
            'tender_id':       t.id,
            'partner_id':      self.vendor1.id,
            'product_id':      product.id,
            'receipt_date':    '2025-01-05',
            'received_by':     self.env.uid,
            'sample_condition': 'good',
        })
        self.assertEqual(sample.tender_id, t)
        self.assertEqual(sample.inspection_result, 'pending')
