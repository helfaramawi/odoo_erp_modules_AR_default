# -*- coding: utf-8 -*-
from . import bid_envelope
from . import tender_evaluation
from . import tender_sample_receipt
from . import procurement_tender
