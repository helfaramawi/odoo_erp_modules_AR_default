# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class ProcurementTenderPublic(models.Model):
    """Extends procurement.tender with full public tender pipeline."""
    _inherit = 'procurement.tender'

    # ── New fields added by C-PR02 ────────────────────────────────────────
    bid_ids = fields.One2many(
        'bid.envelope', 'tender_id',
        string='Bid Submissions (العطاءات)',
    )
    evaluation_ids = fields.One2many(
        'tender.evaluation', 'tender_id',
        string='Evaluation Rounds',
    )
    sample_ids = fields.One2many(
        'tender.sample.receipt', 'tender_id',
        string='Sample Receipts',
    )
    bid_deadline = fields.Datetime(
        string='Bid Submission Deadline',
        tracking=True,
        help='System rejects bids submitted after this date/time.',
    )
    opening_date = fields.Datetime(
        string='فتح المظاريف Date',
        tracking=True,
    )
    publication_date = fields.Date(
        string='Publication Date',
    )
    winning_bid_id = fields.Many2one(
        'bid.envelope',
        string='Winning Bid',
        readonly=True,
        copy=False,
        index=True,
    )

    # ── Smart button counts ───────────────────────────────────────────────
    bid_count = fields.Integer(compute='_compute_bid_count', string='Bids')

    def _compute_bid_count(self):
        for rec in self:
            rec.bid_count = len(rec.bid_ids)

    # ── Bid receipt ───────────────────────────────────────────────────────
    def action_receive_bid(self, partner_id, envelope_number):
        """Receive a vendor bid. Validates deadline. Returns bid.envelope."""
        self.ensure_one()
        # Deadline check handled by bid.envelope constraint
        bid = self.env['bid.envelope'].create({
            'tender_id':       self.id,
            'partner_id':      partner_id,
            'envelope_number': envelope_number,
            'state':           'received',
        })
        return bid

    # ── فتح المظاريف — Technical Bid Opening ─────────────────────────────
    def action_open_technical_envelopes(self):
        self.ensure_one()
        if self.state != 'evaluation':
            raise UserError(_(
                'يجب أن تكون المناقصة في مرحلة التقييم لفتح المظاريف.'
            ))
        if not self.bid_ids:
            raise UserError(_(
                'لا توجد عطاءات مقدمة لفتح المظاريف.'
            ))
        self.bid_ids.write({'state': 'opened_technical'})
        self._safe_generate_document(
            'l10n_eg_tender_public.report_bid_opening')
        return True

    # ── Technical Evaluation ──────────────────────────────────────────────
    def action_technical_evaluate(self, eval_type, committee_id,
                                   decision_text, qualified_bid_ids):
        """
        Run a technical evaluation round.
        :param eval_type: 'بت_فني_أ' or 'بت_فني_ب'
        :param committee_id: procurement.committee record ID
        :param decision_text: Arabic decision text
        :param qualified_bid_ids: list of bid.envelope IDs that qualified
        """
        self.ensure_one()
        eval_rec = self.env['tender.evaluation'].create({
            'tender_id':     self.id,
            'eval_type':     eval_type,
            'committee_id':  committee_id,
            'decision_text': decision_text,
            'state':         'decided',
            'date_session':  fields.Datetime.now(),
            'date_completed': fields.Datetime.now(),
        })
        # Mark qualified bids
        self.bid_ids.filtered(
            lambda b: b.id in qualified_bid_ids
        ).write({'technical_qualified': True})
        # Mark rejected bids
        rejected = self.bid_ids.filtered(
            lambda b: b.id not in qualified_bid_ids
            and b.state == 'opened_technical'
        )
        rejected.write({'state': 'rejected'})
        return eval_rec

    # ── Financial Evaluation — rank by ascending price ────────────────────
    def action_financial_evaluate(self):
        """Rank technically qualified bids by financial_amount ascending."""
        self.ensure_one()
        qualified = self.bid_ids.filtered('technical_qualified').filtered(
            lambda b: b.state != 'rejected'
        )
        if not qualified:
            raise UserError(_(
                'لا توجد عروض مؤهلة فنياً لإجراء التقييم المالي.'
            ))
        # Sort ascending — lowest price wins
        sorted_bids = qualified.sorted('financial_amount')
        for rank, bid in enumerate(sorted_bids, 1):
            bid.financial_rank = rank
        # Auto-set winner
        winner = sorted_bids[0]
        self.winning_bid_id = winner
        self.partner_id = winner.partner_id
        return winner

    # ── Override action_award to validate winning bid ─────────────────────
    def action_award(self):
        """Override to require winning_bid for public tenders."""
        if self.tender_type == 'مناقصة_عامة':
            if not self.winning_bid_id:
                raise UserError(_(
                    'يجب إتمام التقييم المالي وتحديد العرض الفائز '
                    'قبل الترسية في المناقصة العامة.'
                ))
        return super().action_award()

    # ── Smart button ──────────────────────────────────────────────────────
    def action_view_bids(self):
        return {
            'name': _('Bid Envelopes — العطاءات'),
            'type': 'ir.actions.act_window',
            'res_model': 'bid.envelope',
            'view_mode': 'list,form',
            'domain': [('tender_id', '=', self.id)],
            'context': {
                'default_tender_id': self.id,
            },
        }

    def action_view_evaluations(self):
        return {
            'name': _('Evaluation Rounds — جلسات التقييم'),
            'type': 'ir.actions.act_window',
            'res_model': 'tender.evaluation',
            'view_mode': 'list,form',
            'domain': [('tender_id', '=', self.id)],
            'context': {
                'default_tender_id': self.id,
            },
        }
