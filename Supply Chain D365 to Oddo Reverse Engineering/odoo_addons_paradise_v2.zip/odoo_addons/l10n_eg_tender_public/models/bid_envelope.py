# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class BidEnvelope(models.Model):
    _name = 'bid.envelope'
    _description = 'Tender Bid Envelope — مظروف العطاء'
    _order = 'envelope_number'
    _rec_name = 'envelope_number'

    # ── Core Fields ───────────────────────────────────────────────────────
    tender_id = fields.Many2one(
        'procurement.tender',
        string='Tender',
        required=True,
        ondelete='cascade',
        index=True,
    )
    partner_id = fields.Many2one(
        'res.partner',
        string='Vendor',
        required=True,
        index=True,
    )
    submission_date = fields.Datetime(
        string='Submission Date & Time',
        default=fields.Datetime.now,
        required=True,
    )
    envelope_number = fields.Char(
        string='Envelope Number (رقم المظروف)',
        required=True,
        copy=False,
        index=True,
    )

    # ── Bid Values ─────────────────────────────────────────────────────────
    currency_id = fields.Many2one(
        related='tender_id.currency_id',
        store=True,
    )
    technical_amount = fields.Monetary(
        string='Technical Offer Value (EGP)',
        currency_field='currency_id',
        help='Populated after فتح المظاريف الفنية',
    )
    financial_amount = fields.Monetary(
        string='Financial Offer Value (EGP)',
        currency_field='currency_id',
        help='Populated after فتح المظاريف المالية. '
             'Updated to negotiated price by C-PR06.',
    )

    # ── Evaluation Results ─────────────────────────────────────────────────
    state = fields.Selection([
        ('received',          'Received — مستلم'),
        ('opened_technical',  'Technical Opened — مفتوح فنياً'),
        ('opened_financial',  'Financial Opened — مفتوح مالياً'),
        ('evaluated',         'Evaluated — مقيَّم'),
        ('awarded',           'Awarded — فائز'),
        ('rejected',          'Rejected — مرفوض'),
    ], default='received', string='Status', index=True, tracking=True)

    technical_qualified = fields.Boolean(
        string='Technically Qualified (مطابق فنياً)',
        default=False,
    )
    financial_rank = fields.Integer(
        string='Financial Rank (الترتيب المالي)',
        help='1 = lowest price = winner',
    )
    disqualification_reason = fields.Text(
        string='Rejection Reason (Arabic)',
    )
    attachment_ids = fields.Many2many(
        'ir.attachment',
        'bid_envelope_attachment_rel',
        'bid_id',
        'attachment_id',
        string='Submitted Documents',
    )

    # ── Constraints ────────────────────────────────────────────────────────
    @api.constrains('tender_id', 'partner_id')
    def _check_unique_vendor(self):
        for rec in self:
            duplicate = self.search([
                ('tender_id',  '=', rec.tender_id.id),
                ('partner_id', '=', rec.partner_id.id),
                ('id',         '!=', rec.id),
            ])
            if duplicate:
                raise ValidationError(_(
                    'لا يمكن تقديم أكثر من عطاء واحد من نفس المورد في المناقصة.\n'
                    'المورد: %(vendor)s — المناقصة: %(tender)s',
                    vendor=rec.partner_id.name,
                    tender=rec.tender_id.name,
                ))

    @api.constrains('tender_id', 'submission_date')
    def _check_deadline(self):
        for rec in self:
            if (rec.tender_id.bid_deadline
                    and rec.submission_date > rec.tender_id.bid_deadline):
                raise UserError(_(
                    'انتهى موعد تقديم العطاءات في %(deadline)s.\n'
                    'لا يمكن قبول عطاءات جديدة بعد هذا الموعد.',
                    deadline=rec.tender_id.bid_deadline,
                ))

    # ── Name ──────────────────────────────────────────────────────────────
    def name_get(self):
        result = []
        for rec in self:
            name = '%s — %s' % (rec.envelope_number, rec.partner_id.name)
            result.append((rec.id, name))
        return result
