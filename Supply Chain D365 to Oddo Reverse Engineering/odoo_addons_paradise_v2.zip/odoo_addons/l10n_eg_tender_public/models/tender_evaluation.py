# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class TenderEvaluation(models.Model):
    _name = 'tender.evaluation'
    _description = 'Tender Evaluation Round — جلسة تقييم'
    _order = 'tender_id, id'

    tender_id = fields.Many2one(
        'procurement.tender',
        required=True,
        ondelete='cascade',
        index=True,
    )
    eval_type = fields.Selection([
        ('فتح_مظاريف',   'فتح المظاريف — Technical Bid Opening'),
        ('بت_فني_أ',     'البت الفني أ — 1st Technical Evaluation'),
        ('بت_فني_ب',     'البت الفني ب — 2nd Technical Evaluation'),
        ('فتح_مالي',     'فتح المظاريف المالية — Financial Bid Opening'),
        ('بت_مالي_أول',  'البت المالي الأول — 1st Financial Evaluation'),
        ('بت_مالي_ثاني', 'البت المالي الثاني — 2nd Financial Evaluation'),
    ], string='Evaluation Type', required=True, index=True)

    committee_id = fields.Many2one(
        'procurement.committee',
        string='Committee',
        required=True,
        domain="[('tender_id', '=', tender_id)]",
    )
    date_session = fields.Datetime(
        string='Session Date & Time',
        required=True,
    )
    date_completed = fields.Datetime(
        string='Completed On',
        readonly=True,
        copy=False,
    )
    decision_text = fields.Text(
        string='Committee Decision (Arabic)',
        help='Full Arabic decision text — printed in evaluation minutes.',
    )
    qualified_count = fields.Integer(
        compute='_compute_counts',
        string='Qualified Vendors',
        store=True,
    )
    rejected_count = fields.Integer(
        compute='_compute_counts',
        string='Rejected Vendors',
        store=True,
    )
    state = fields.Selection([
        ('scheduled',          'Scheduled — مجدول'),
        ('in_progress',        'In Progress — جارٍ'),
        ('decided',            'Decided — اتخذ قراره'),
        ('report_generated',   'Report Generated — صدر المحضر'),
        ('signed',             'Signed — موقع'),
    ], default='scheduled', string='Status', tracking=True)

    report_id = fields.Many2one(
        'procurement.document',
        string='Minutes Document',
        readonly=True,
        copy=False,
    )
    notes = fields.Text(string='Internal Notes')

    @api.depends('tender_id.bid_ids.technical_qualified',
                 'tender_id.bid_ids.state')
    def _compute_counts(self):
        for rec in self:
            bids = rec.tender_id.bid_ids
            rec.qualified_count = len(bids.filtered('technical_qualified'))
            rec.rejected_count = len(bids.filtered(
                lambda b: b.state == 'rejected'))

    def action_start(self):
        self.ensure_one()
        self.state = 'in_progress'

    def action_decide(self):
        self.ensure_one()
        if not self.decision_text:
            raise UserError(_(
                'يجب إدخال نص قرار اللجنة قبل إغلاق جلسة التقييم.'
            ))
        self.date_completed = fields.Datetime.now()
        self.state = 'decided'
        # Mark the linked committee as decided
        if self.committee_id.state not in ('decided', 'signed'):
            self.committee_id.decision = self.decision_text
            self.committee_id.action_decide()

    def action_generate_report(self):
        self.ensure_one()
        # Map eval_type to report XML ID
        report_map = {
            'فتح_مظاريف':   'l10n_eg_tender_public.report_bid_opening',
            'بت_فني_أ':     'l10n_eg_tender_public.report_tech_eval_a',
            'بت_فني_ب':     'l10n_eg_tender_public.report_tech_eval_b',
            'بت_مالي_أول':  'l10n_eg_tender_public.report_fin_eval_1',
            'بت_مالي_ثاني': 'l10n_eg_tender_public.report_fin_eval_2',
        }
        report_id = report_map.get(self.eval_type)
        if not report_id:
            raise UserError(_('لا يوجد نموذج تقرير لهذا النوع من التقييم.'))
        doc = self.tender_id._safe_generate_document(report_id)
        if doc:
            self.report_id = doc
            self.state = 'report_generated'
        return doc
