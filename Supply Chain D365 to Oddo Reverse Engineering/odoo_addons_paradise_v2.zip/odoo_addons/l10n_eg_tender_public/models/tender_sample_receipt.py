# -*- coding: utf-8 -*-
from odoo import models, fields, api, _


class TenderSampleReceipt(models.Model):
    _name = 'tender.sample.receipt'
    _description = 'Sample Receipt Register — كشف استلام العينات'
    _order = 'receipt_date desc'

    tender_id = fields.Many2one(
        'procurement.tender',
        required=True,
        ondelete='cascade',
        index=True,
    )
    partner_id = fields.Many2one(
        'res.partner',
        string='Vendor Submitting Sample',
        required=True,
    )
    product_id = fields.Many2one(
        'product.product',
        string='Sample Item',
        required=True,
    )
    receipt_date = fields.Date(
        string='Receipt Date',
        required=True,
        default=fields.Date.today,
    )
    received_by = fields.Many2one(
        'res.users',
        string='Received By',
        default=lambda self: self.env.uid,
        required=True,
    )
    sample_condition = fields.Selection([
        ('good',       'Good — سليم'),
        ('damaged',    'Damaged — تالف'),
        ('incomplete', 'Incomplete — ناقص'),
    ], string='Sample Condition', required=True, default='good')

    inspection_result = fields.Selection([
        ('passed',  'Passed — مطابق'),
        ('failed',  'Failed — غير مطابق'),
        ('pending', 'Pending — قيد الفحص'),
    ], string='Inspection Result', default='pending')

    notes = fields.Text(string='Inspection Notes (Arabic)')
