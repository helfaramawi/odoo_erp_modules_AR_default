# -*- coding: utf-8 -*-
{
    'name': 'Public Tender Pipeline — المناقصة العامة (C-PR02)',
    'version': '17.0.1.0.0',
    'summary': 'Full government public tender: bid envelopes, البت الفني/المالي committees, 10 Arabic document templates',
    'description': """
        C-PR02 PublicTenderPipeline
        ============================
        Extends C-PR01 with:
        - bid.envelope model (vendor submissions)
        - tender.evaluation model (البت الفني/المالي rounds)
        - tender.sample.receipt (كشف استلام العينات)
        - فتح المظاريف event workflow
        - 11 Arabic QWeb report templates
        - Financial ranking by ascending price (lowest = winner)
        - إخطار الترسية auto-generation on award

        FRD: PR-02 المناقصة العامة للتوريدات وتقديم الخدمات
        Client: الديوان العام لمحافظة بورسعيد
        Delivered by: Paradise Integrated Solutions
    """,
    'author': 'Paradise Integrated Solutions',
    'license': 'LGPL-3',
    'category': 'Purchase',
    'depends': [
        'l10n_eg_tender',  # C-PR01 — REQUIRED foundation
        'purchase',
        'quality',
    ],
    'data': [
        'security/ir.model.access.csv',
        'data/sequences.xml',
        'views/bid_envelope_views.xml',
        'views/tender_evaluation_views.xml',
        'views/tender_views_inherit.xml',
        'report/report_bid_opening.xml',
        'report/report_tech_eval_a.xml',
        'report/report_tech_eval_b.xml',
        'report/report_fin_eval_1.xml',
        'report/report_fin_eval_2.xml',
        'report/report_vendor_registry.xml',
        'report/report_award_notification_ext.xml',
        'report/report_actions.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
